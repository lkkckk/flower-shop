import{x as o}from"./-14QgBge.js";import{h as t,I as a}from"./Cs-fsS2d.js";const s=(()=>{const e=a(!1);return t(()=>{e.value=o()}),e});export{s as u};
