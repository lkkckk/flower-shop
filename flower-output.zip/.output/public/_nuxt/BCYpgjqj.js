import{C as o,I as s}from"./Cs-fsS2d.js";const t=()=>{const e=s(!1);return o(()=>{e.value=!0}),e};export{t as u};
