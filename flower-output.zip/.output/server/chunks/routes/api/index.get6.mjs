import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import { p as productRecipeInclude } from '../../_/productRecipe.mjs';
import { h as hideWholesalePriceForCashier } from '../../_/productVisibility.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const keyword = query.keyword;
  const category = query.category;
  const categoryId = query.categoryId ? Number(query.categoryId) : void 0;
  const status = query.status;
  const where = {};
  if (keyword) {
    where.name = { contains: keyword };
  }
  if (categoryId) {
    const allCats = await prisma.category.findMany({ select: { id: true, parentId: true } });
    const descendantIds = /* @__PURE__ */ new Set([categoryId]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const c of allCats) {
        if (c.parentId && descendantIds.has(c.parentId) && !descendantIds.has(c.id)) {
          descendantIds.add(c.id);
          changed = true;
        }
      }
    }
    where.categoryId = { in: Array.from(descendantIds) };
  } else if (category) {
    where.category = category;
  }
  if (status) {
    where.status = status;
  }
  try {
    const [list, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          unitConversions: true,
          categoryRef: true,
          recipe: { include: productRecipeInclude }
        },
        orderBy: {
          updatedAt: "desc"
        },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.product.count({ where })
    ]);
    return {
      data: {
        list: hideWholesalePriceForCashier(event, list),
        total,
        page,
        pageSize
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5546\u54C1\u5217\u8868\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get6.mjs.map
