import { c as defineEventHandler, h as getCurrentUser, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role !== "admin") {
    return { data: null, error: { message: "\u4EC5\u7BA1\u7406\u5458\u53EF\u64CD\u4F5C", code: "FORBIDDEN" } };
  }
  const users = await prisma.user.findMany({
    select: { id: true, username: true, name: true, role: true, status: true, createdAt: true },
    orderBy: { createdAt: "asc" }
  });
  return { data: users, error: null };
});

export { index_get as default };
//# sourceMappingURL=index.get10.mjs.map
