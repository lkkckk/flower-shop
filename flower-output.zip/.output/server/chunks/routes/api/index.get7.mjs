import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  const status = q.status;
  try {
    const where = {};
    if (status) where.status = status;
    const list = await prisma.promotion.findMany({
      where,
      orderBy: [{ status: "asc" }, { threshold: "asc" }]
    });
    return { data: { list }, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u67E5\u8BE2\u5931\u8D25", code: "FETCH_ERROR" } };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get7.mjs.map
