import { c as defineEventHandler, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const health_get = defineEventHandler(async () => {
  try {
    const productCount = await prisma.product.count();
    return {
      data: {
        status: "ok",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        productCount
      },
      error: null
    };
  } catch (e) {
    return {
      data: null,
      error: e.message || "Database connection failed"
    };
  }
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
