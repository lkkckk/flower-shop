import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Math.min(Number(query.pageSize) || 20, 50);
  const keyword = query.keyword;
  const category = query.category;
  const where = { status: "active" };
  if (keyword) where.name = { contains: keyword, mode: "insensitive" };
  if (category) where.category = category;
  try {
    const [rawList, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { unitConversions: true },
        orderBy: { updatedAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.product.count({ where })
    ]);
    const list = rawList.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      baseUnit: p.baseUnit,
      grade: p.grade,
      color: p.color,
      specification: p.specification,
      defaultPrice: p.defaultPrice,
      imageUrl: p.imageUrl,
      unitConversions: p.unitConversions.map((uc) => ({
        fromUnit: uc.fromUnit,
        toBaseQty: uc.toBaseQty
      }))
    }));
    return { data: { list, total, page, pageSize }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5546\u54C1\u5217\u8868\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
