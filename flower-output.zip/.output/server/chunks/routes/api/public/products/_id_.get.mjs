import { c as defineEventHandler, j as getRouterParam, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__get = defineEventHandler(async (event) => {
  const id = parseInt(getRouterParam(event, "id") || "0");
  if (!id) {
    return { data: null, error: { message: "\u53C2\u6570\u9519\u8BEF", code: "BAD_PARAMS" } };
  }
  const p = await prisma.product.findUnique({
    where: { id },
    include: { unitConversions: true }
  });
  if (!p || p.status !== "active") {
    return { data: null, error: { message: "\u5546\u54C1\u4E0D\u5B58\u5728\u6216\u5DF2\u4E0B\u67B6", code: "NOT_FOUND" } };
  }
  return {
    data: {
      id: p.id,
      name: p.name,
      category: p.category,
      baseUnit: p.baseUnit,
      grade: p.grade,
      color: p.color,
      specification: p.specification,
      defaultPrice: p.defaultPrice,
      imageUrl: p.imageUrl,
      shelfLifeDays: p.shelfLifeDays,
      unitConversions: p.unitConversions.map((uc) => ({
        fromUnit: uc.fromUnit,
        toBaseQty: uc.toBaseQty
      }))
    },
    error: null
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
