import { c as defineEventHandler, j as getRouterParam, r as readBody, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const repay_post = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5BA2\u6237 ID", code: "INVALID_PARAMS" } };
  }
  const body = await readBody(event);
  const amount = Number(body.amount);
  const paymentMethod = body.paymentMethod;
  const notes = body.notes ? String(body.notes) : null;
  if (!(amount > 0)) {
    return { data: null, error: { message: "\u8FD8\u6B3E\u91D1\u989D\u5FC5\u987B\u5927\u4E8E 0", code: "INVALID_PARAMS" } };
  }
  if (!["cash", "wechat", "alipay"].includes(paymentMethod)) {
    return { data: null, error: { message: "\u652F\u4ED8\u65B9\u5F0F\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" } };
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const customer = await tx.customer.findUnique({ where: { id } });
      if (!customer) throw new Error("\u5BA2\u6237\u4E0D\u5B58\u5728");
      const payment = await tx.payment.create({
        data: {
          customerId: id,
          amount,
          paymentMethod,
          type: "repay",
          notes,
          operator: "system"
        }
      });
      const updated = await tx.customer.update({
        where: { id },
        data: {
          balance: { increment: amount }
          // totalOwed 不变（业务规则：只增不减）
        }
      });
      return { customer: updated, payment };
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u8FD8\u6B3E\u5931\u8D25", code: "REPAY_ERROR" }
    };
  }
});

export { repay_post as default };
//# sourceMappingURL=repay.post.mjs.map
