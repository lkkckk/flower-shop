import { c as defineEventHandler, j as getRouterParam, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const favorites_get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5BA2\u6237 ID", code: "INVALID_PARAMS" } };
  }
  try {
    const grouped = await prisma.orderItem.groupBy({
      by: ["productId"],
      where: {
        order: { customerId: id }
      },
      _sum: {
        baseQty: true,
        subtotal: true
      },
      _count: {
        id: true
      },
      orderBy: {
        _count: { id: "desc" }
      },
      take: 10
    });
    if (grouped.length === 0) {
      return { data: [], error: null };
    }
    const productIds = grouped.map((g) => g.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds } },
      select: { id: true, name: true, baseUnit: true, grade: true }
    });
    const productMap = new Map(products.map((p) => [p.id, p]));
    const favorites = grouped.map((g) => {
      const product = productMap.get(g.productId);
      return {
        productId: g.productId,
        productName: (product == null ? void 0 : product.name) || `#${g.productId}`,
        baseUnit: (product == null ? void 0 : product.baseUnit) || "",
        grade: (product == null ? void 0 : product.grade) || null,
        totalQty: g._sum.baseQty || 0,
        totalAmount: g._sum.subtotal || 0,
        orderCount: g._count.id || 0
      };
    });
    return { data: favorites, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5E38\u8D2D\u82B1\u6750\u5931\u8D25", code: "FAVORITES_ERROR" }
    };
  }
});

export { favorites_get as default };
//# sourceMappingURL=favorites.get.mjs.map
