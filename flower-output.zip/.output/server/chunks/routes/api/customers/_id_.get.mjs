import { c as defineEventHandler, j as getRouterParam, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5BA2\u6237 ID", code: "INVALID_PARAMS" } };
  }
  try {
    const customer = await prisma.customer.findUnique({
      where: { id },
      include: {
        orders: {
          take: 10,
          orderBy: { createdAt: "desc" },
          include: {
            items: {
              select: {
                id: true,
                productId: true,
                qty: true,
                unit: true,
                unitPrice: true,
                subtotal: true
              }
            }
          }
        },
        payments: {
          take: 10,
          orderBy: { createdAt: "desc" }
        }
      }
    });
    if (!customer) {
      return { data: null, error: { message: "\u5BA2\u6237\u4E0D\u5B58\u5728", code: "NOT_FOUND" } };
    }
    return { data: customer, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5BA2\u6237\u8BE6\u60C5\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
