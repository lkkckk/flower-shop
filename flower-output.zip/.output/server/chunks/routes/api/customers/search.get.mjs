import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const search_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const keyword = query.keyword;
  const where = {};
  if (keyword) {
    where.OR = [
      { name: { contains: keyword } },
      { phone: { contains: keyword } }
    ];
  }
  try {
    const list = await prisma.customer.findMany({
      where,
      select: {
        id: true,
        name: true,
        phone: true,
        level: true,
        balance: true
      },
      orderBy: { updatedAt: "desc" },
      take: 20
    });
    return { data: { list }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u641C\u7D22\u5BA2\u6237\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map
