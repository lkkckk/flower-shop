import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const debtSummary_get = defineEventHandler(async () => {
  try {
    const customers = await prisma.customer.findMany({
      where: { balance: { lt: 0 } },
      orderBy: { balance: "asc" },
      select: {
        id: true,
        name: true,
        phone: true,
        level: true,
        balance: true,
        totalOwed: true
      }
    });
    return {
      data: { list: customers, total: customers.length },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u6B20\u6B3E\u6C47\u603B\u5931\u8D25", code: "DEBT_SUMMARY_ERROR" }
    };
  }
});

export { debtSummary_get as default };
//# sourceMappingURL=debt-summary.get.mjs.map
