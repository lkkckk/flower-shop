import { c as defineEventHandler, j as getRouterParam, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b;
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5BA2\u6237 ID", code: "INVALID_PARAMS" } };
  }
  const body = await readBody(event);
  const name = (body.name || "").trim();
  const phone = body.phone ? String(body.phone).trim() : null;
  const address = (_a = body.address) != null ? _a : null;
  const level = body.level || "normal";
  const notes = (_b = body.notes) != null ? _b : null;
  if (!name) {
    return { data: null, error: { message: "\u8BF7\u586B\u5199\u5BA2\u6237\u59D3\u540D", code: "INVALID_PARAMS" } };
  }
  if (!["normal", "member", "vip", "wholesale"].includes(level)) {
    return { data: null, error: { message: "\u5BA2\u6237\u7B49\u7EA7\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" } };
  }
  try {
    const existing = await prisma.customer.findUnique({ where: { id } });
    if (!existing) {
      return { data: null, error: { message: "\u5BA2\u6237\u4E0D\u5B58\u5728", code: "NOT_FOUND" } };
    }
    if (phone && phone !== existing.phone) {
      const conflict = await prisma.customer.findUnique({ where: { phone } });
      if (conflict && conflict.id !== id) {
        return {
          data: null,
          error: { message: "\u8BE5\u624B\u673A\u53F7\u5DF2\u88AB\u5176\u4ED6\u5BA2\u6237\u4F7F\u7528", code: "PHONE_EXISTS" }
        };
      }
    }
    const updated = await prisma.customer.update({
      where: { id },
      data: {
        name,
        phone,
        address,
        level,
        notes
      }
    });
    return { data: updated, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u66F4\u65B0\u5BA2\u6237\u5931\u8D25", code: "UPDATE_ERROR" }
    };
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
