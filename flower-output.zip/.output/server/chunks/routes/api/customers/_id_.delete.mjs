import { c as defineEventHandler, j as getRouterParam, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5BA2\u6237 ID", code: "INVALID_PARAMS" } };
  }
  try {
    const existing = await prisma.customer.findUnique({ where: { id } });
    if (!existing) {
      return { data: null, error: { message: "\u5BA2\u6237\u4E0D\u5B58\u5728", code: "NOT_FOUND" } };
    }
    const orderCount = await prisma.order.count({ where: { customerId: id } });
    if (orderCount > 0) {
      return {
        data: null,
        error: {
          message: `\u8BE5\u5BA2\u6237\u6709 ${orderCount} \u7B14\u5386\u53F2\u8BA2\u5355\uFF0C\u65E0\u6CD5\u5220\u9664`,
          code: "HAS_ORDERS"
        }
      };
    }
    await prisma.$transaction(async (tx) => {
      await tx.payment.deleteMany({ where: { customerId: id } });
      await tx.customer.delete({ where: { id } });
    });
    return { data: { success: true }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u5220\u9664\u5BA2\u6237\u5931\u8D25", code: "DELETE_ERROR" }
    };
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
