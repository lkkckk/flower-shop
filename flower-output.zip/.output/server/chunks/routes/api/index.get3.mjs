import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const onlyUnread = String(query.onlyUnread || "") === "true";
  const type = query.type ? String(query.type) : void 0;
  const level = query.level ? String(query.level) : void 0;
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 50;
  const where = { userId: null };
  if (onlyUnread) where.readAt = null;
  if (type) where.type = type;
  if (level) where.level = level;
  try {
    const [list, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: [{ readAt: { sort: "asc", nulls: "first" } }, { createdAt: "desc" }],
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: null, readAt: null } })
    ]);
    return { data: { list, total, page, pageSize, unreadCount }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u901A\u77E5\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
