import { c as defineEventHandler, j as getRouterParam, i as createError, p as prisma } from '../../../_/nitro.mjs';
import { c as computeReminderStage, d as daysUntil } from '../../../_/preorderReminder.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BA2\u5355 id" });
  try {
    const order = await prisma.order.findUnique({
      where: { id },
      include: {
        customer: true,
        items: {
          include: {
            product: {
              select: { id: true, name: true, imageUrl: true, baseUnit: true, grade: true, color: true, specification: true }
            },
            batch: { select: { id: true, batchNo: true, inboundDate: true } }
          }
        },
        payments: { orderBy: { createdAt: "desc" } }
      }
    });
    if (!order || order.orderType !== "preorder") {
      throw createError({ statusCode: 404, message: "\u9884\u552E\u5355\u4E0D\u5B58\u5728" });
    }
    const stage = computeReminderStage(order.deliveryTime);
    const days = daysUntil(order.deliveryTime);
    if (stage !== order.reminderStage) {
      await prisma.order.update({
        where: { id },
        data: { reminderStage: stage, reminderUpdatedAt: /* @__PURE__ */ new Date() }
      });
    }
    return {
      data: { ...order, reminderStage: stage, daysUntil: days },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u9884\u552E\u5355\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
