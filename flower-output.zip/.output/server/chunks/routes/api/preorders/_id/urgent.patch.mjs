import { c as defineEventHandler, j as getRouterParam, i as createError, r as readBody, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const urgent_patch = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BA2\u5355 id" });
  const body = await readBody(event);
  const existing = await prisma.order.findUnique({ where: { id } });
  if (!existing || existing.orderType !== "preorder") {
    throw createError({ statusCode: 404, message: "\u9884\u552E\u5355\u4E0D\u5B58\u5728" });
  }
  const order = await prisma.order.update({
    where: { id },
    data: { isUrgent: Boolean(body == null ? void 0 : body.isUrgent) },
    include: {
      customer: true,
      items: { include: { product: true } }
    }
  });
  return { data: order, error: null };
});

export { urgent_patch as default };
//# sourceMappingURL=urgent.patch.mjs.map
