import { c as defineEventHandler, j as getRouterParam, i as createError, r as readBody, p as prisma } from '../../../../_/nitro.mjs';
import { b as allocatePreorderItems } from '../../../../_/stockAllocator.mjs';
import { c as canTransition, i as isStockDeducted } from '../../../../_/preorderStatus.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const advance_post = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BA2\u5355 id" });
  const body = await readBody(event);
  const to = body == null ? void 0 : body.to;
  if (!to) throw createError({ statusCode: 400, message: "\u76EE\u6807\u72B6\u6001\u5FC5\u586B" });
  try {
    const result = await prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({ where: { id } });
      if (!order || order.orderType !== "preorder") {
        throw Object.assign(new Error("\u9884\u552E\u5355\u4E0D\u5B58\u5728"), { statusCode: 404 });
      }
      const from = order.status;
      if (!canTransition(from, to)) {
        throw Object.assign(new Error(`\u4E0D\u5141\u8BB8\u4ECE ${from} \u6D41\u8F6C\u5230 ${to}`), { statusCode: 400 });
      }
      if (to === "cancelled" && isStockDeducted(from)) {
        const items = await tx.orderItem.findMany({
          where: { orderId: id },
          select: { id: true, batchId: true, baseQty: true }
        });
        for (const it of items) {
          if (!it.batchId || !(it.baseQty > 0)) continue;
          const batch = await tx.stockBatch.findUnique({ where: { id: it.batchId } });
          if (!batch) {
            throw Object.assign(
              new Error(`\u5173\u8054\u6279\u6B21(id=${it.batchId})\u5DF2\u4E0D\u5B58\u5728\uFF0C\u65E0\u6CD5\u81EA\u52A8\u56DE\u8865\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458`),
              { statusCode: 400, code: "STOCK_REFUND_BATCH_MISSING" }
            );
          }
          await tx.stockBatch.update({
            where: { id: it.batchId },
            data: { currentQty: { increment: it.baseQty }, status: "in_stock" }
          });
          await tx.stockMovement.create({
            data: {
              batchId: it.batchId,
              type: "cancel_refund",
              qtyChange: it.baseQty,
              relatedOrderId: id,
              operator: "system",
              notes: `\u9884\u552E\u5355\u53D6\u6D88\u56DE\u8865 OrderItem#${it.id}`
            }
          });
        }
      }
      if (to === "in_production" && !isStockDeducted(from)) {
        await allocatePreorderItems(tx, id, "system");
      }
      const updated = await tx.order.update({
        where: { id },
        data: { status: to },
        include: { items: true, customer: true }
      });
      return updated;
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: {
        message: error.message || "\u72B6\u6001\u6D41\u8F6C\u5931\u8D25",
        code: error.code || "ADVANCE_FAILED",
        shortages: error.shortages || void 0
      }
    };
  }
});

export { advance_post as default };
//# sourceMappingURL=advance.post.mjs.map
