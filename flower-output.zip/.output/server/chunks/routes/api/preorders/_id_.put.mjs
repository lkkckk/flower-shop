import { c as defineEventHandler, j as getRouterParam, i as createError, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import { c as computeReminderStage } from '../../../_/preorderReminder.mjs';
import { i as isStockDeducted } from '../../../_/preorderStatus.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BA2\u5355 id" });
  const body = await readBody(event);
  try {
    const result = await prisma.$transaction(async (tx) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const existing = await tx.order.findUnique({ where: { id }, include: { items: true } });
      if (!existing || existing.orderType !== "preorder") {
        throw Object.assign(new Error("\u9884\u552E\u5355\u4E0D\u5B58\u5728"), { statusCode: 404 });
      }
      const status = existing.status;
      const stockLocked = isStockDeducted(status) || status === "cancelled";
      const update = {};
      if ("receiverName" in body) update.receiverName = body.receiverName || null;
      if ("receiverPhone" in body) update.receiverPhone = body.receiverPhone || null;
      if ("deliveryAddress" in body) update.deliveryAddress = body.deliveryAddress || null;
      if ("notes" in body) update.notes = body.notes || null;
      if ("cardMessage" in body) update.cardMessage = body.cardMessage || null;
      if ("sourceChannel" in body) update.sourceChannel = body.sourceChannel || null;
      if ("customerId" in body) update.customerId = body.customerId || null;
      if ("fulfillmentType" in body) update.fulfillmentType = body.fulfillmentType === "pickup" ? "pickup" : "delivery";
      if ("isMade" in body) update.isMade = Boolean(body.isMade);
      if ("isUrgent" in body) update.isUrgent = Boolean(body.isUrgent);
      if ("sortIndex" in body) update.sortIndex = Number(body.sortIndex) || 0;
      const allowedPriceModes = /* @__PURE__ */ new Set(["retail", "vip", "wholesale", "discount", "promotion", "custom"]);
      if ("priceMode" in body) update.priceMode = allowedPriceModes.has(body.priceMode) ? body.priceMode : "retail";
      if ("discountRate" in body) update.discountRate = body.discountRate === null ? null : Number(body.discountRate);
      if ("promotionId" in body) update.promotionId = body.promotionId ? Number(body.promotionId) : null;
      if ("deliveryTime" in body) {
        const t = new Date(body.deliveryTime);
        if (Number.isNaN(t.getTime())) throw new Error("\u5C65\u7EA6\u65E5\u671F\u683C\u5F0F\u9519\u8BEF");
        update.deliveryTime = t;
        update.reminderStage = computeReminderStage(t);
        update.reminderUpdatedAt = /* @__PURE__ */ new Date();
      }
      if (Array.isArray(body.items)) {
        if (stockLocked) {
          throw Object.assign(new Error("\u8BE5\u72B6\u6001\u4E0B\u4E0D\u5141\u8BB8\u4FEE\u6539\u5546\u54C1\u6E05\u5355"), { statusCode: 400 });
        }
        await tx.orderItem.deleteMany({ where: { orderId: id } });
        const productIds = Array.from(
          new Set(body.items.map((i) => Number(i.productId)).filter(Boolean))
        );
        const products = await tx.product.findMany({
          where: { id: { in: productIds } },
          select: { id: true, defaultPrice: true, imageUrl: true, grade: true, color: true }
        });
        const productMap = new Map(products.map((p) => [p.id, p]));
        let itemsSubtotal = 0;
        for (const it of body.items) {
          const p = productMap.get(Number(it.productId));
          if (!p) throw new Error(`\u5546\u54C1(id=${it.productId})\u4E0D\u5B58\u5728`);
          const unitPrice = Math.max(0, Number(it.unitPrice) || p.defaultPrice);
          const qty = Math.max(0, Number(it.qty) || 0);
          const subtotal = Math.max(0, Number(it.subtotal) || unitPrice * qty);
          itemsSubtotal += subtotal;
          await tx.orderItem.create({
            data: {
              orderId: id,
              productId: p.id,
              unit: it.unit || "default",
              baseQty: Math.max(0, Number(it.baseQty) || qty),
              qty,
              unitPrice,
              originalPrice: p.defaultPrice,
              subtotal,
              grade: (_b = (_a = it.grade) != null ? _a : p.grade) != null ? _b : null,
              color: (_d = (_c = it.color) != null ? _c : p.color) != null ? _d : null,
              notes: (_e = it.notes) != null ? _e : null,
              imageUrl: (_g = (_f = it.imageUrl) != null ? _f : p.imageUrl) != null ? _g : null
            }
          });
        }
        let totalAmount = itemsSubtotal;
        const nextPriceMode = update.priceMode || existing.priceMode;
        const nextPromotionId = "promotionId" in update ? update.promotionId : existing.promotionId;
        if (nextPriceMode === "promotion" && nextPromotionId) {
          const promotion = await tx.promotion.findUnique({ where: { id: nextPromotionId } });
          if (!promotion || promotion.status !== "active") throw new Error("\u6EE1\u51CF\u6D3B\u52A8\u4E0D\u5B58\u5728\u6216\u5DF2\u505C\u7528");
          if (itemsSubtotal < promotion.threshold) throw new Error("\u5F53\u524D\u5546\u54C1\u5C0F\u8BA1\u672A\u8FBE\u5230\u6EE1\u51CF\u95E8\u69DB");
          totalAmount = Math.max(0, itemsSubtotal - promotion.reduction);
        } else if (Number(body.totalAmount) >= 0) {
          totalAmount = Number(body.totalAmount);
        }
        update.totalAmount = totalAmount;
      } else if ("totalAmount" in body && Number(body.totalAmount) >= 0) {
        update.totalAmount = Number(body.totalAmount);
      }
      const updated = await tx.order.update({
        where: { id },
        data: update,
        include: { items: true, customer: true }
      });
      return updated;
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u66F4\u65B0\u9884\u552E\u5355\u5931\u8D25", code: "UPDATE_FAILED" }
    };
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
