import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import { d as daysUntil, c as computeReminderStage } from '../../../_/preorderReminder.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const upcoming_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const days = Number(query.days) || 7;
  const start = dayjs().startOf("day").toDate();
  const end = dayjs().add(days, "day").endOf("day").toDate();
  try {
    const list = await prisma.order.findMany({
      where: {
        orderType: "preorder",
        status: { notIn: ["completed", "cancelled"] },
        deliveryTime: { gte: start, lte: end }
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } }
      },
      orderBy: { deliveryTime: "asc" }
    });
    const now = /* @__PURE__ */ new Date();
    return {
      data: list.map((o) => ({
        ...o,
        reminderStage: computeReminderStage(o.deliveryTime, now),
        daysUntil: daysUntil(o.deliveryTime, now)
      })),
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5373\u5C06\u5C65\u7EA6\u9884\u552E\u5355\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { upcoming_get as default };
//# sourceMappingURL=upcoming.get.mjs.map
