import { c as defineEventHandler, k as getQuery, i as createError, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

function startOfDay(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}
function endOfDay(date) {
  const d = startOfDay(date);
  d.setDate(d.getDate() + 1);
  return d;
}
function toBaseQty(product, unit, qty) {
  var _a;
  if (!unit || unit === product.baseUnit) return qty;
  const conversion = (_a = product.unitConversions) == null ? void 0 : _a.find((u) => u.fromUnit === unit);
  return qty * Number((conversion == null ? void 0 : conversion.toBaseQty) || 1);
}
function addMaterial(materialMap, component, requiredQty, sources) {
  const current = materialMap.get(component.id) || {
    productId: component.id,
    productName: component.name || "\u672A\u547D\u540D\u5546\u54C1",
    imageUrl: component.imageUrl || "",
    baseUnit: component.baseUnit || "",
    requiredQty: 0,
    currentStock: 0,
    shortageQty: 0,
    sources: []
  };
  current.requiredQty += requiredQty;
  current.sources.push(...sources);
  materialMap.set(component.id, current);
}
const hot_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const targetDate = query.date ? new Date(String(query.date)) : /* @__PURE__ */ new Date();
  if (Number.isNaN(targetDate.getTime())) {
    throw createError({ statusCode: 400, message: "\u65E5\u671F\u683C\u5F0F\u9519\u8BEF" });
  }
  const orders = await prisma.order.findMany({
    where: {
      orderType: "preorder",
      status: { not: "cancelled" },
      deliveryTime: { gte: startOfDay(targetDate), lt: endOfDay(targetDate) }
    },
    include: {
      customer: true,
      items: {
        include: {
          product: {
            include: {
              unitConversions: true,
              recipe: {
                include: {
                  items: {
                    orderBy: { sort: "asc" },
                    include: {
                      componentProduct: { include: { unitConversions: true } }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    orderBy: [{ isMade: "asc" }, { deliveryTime: "asc" }, { createdAt: "asc" }]
  });
  const productMap = /* @__PURE__ */ new Map();
  const materialMap = /* @__PURE__ */ new Map();
  let totalQty = 0;
  let totalAmount = 0;
  let unmadeCount = 0;
  let madeCount = 0;
  let deliveryCount = 0;
  let pickupCount = 0;
  for (const order of orders) {
    totalAmount += Number(order.totalAmount || 0);
    if (order.isMade) madeCount += 1;
    else unmadeCount += 1;
    if (order.fulfillmentType === "pickup") pickupCount += 1;
    else deliveryCount += 1;
    for (const item of order.items) {
      const product = item.product;
      const recipeItems = ((_a = product == null ? void 0 : product.recipe) == null ? void 0 : _a.enabled) ? product.recipe.items || [] : [];
      const current = productMap.get(item.productId) || {
        productId: item.productId,
        productName: (product == null ? void 0 : product.name) || "\u672A\u547D\u540D\u5546\u54C1",
        imageUrl: item.imageUrl || (product == null ? void 0 : product.imageUrl) || "",
        orderIds: /* @__PURE__ */ new Set(),
        orderCount: 0,
        totalQty: 0,
        totalAmount: 0,
        unit: item.unit,
        hasRecipe: recipeItems.length > 0
      };
      current.orderIds.add(order.id);
      current.orderCount = current.orderIds.size;
      current.totalQty += Number(item.qty || 0);
      current.totalAmount += Number(item.subtotal || 0);
      current.hasRecipe = current.hasRecipe || recipeItems.length > 0;
      totalQty += Number(item.qty || 0);
      productMap.set(item.productId, current);
      for (const recipeItem of recipeItems) {
        const component = recipeItem.componentProduct;
        const requiredQty = toBaseQty(component, recipeItem.unit, Number(item.baseQty || item.qty || 0) * Number(recipeItem.qty || 0));
        addMaterial(materialMap, component, requiredQty, [{
          orderId: order.id,
          orderNo: order.orderNo,
          productId: item.productId,
          productName: (product == null ? void 0 : product.name) || "\u672A\u547D\u540D\u5546\u54C1",
          qty: Number(item.qty || 0)
        }]);
      }
    }
  }
  const materialIds = Array.from(materialMap.keys());
  if (materialIds.length > 0) {
    const materialStocks = await prisma.product.findMany({
      where: { id: { in: materialIds } },
      include: {
        stockBatches: {
          where: { status: "in_stock", currentQty: { gt: 0 } },
          select: { currentQty: true }
        }
      }
    });
    for (const product of materialStocks) {
      const row = materialMap.get(product.id);
      if (row) {
        row.currentStock = product.stockBatches.reduce((sum, batch) => sum + Number(batch.currentQty || 0), 0);
        row.shortageQty = Math.max(0, row.requiredQty - row.currentStock);
      }
    }
  }
  const productRows = Array.from(productMap.values()).map(({ orderIds, ...row }) => row).sort((a, b) => b.totalQty - a.totalQty);
  const materialRows = Array.from(materialMap.values()).map((row) => ({
    ...row,
    sources: row.sources.slice(0, 6)
  })).sort((a, b) => b.shortageQty - a.shortageQty || b.requiredQty - a.requiredQty);
  const orderRows = orders.map((order) => {
    var _a2, _b;
    return {
      id: order.id,
      orderNo: order.orderNo,
      receiverName: order.receiverName || ((_a2 = order.customer) == null ? void 0 : _a2.name) || "\u6563\u5BA2",
      receiverPhone: order.receiverPhone || ((_b = order.customer) == null ? void 0 : _b.phone) || "",
      deliveryTime: order.deliveryTime,
      fulfillmentType: order.fulfillmentType,
      totalAmount: order.totalAmount,
      status: order.status,
      isMade: order.isMade,
      isUrgent: order.isUrgent,
      itemCount: order.items.length,
      items: order.items.map((item) => {
        var _a3, _b2, _c, _d, _e;
        return {
          id: item.id,
          productId: item.productId,
          productName: ((_a3 = item.product) == null ? void 0 : _a3.name) || "\u672A\u547D\u540D\u5546\u54C1",
          imageUrl: item.imageUrl || ((_b2 = item.product) == null ? void 0 : _b2.imageUrl) || "",
          qty: item.qty,
          unit: item.unit,
          hasRecipe: Boolean(((_d = (_c = item.product) == null ? void 0 : _c.recipe) == null ? void 0 : _d.enabled) && ((_e = item.product.recipe.items) == null ? void 0 : _e.length))
        };
      })
    };
  });
  return {
    data: productRows,
    productRows,
    materialRows,
    orders: orderRows,
    summary: {
      orderCount: orders.length,
      totalQty,
      totalAmount,
      unmadeCount,
      madeCount,
      deliveryCount,
      pickupCount,
      shortageCount: materialRows.filter((row) => row.shortageQty > 0).length
    },
    error: null
  };
});

export { hot_get as default };
//# sourceMappingURL=hot.get.mjs.map
