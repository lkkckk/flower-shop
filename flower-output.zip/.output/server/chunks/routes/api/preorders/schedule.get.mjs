import { c as defineEventHandler, k as getQuery, i as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const MS_PER_DAY = 24 * 60 * 60 * 1e3;
function startOfDay(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}
function endOfDay(date) {
  const d = startOfDay(date);
  d.setDate(d.getDate() + 1);
  return d;
}
function parseBoolean(value) {
  if (value === "true") return true;
  if (value === "false") return false;
  return void 0;
}
function formatDateLabel(value) {
  if (!value) return "";
  return value.toLocaleDateString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
}
function formatTimeLabel(value) {
  if (!value) return "";
  return value.toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
}
function normalizeOrder(order) {
  var _a, _b, _c, _d;
  const firstItem = (_a = order.items) == null ? void 0 : _a[0];
  return {
    id: order.id,
    orderNo: order.orderNo,
    receiverName: order.receiverName || ((_b = order.customer) == null ? void 0 : _b.name) || "\u6563\u5BA2",
    receiverPhone: order.receiverPhone || ((_c = order.customer) == null ? void 0 : _c.phone) || "",
    deliveryTime: order.deliveryTime,
    dateLabel: formatDateLabel(order.deliveryTime),
    timeLabel: formatTimeLabel(order.deliveryTime),
    fulfillmentType: order.fulfillmentType,
    deliveryAddress: order.deliveryAddress,
    totalAmount: order.totalAmount,
    status: order.status,
    isMade: order.isMade,
    isUrgent: order.isUrgent,
    sourceChannel: order.sourceChannel,
    cardMessage: order.cardMessage,
    notes: order.notes,
    coverImage: (firstItem == null ? void 0 : firstItem.imageUrl) || ((_d = firstItem == null ? void 0 : firstItem.product) == null ? void 0 : _d.imageUrl) || "",
    customer: order.customer,
    items: (order.items || []).map((item) => {
      var _a2, _b2;
      return {
        id: item.id,
        productId: item.productId,
        productName: ((_a2 = item.product) == null ? void 0 : _a2.name) || "\u672A\u547D\u540D\u5546\u54C1",
        imageUrl: item.imageUrl || ((_b2 = item.product) == null ? void 0 : _b2.imageUrl) || "",
        qty: item.qty,
        unit: item.unit,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
        notes: item.notes
      };
    })
  };
}
const schedule_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const view = String(query.view || "today");
  const keyword = String(query.keyword || "").trim();
  const fulfillmentType = String(query.fulfillmentType || "").trim();
  const isMade = parseBoolean(query.isMade);
  const status = String(query.status || "").trim();
  const baseDate = query.date ? new Date(String(query.date)) : /* @__PURE__ */ new Date();
  if (Number.isNaN(baseDate.getTime())) {
    throw createError({ statusCode: 400, message: "\u65E5\u671F\u683C\u5F0F\u9519\u8BEF" });
  }
  const where = {
    orderType: "preorder",
    status: { not: "cancelled" }
  };
  if (status) where.status = status;
  if (fulfillmentType === "delivery" || fulfillmentType === "pickup") where.fulfillmentType = fulfillmentType;
  if (typeof isMade === "boolean") where.isMade = isMade;
  if (view === "today") {
    where.deliveryTime = { gte: startOfDay(baseDate), lt: endOfDay(baseDate) };
  } else if (view === "tomorrow") {
    const tomorrow = new Date(startOfDay(baseDate).getTime() + MS_PER_DAY);
    where.deliveryTime = { gte: tomorrow, lt: endOfDay(tomorrow) };
  } else if (view === "future") {
    where.deliveryTime = { gte: endOfDay(baseDate) };
  } else if (view !== "all") {
    where.deliveryTime = { gte: startOfDay(baseDate), lt: endOfDay(baseDate) };
  }
  if (keyword) {
    where.OR = [
      { orderNo: { contains: keyword, mode: "insensitive" } },
      { receiverName: { contains: keyword, mode: "insensitive" } },
      { receiverPhone: { contains: keyword, mode: "insensitive" } },
      { deliveryAddress: { contains: keyword, mode: "insensitive" } },
      { notes: { contains: keyword, mode: "insensitive" } },
      { cardMessage: { contains: keyword, mode: "insensitive" } },
      { sourceChannel: { contains: keyword, mode: "insensitive" } },
      { customer: { is: { name: { contains: keyword, mode: "insensitive" } } } },
      { customer: { is: { phone: { contains: keyword, mode: "insensitive" } } } }
    ];
  }
  const orders = await prisma.order.findMany({
    where,
    include: {
      customer: true,
      items: { include: { product: true } }
    },
    orderBy: [
      { isUrgent: "desc" },
      { isMade: "asc" },
      { deliveryTime: "asc" },
      { sortIndex: "asc" },
      { createdAt: "asc" }
    ]
  });
  return {
    data: orders.map(normalizeOrder),
    error: null
  };
});

export { schedule_get as default };
//# sourceMappingURL=schedule.get.mjs.map
