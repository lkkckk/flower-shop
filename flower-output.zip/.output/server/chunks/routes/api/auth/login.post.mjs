import { c as defineEventHandler, r as readBody, p as prisma, v as verifyPassword, e as signToken, g as getHeader, f as getRequestIP } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

var _a;
const WINDOW_MS = 15 * 60 * 1e3;
const MAX_FAILS = 10;
const buckets = (_a = globalThis.__loginRateLimit) != null ? _a : globalThis.__loginRateLimit = /* @__PURE__ */ new Map();
function getClientKey(event) {
  var _a2;
  const xff = getHeader(event, "x-forwarded-for");
  return ((_a2 = xff == null ? void 0 : xff.split(",")[0]) == null ? void 0 : _a2.trim()) || getRequestIP(event, { xForwardedFor: true }) || "unknown";
}
function readBucket(key) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    const fresh = { failed: 0, resetAt: now + WINDOW_MS };
    buckets.set(key, fresh);
    return fresh;
  }
  return b;
}
const login_post = defineEventHandler(async (event) => {
  const clientKey = getClientKey(event);
  const bucket = readBucket(clientKey);
  if (bucket.failed >= MAX_FAILS) {
    return {
      data: null,
      error: {
        message: "\u767B\u5F55\u5931\u8D25\u6B21\u6570\u8FC7\u591A\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5",
        code: "RATE_LIMITED",
        retryAfterSec: Math.max(0, Math.ceil((bucket.resetAt - Date.now()) / 1e3))
      }
    };
  }
  const body = await readBody(event);
  const username = ((body == null ? void 0 : body.username) || "").trim();
  const password = (body == null ? void 0 : body.password) || "";
  if (!username || !password) {
    return { data: null, error: { message: "\u7528\u6237\u540D\u548C\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A", code: "BAD_PARAMS" } };
  }
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user) {
    bucket.failed += 1;
    return { data: null, error: { message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF", code: "INVALID_CREDENTIALS" } };
  }
  if (user.status !== "active") {
    return { data: null, error: { message: "\u8D26\u53F7\u5DF2\u88AB\u505C\u7528", code: "USER_DISABLED" } };
  }
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    bucket.failed += 1;
    return { data: null, error: { message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF", code: "INVALID_CREDENTIALS" } };
  }
  buckets.delete(clientKey);
  const token = signToken({ sub: user.id, type: "staff", role: user.role });
  return {
    data: {
      token,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role,
        status: user.status
      }
    },
    error: null
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
