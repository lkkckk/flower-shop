import { c as defineEventHandler, h as getCurrentUser, i as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const me_get = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized",
      data: { message: "\u672A\u767B\u5F55\u6216\u51ED\u8BC1\u5DF2\u8FC7\u671F", code: "UNAUTHORIZED" }
    });
  }
  if (payload.type === "staff") {
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, username: true, name: true, role: true, status: true }
    });
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Unauthorized",
        data: { message: "\u7528\u6237\u4E0D\u5B58\u5728", code: "USER_NOT_FOUND" }
      });
    }
    if (user.status !== "active") {
      throw createError({
        statusCode: 403,
        statusMessage: "Forbidden",
        data: { message: "\u8D26\u53F7\u5DF2\u88AB\u505C\u7528", code: "USER_DISABLED" }
      });
    }
    return { data: { type: "staff", user }, error: null };
  }
  const customer = await prisma.customer.findUnique({
    where: { id: payload.sub },
    select: {
      id: true,
      name: true,
      phone: true,
      level: true,
      balance: true,
      totalOwed: true,
      points: true,
      openid: true,
      nickname: true,
      avatarUrl: true
    }
  });
  if (!customer) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized",
      data: { message: "\u987E\u5BA2\u4E0D\u5B58\u5728", code: "CUSTOMER_NOT_FOUND" }
    });
  }
  return { data: { type: "customer", customer }, error: null };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
