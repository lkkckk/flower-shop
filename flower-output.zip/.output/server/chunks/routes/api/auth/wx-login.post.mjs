import { c as defineEventHandler, r as readBody, p as prisma, e as signToken } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const wxLogin_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const code = ((body == null ? void 0 : body.code) || "").trim();
  if (!code) {
    return { data: null, error: { message: "\u7F3A\u5C11 code \u53C2\u6570", code: "BAD_PARAMS" } };
  }
  const appid = process.env.WECHAT_APPID;
  const secret = process.env.WECHAT_SECRET;
  let openid = "";
  let unionid;
  if (!appid || !secret) {
    if (code.startsWith("dev-")) {
      openid = code;
      console.warn("[wx-login] \u4F7F\u7528\u5F00\u53D1\u6A21\u5F0F\u5047 openid:", openid);
    } else {
      return {
        data: null,
        error: { message: "\u540E\u7AEF\u672A\u914D\u7F6E\u5FAE\u4FE1\u5C0F\u7A0B\u5E8F\u51ED\u8BC1 (WECHAT_APPID/WECHAT_SECRET)", code: "WECHAT_NOT_CONFIGURED" }
      };
    }
  } else {
    try {
      const url = `https://api.weixin.qq.com/sns/jscode2session?appid=${appid}&secret=${secret}&js_code=${code}&grant_type=authorization_code`;
      const resp = await $fetch(url);
      if (resp.errcode) {
        return {
          data: null,
          error: {
            message: `\u5FAE\u4FE1\u767B\u5F55\u5931\u8D25: ${resp.errmsg || "unknown"}`,
            code: `WX_${resp.errcode}`
          }
        };
      }
      openid = resp.openid || "";
      unionid = resp.unionid;
    } catch (e) {
      return { data: null, error: { message: "\u8C03\u7528\u5FAE\u4FE1\u63A5\u53E3\u5931\u8D25", code: "WX_REQUEST_FAILED" } };
    }
  }
  if (!openid) {
    return { data: null, error: { message: "\u672A\u80FD\u83B7\u53D6 openid", code: "NO_OPENID" } };
  }
  let customer = await prisma.customer.findUnique({ where: { openid } });
  if (!customer) {
    customer = await prisma.customer.create({
      data: {
        name: ((_a = body == null ? void 0 : body.userInfo) == null ? void 0 : _a.nickName) || "\u5FAE\u4FE1\u7528\u6237",
        level: "normal",
        openid,
        unionid,
        nickname: (_b = body == null ? void 0 : body.userInfo) == null ? void 0 : _b.nickName,
        avatarUrl: (_c = body == null ? void 0 : body.userInfo) == null ? void 0 : _c.avatarUrl
      }
    });
  } else if (body == null ? void 0 : body.userInfo) {
    const patch = {};
    if (body.userInfo.nickName && body.userInfo.nickName !== customer.nickname) {
      patch.nickname = body.userInfo.nickName;
    }
    if (body.userInfo.avatarUrl && body.userInfo.avatarUrl !== customer.avatarUrl) {
      patch.avatarUrl = body.userInfo.avatarUrl;
    }
    if (Object.keys(patch).length > 0) {
      customer = await prisma.customer.update({ where: { id: customer.id }, data: patch });
    }
  }
  const token = signToken({ sub: customer.id, type: "customer" });
  return {
    data: {
      token,
      customer: {
        id: customer.id,
        name: customer.name,
        phone: customer.phone,
        level: customer.level,
        balance: customer.balance,
        points: customer.points,
        nickname: customer.nickname,
        avatarUrl: customer.avatarUrl
      }
    },
    error: null
  };
});

export { wxLogin_post as default };
//# sourceMappingURL=wx-login.post.mjs.map
