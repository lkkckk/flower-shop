import { c as defineEventHandler, h as getCurrentUser, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  const isCashier = (payload == null ? void 0 : payload.type) === "staff" && (payload == null ? void 0 : payload.role) === "cashier";
  try {
    const rows = isCashier ? await prisma.setting.findMany({ where: { key: "lowStockThreshold" } }) : await prisma.setting.findMany();
    const map = {};
    for (const r of rows) map[r.key] = r.value;
    const defaults = isCashier ? { lowStockThreshold: "20" } : {
      lowStockThreshold: "20",
      expiringDays: "3",
      debtOverdueDays: "30",
      safetyStockDays: "5",
      notificationQuietStart: "22:00",
      notificationQuietEnd: "08:00"
    };
    for (const [key, value] of Object.entries(defaults)) {
      if (!(key in map)) map[key] = value;
    }
    return { data: map, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u8BFB\u53D6\u8BBE\u7F6E\u5931\u8D25", code: "FETCH_ERROR" } };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get8.mjs.map
