import { c as defineEventHandler, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const inbound_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const productId = Number(body.productId);
  const inboundQty = Number(body.inboundQty);
  const costPrice = Number(body.costPrice);
  const notes = body.notes;
  const inboundDateRaw = body.inboundDate;
  if (!productId || !inboundDateRaw || !(inboundQty > 0) || costPrice < 0 || Number.isNaN(costPrice)) {
    return {
      data: null,
      error: { message: "\u5165\u5E93\u53C2\u6570\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" }
    };
  }
  try {
    const batch = await prisma.$transaction(async (tx) => {
      const product = await tx.product.findUnique({ where: { id: productId } });
      if (!product) throw new Error("\u5546\u54C1\u4E0D\u5B58\u5728");
      const inboundDate = dayjs(inboundDateRaw).startOf("day").toDate();
      const expiryDate = body.expiryDate ? dayjs(body.expiryDate).startOf("day").toDate() : dayjs(inboundDate).add(product.shelfLifeDays, "day").toDate();
      const dayStart = dayjs(inboundDate).startOf("day").toDate();
      const dayEnd = dayjs(inboundDate).endOf("day").toDate();
      const todayCount = await tx.stockBatch.count({
        where: {
          inboundDate: { gte: dayStart, lte: dayEnd }
        }
      });
      const dateStr = dayjs(inboundDate).format("YYYYMMDD");
      const batchNo = `B${dateStr}${(todayCount + 1).toString().padStart(3, "0")}`;
      const created = await tx.stockBatch.create({
        data: {
          productId,
          batchNo,
          inboundDate,
          expiryDate,
          inboundQty,
          currentQty: inboundQty,
          costPrice,
          status: "in_stock",
          notes: notes || null
        },
        include: {
          product: true
        }
      });
      await tx.stockMovement.create({
        data: {
          batchId: created.id,
          type: "inbound",
          qtyChange: inboundQty,
          operator: "system",
          notes: notes || null
        }
      });
      return created;
    });
    return {
      data: batch,
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u5165\u5E93\u5931\u8D25", code: "INBOUND_FAILED" }
    };
  }
});

export { inbound_post as default };
//# sourceMappingURL=inbound.post.mjs.map
