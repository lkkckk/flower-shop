import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id)) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u6279\u6B21 ID", code: "INVALID_ID" } };
  }
  try {
    const orderItemCount = await prisma.orderItem.count({ where: { batchId: id } });
    if (orderItemCount > 0) {
      return {
        data: null,
        error: { message: `\u8BE5\u6279\u6B21\u5DF2\u6709 ${orderItemCount} \u6761\u9500\u552E\u8BB0\u5F55\uFF0C\u4E0D\u80FD\u5220\u9664`, code: "HAS_ORDER_ITEMS" }
      };
    }
    await prisma.$transaction(async (tx) => {
      await tx.stockMovement.deleteMany({ where: { batchId: id } });
      await tx.stockBatch.delete({ where: { id } });
    });
    return { data: { success: true }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u5220\u9664\u5931\u8D25", code: "DELETE_ERROR" }
    };
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
