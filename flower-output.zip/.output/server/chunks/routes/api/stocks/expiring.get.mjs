import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const expiring_get = defineEventHandler(async () => {
  try {
    const now = dayjs();
    const todayStart = now.startOf("day").toDate();
    const threshold = now.add(3, "day").endOf("day").toDate();
    const expiring = await prisma.stockBatch.findMany({
      where: {
        status: "in_stock",
        currentQty: { gt: 0 },
        expiryDate: { gte: todayStart, lte: threshold }
      },
      include: { product: true },
      orderBy: { expiryDate: "asc" }
    });
    const expired = await prisma.stockBatch.findMany({
      where: {
        status: "in_stock",
        currentQty: { gt: 0 },
        expiryDate: { lt: todayStart }
      },
      include: { product: true },
      orderBy: { expiryDate: "asc" }
    });
    return {
      data: { expiring, expired },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u4E34\u671F\u6279\u6B21\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { expiring_get as default };
//# sourceMappingURL=expiring.get.mjs.map
