import { c as defineEventHandler, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const scrap_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const batchId = Number(body.batchId);
  const qty = Number(body.qty);
  const reason = body.reason ? String(body.reason) : null;
  if (!batchId || isNaN(batchId)) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u6279\u6B21 ID", code: "INVALID_PARAMS" } };
  }
  if (!(qty > 0)) {
    return { data: null, error: { message: "\u62A5\u635F\u6570\u91CF\u5FC5\u987B\u5927\u4E8E 0", code: "INVALID_PARAMS" } };
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const batch = await tx.stockBatch.findUnique({ where: { id: batchId } });
      if (!batch) throw new Error("\u6279\u6B21\u4E0D\u5B58\u5728");
      if (batch.status !== "in_stock") throw new Error("\u8BE5\u6279\u6B21\u72B6\u6001\u4E0D\u5141\u8BB8\u62A5\u635F");
      if (qty > batch.currentQty) throw new Error(`\u62A5\u635F\u6570\u91CF\u4E0D\u80FD\u8D85\u8FC7\u5F53\u524D\u5E93\u5B58 (${batch.currentQty})`);
      const newQty = batch.currentQty - qty;
      const updatedBatch = await tx.stockBatch.update({
        where: { id: batchId },
        data: {
          currentQty: newQty,
          status: newQty <= 0 ? "scrapped" : "in_stock"
        }
      });
      const movement = await tx.stockMovement.create({
        data: {
          batchId,
          type: "scrap",
          qtyChange: -qty,
          notes: reason,
          operator: "system"
        }
      });
      return { batch: updatedBatch, movement };
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u62A5\u635F\u5931\u8D25", code: "SCRAP_FAILED" }
    };
  }
});

export { scrap_post as default };
//# sourceMappingURL=scrap.post.mjs.map
