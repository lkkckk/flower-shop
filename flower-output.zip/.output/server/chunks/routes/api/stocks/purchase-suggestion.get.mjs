import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const purchaseSuggestion_get = defineEventHandler(async () => {
  var _a, _b;
  try {
    const setting = await prisma.setting.findUnique({ where: { key: "safetyStockDays" } });
    const safetyDays = Math.max(1, Number(setting == null ? void 0 : setting.value) || 5);
    const since = dayjs().subtract(7, "day").startOf("day").toDate();
    const [activeProducts, sales, stockAgg] = await Promise.all([
      prisma.product.findMany({
        where: { status: "active" },
        select: { id: true, name: true, baseUnit: true, grade: true, imageUrl: true }
      }),
      prisma.orderItem.groupBy({
        by: ["productId"],
        where: {
          order: { createdAt: { gte: since }, status: { not: "cancelled" } }
        },
        _sum: { baseQty: true }
      }),
      prisma.stockBatch.groupBy({
        by: ["productId"],
        where: { status: { in: ["in_stock", "discounted"] } },
        _sum: { currentQty: true }
      })
    ]);
    const salesMap = /* @__PURE__ */ new Map();
    for (const r of sales) salesMap.set(r.productId, (_a = r._sum.baseQty) != null ? _a : 0);
    const stockMap = /* @__PURE__ */ new Map();
    for (const r of stockAgg) stockMap.set(r.productId, (_b = r._sum.currentQty) != null ? _b : 0);
    const suggestions = activeProducts.map((p) => {
      var _a2, _b2;
      const weeklySales = (_a2 = salesMap.get(p.id)) != null ? _a2 : 0;
      const dailyAvg = weeklySales / 7;
      const suggestedStock = Math.ceil(dailyAvg * safetyDays);
      const currentStock = (_b2 = stockMap.get(p.id)) != null ? _b2 : 0;
      const gap = Math.max(0, suggestedStock - Math.floor(currentStock));
      return {
        productId: p.id,
        productName: p.name,
        baseUnit: p.baseUnit,
        grade: p.grade,
        imageUrl: p.imageUrl,
        weeklySales,
        dailyAvg: Number(dailyAvg.toFixed(2)),
        currentStock,
        suggestedStock,
        gap
      };
    }).filter((row) => row.gap > 0).sort((a, b) => b.gap - a.gap);
    return {
      data: { list: suggestions, safetyDays },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u91C7\u8D2D\u5EFA\u8BAE\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { purchaseSuggestion_get as default };
//# sourceMappingURL=purchase-suggestion.get.mjs.map
