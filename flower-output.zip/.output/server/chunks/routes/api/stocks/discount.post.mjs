import { c as defineEventHandler, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const discount_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const batchId = Number(body.batchId);
  const discountPrice = Number(body.discountPrice);
  const reason = body.reason ? String(body.reason) : null;
  if (!batchId || isNaN(batchId)) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u6279\u6B21 ID", code: "INVALID_PARAMS" } };
  }
  if (isNaN(discountPrice) || discountPrice < 0) {
    return { data: null, error: { message: "\u6298\u4EF7\u91D1\u989D\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" } };
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const batch = await tx.stockBatch.findUnique({ where: { id: batchId } });
      if (!batch) throw new Error("\u6279\u6B21\u4E0D\u5B58\u5728");
      if (batch.status !== "in_stock") throw new Error("\u8BE5\u6279\u6B21\u72B6\u6001\u4E0D\u5141\u8BB8\u6298\u4EF7");
      const updatedBatch = await tx.stockBatch.update({
        where: { id: batchId },
        data: {
          status: "discounted"
        }
      });
      const movement = await tx.stockMovement.create({
        data: {
          batchId,
          type: "discount",
          qtyChange: 0,
          notes: `\u6298\u4EF7\u81F3 \xA5${discountPrice}${reason ? "\uFF1A" + reason : ""}`,
          operator: "system"
        }
      });
      return { batch: updatedBatch, movement };
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u6298\u4EF7\u5931\u8D25", code: "DISCOUNT_FAILED" }
    };
  }
});

export { discount_post as default };
//# sourceMappingURL=discount.post.mjs.map
