import { c as defineEventHandler, h as getCurrentUser, r as readBody, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const adjust_post = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload) return { data: null, error: { message: "\u672A\u767B\u5F55", code: "UNAUTHORIZED" } };
  const body = await readBody(event);
  const productId = Number(body == null ? void 0 : body.productId);
  const actualQty = Number(body == null ? void 0 : body.actualQty);
  const reason = ((body == null ? void 0 : body.reason) || "").trim() || "\u76D8\u70B9\u8C03\u6574";
  if (!productId) return { data: null, error: { message: "\u5546\u54C1 ID \u5FC5\u586B", code: "BAD_PARAMS" } };
  if (!(actualQty >= 0)) {
    return { data: null, error: { message: "\u5B9E\u9645\u6570\u91CF\u5FC5\u987B >= 0", code: "BAD_PARAMS" } };
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const product = await tx.product.findUnique({ where: { id: productId } });
      if (!product) throw new Error("\u5546\u54C1\u4E0D\u5B58\u5728");
      const batches = await tx.stockBatch.findMany({
        where: { productId, status: "in_stock", currentQty: { gt: 0 } },
        orderBy: { inboundDate: "desc" }
        // 盘亏从新批次倒扣（避免动老批次的可追溯效期）
      });
      const systemQty = batches.reduce((s, b) => s + b.currentQty, 0);
      const delta = actualQty - systemQty;
      if (Math.abs(delta) < 1e-6) {
        return {
          productId,
          systemQty,
          actualQty,
          delta: 0,
          message: "\u7CFB\u7EDF\u5E93\u5B58\u4E0E\u5B9E\u9645\u4E00\u81F4\uFF0C\u65E0\u9700\u8C03\u6574"
        };
      }
      const operator = payload.sub ? `user#${payload.sub}` : void 0;
      if (delta < 0) {
        let remaining = -delta;
        for (const b of batches) {
          if (remaining <= 0) break;
          const take = Math.min(b.currentQty, remaining);
          const newQty = b.currentQty - take;
          await tx.stockBatch.update({
            where: { id: b.id },
            data: {
              currentQty: newQty,
              status: newQty <= 0 ? "sold_out" : b.status
            }
          });
          await tx.stockMovement.create({
            data: {
              batchId: b.id,
              type: "stocktake_loss",
              qtyChange: -take,
              operator,
              notes: reason
            }
          });
          remaining -= take;
        }
      } else {
        const batchNo = `STK-${productId}-${Date.now()}`;
        const now = /* @__PURE__ */ new Date();
        const expiryDate = new Date(now);
        expiryDate.setDate(expiryDate.getDate() + (product.shelfLifeDays || 7));
        const batch = await tx.stockBatch.create({
          data: {
            productId,
            batchNo,
            inboundDate: now,
            expiryDate,
            inboundQty: delta,
            currentQty: delta,
            costPrice: 0,
            status: "in_stock",
            notes: `[\u76D8\u76C8] ${reason}`
          }
        });
        await tx.stockMovement.create({
          data: {
            batchId: batch.id,
            type: "stocktake_gain",
            qtyChange: delta,
            operator,
            notes: reason
          }
        });
      }
      return { productId, systemQty, actualQty, delta };
    });
    return { data: result, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u76D8\u70B9\u8C03\u6574\u5931\u8D25", code: "ADJUST_ERROR" } };
  }
});

export { adjust_post as default };
//# sourceMappingURL=adjust.post.mjs.map
