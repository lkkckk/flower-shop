import { c as defineEventHandler, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const summary_get = defineEventHandler(async () => {
  var _a;
  try {
    const [setting, products] = await Promise.all([
      prisma.setting.findUnique({ where: { key: "lowStockThreshold" } }),
      prisma.product.findMany({
        where: { status: "active" },
        include: {
          stockBatches: {
            where: { status: "in_stock", currentQty: { gt: 0 } },
            select: { currentQty: true, expiryDate: true }
          }
        },
        orderBy: { name: "asc" }
      })
    ]);
    const threshold = Number((_a = setting == null ? void 0 : setting.value) != null ? _a : 20) || 20;
    const items = products.map((p) => {
      const totalStock = p.stockBatches.reduce((s, b) => s + b.currentQty, 0);
      const oldestExpiry = p.stockBatches.reduce((min, b) => {
        if (!min) return b.expiryDate;
        return b.expiryDate < min ? b.expiryDate : min;
      }, null);
      return {
        id: p.id,
        name: p.name,
        category: p.category,
        baseUnit: p.baseUnit,
        specification: p.specification,
        imageUrl: p.imageUrl,
        totalStock,
        threshold,
        isLow: totalStock < threshold,
        oldestExpiry
      };
    });
    const lowStockCount = items.filter((it) => it.isLow).length;
    return { data: { items, lowStockCount, threshold }, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u83B7\u53D6\u76D8\u70B9\u6570\u636E\u5931\u8D25", code: "FETCH_ERROR" } };
  }
});

export { summary_get as default };
//# sourceMappingURL=summary.get.mjs.map
