import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const summary_get = defineEventHandler(async () => {
  var _a, _b, _c, _d;
  try {
    const expiringThreshold = dayjs().add(3, "day").endOf("day").toDate();
    const now = /* @__PURE__ */ new Date();
    const [skuCount, batches, productsAgg, productsTotal] = await Promise.all([
      prisma.product.count({ where: { status: "active" } }),
      prisma.stockBatch.findMany({
        where: { status: { in: ["in_stock", "discounted"] } },
        select: { currentQty: true, costPrice: true, expiryDate: true }
      }),
      prisma.stockBatch.groupBy({
        by: ["productId"],
        where: { status: { in: ["in_stock", "discounted"] } },
        _sum: { currentQty: true }
      }),
      prisma.product.findMany({
        where: { status: "active" },
        select: { id: true }
      })
    ]);
    let totalValue = 0;
    let expiringCount = 0;
    for (const b of batches) {
      const qty = (_a = b.currentQty) != null ? _a : 0;
      const price = (_b = b.costPrice) != null ? _b : 0;
      totalValue += qty * price;
      if (qty > 0 && b.expiryDate && b.expiryDate >= now && b.expiryDate <= expiringThreshold) {
        expiringCount += 1;
      }
    }
    const stockMap = /* @__PURE__ */ new Map();
    for (const a of productsAgg) {
      stockMap.set(a.productId, (_c = a._sum.currentQty) != null ? _c : 0);
    }
    let outOfStockCount = 0;
    for (const p of productsTotal) {
      if (((_d = stockMap.get(p.id)) != null ? _d : 0) <= 0) outOfStockCount += 1;
    }
    return {
      data: {
        skuCount,
        totalValue,
        expiringCount,
        outOfStockCount
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5E93\u5B58\u5927\u76D8\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { summary_get as default };
//# sourceMappingURL=summary.get.mjs.map
