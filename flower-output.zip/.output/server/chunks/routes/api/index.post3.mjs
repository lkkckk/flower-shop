import { c as defineEventHandler, r as readBody, i as createError, p as prisma } from '../../_/nitro.mjs';
import { c as computeReminderStage } from '../../_/preorderReminder.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

function formatLocalDateKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}${m}${d}`;
}
function getErrorMessage(error) {
  if ((error == null ? void 0 : error.code) === "P2002") return "\u8BA2\u5355\u53F7\u51B2\u7A81\uFF0C\u8BF7\u91CD\u8BD5";
  return (error == null ? void 0 : error.message) || "\u521B\u5EFA\u9884\u552E\u5355\u5931\u8D25";
}
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!(body == null ? void 0 : body.deliveryTime)) {
    throw createError({ statusCode: 400, message: "\u5C65\u7EA6\u65E5\u671F\u5FC5\u586B" });
  }
  if (!Array.isArray(body.items) || body.items.length === 0) {
    throw createError({ statusCode: 400, message: "\u5546\u54C1\u4E0D\u80FD\u4E3A\u7A7A" });
  }
  const deliveryTime = new Date(body.deliveryTime);
  if (Number.isNaN(deliveryTime.getTime())) {
    throw createError({ statusCode: 400, message: "\u5C65\u7EA6\u65E5\u671F\u683C\u5F0F\u9519\u8BEF" });
  }
  const fulfillmentType = body.fulfillmentType === "pickup" ? "pickup" : "delivery";
  const allowedPriceModes = /* @__PURE__ */ new Set(["retail", "vip", "wholesale", "discount", "promotion", "custom"]);
  const priceMode = allowedPriceModes.has(body.priceMode) ? body.priceMode : "retail";
  const discountRate = priceMode === "discount" ? Number(body.discountRate || 100) : null;
  const promotionId = priceMode === "promotion" && body.promotionId ? Number(body.promotionId) : null;
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const result = await prisma.$transaction(async (tx) => {
        const productIds = Array.from(
          new Set(body.items.map((i) => Number(i.productId)).filter(Boolean))
        );
        const products = await tx.product.findMany({
          where: { id: { in: productIds } },
          select: {
            id: true,
            name: true,
            defaultPrice: true,
            imageUrl: true,
            grade: true,
            color: true
          }
        });
        const productMap = new Map(products.map((p) => [p.id, p]));
        const dateStr = formatLocalDateKey(/* @__PURE__ */ new Date());
        const prefix = `PO${dateStr}`;
        const latest = await tx.order.findFirst({
          where: { orderType: "preorder", orderNo: { startsWith: prefix } },
          orderBy: { orderNo: "desc" },
          select: { orderNo: true }
        });
        const latestSeq = (latest == null ? void 0 : latest.orderNo) ? Number(latest.orderNo.slice(prefix.length)) || 0 : 0;
        const orderNo = `${prefix}${(latestSeq + 1).toString().padStart(4, "0")}`;
        let itemsSubtotal = 0;
        const itemRows = body.items.map((it) => {
          var _a, _b, _c, _d, _e, _f, _g;
          const p = productMap.get(Number(it.productId));
          if (!p) throw new Error(`\u5546\u54C1(id=${it.productId})\u4E0D\u5B58\u5728`);
          const unitPrice = Math.max(0, Number(it.unitPrice) || p.defaultPrice);
          const qty = Math.max(0, Number(it.qty) || 0);
          const baseQty = Math.max(0, Number(it.baseQty) || qty);
          const subtotal = Math.max(0, Number(it.subtotal) || unitPrice * qty);
          itemsSubtotal += subtotal;
          return {
            productId: p.id,
            unit: it.unit || "default",
            qty,
            baseQty,
            unitPrice,
            originalPrice: p.defaultPrice,
            subtotal,
            grade: (_b = (_a = it.grade) != null ? _a : p.grade) != null ? _b : null,
            color: (_d = (_c = it.color) != null ? _c : p.color) != null ? _d : null,
            notes: (_e = it.notes) != null ? _e : null,
            imageUrl: (_g = (_f = it.imageUrl) != null ? _f : p.imageUrl) != null ? _g : null
          };
        });
        let totalAmount = itemsSubtotal;
        if (priceMode === "promotion" && promotionId) {
          const promotion = await tx.promotion.findUnique({ where: { id: promotionId } });
          if (!promotion || promotion.status !== "active") throw new Error("\u6EE1\u51CF\u6D3B\u52A8\u4E0D\u5B58\u5728\u6216\u5DF2\u505C\u7528");
          if (itemsSubtotal < promotion.threshold) throw new Error("\u5F53\u524D\u5546\u54C1\u5C0F\u8BA1\u672A\u8FBE\u5230\u6EE1\u51CF\u95E8\u69DB");
          totalAmount = Math.max(0, itemsSubtotal - promotion.reduction);
        } else if (Number(body.totalAmount) >= 0) {
          totalAmount = Number(body.totalAmount);
        }
        const reminderStage = computeReminderStage(deliveryTime);
        return tx.order.create({
          data: {
            orderNo,
            orderType: "preorder",
            customerId: body.customerId || null,
            totalAmount,
            paidAmount: 0,
            owedAmount: 0,
            status: "pending_confirm",
            fulfillmentType,
            isUrgent: Boolean(body.isUrgent),
            isMade: Boolean(body.isMade),
            sortIndex: Number(body.sortIndex) || 0,
            priceMode,
            discountRate,
            promotionId,
            notes: body.notes || null,
            cardMessage: body.cardMessage || null,
            sourceChannel: body.sourceChannel || null,
            receiverName: body.receiverName || null,
            receiverPhone: body.receiverPhone || null,
            deliveryTime,
            deliveryAddress: body.deliveryAddress || null,
            reminderStage,
            reminderUpdatedAt: /* @__PURE__ */ new Date(),
            items: { create: itemRows }
          },
          include: { items: true }
        });
      });
      return { data: result, error: null };
    } catch (error) {
      lastError = error;
      if ((error == null ? void 0 : error.code) !== "P2002") break;
    }
  }
  return {
    data: null,
    error: { message: getErrorMessage(lastError), code: (lastError == null ? void 0 : lastError.code) || "CREATE_FAILED" }
  };
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
