import { c as defineEventHandler, h as getCurrentUser, r as readBody, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const body = await readBody(event);
  const name = ((body == null ? void 0 : body.name) || "").trim();
  const threshold = Number(body == null ? void 0 : body.threshold);
  const reduction = Number(body == null ? void 0 : body.reduction);
  if (!name) return { data: null, error: { message: "\u6D3B\u52A8\u540D\u79F0\u5FC5\u586B", code: "BAD_PARAMS" } };
  if (!(threshold > 0)) return { data: null, error: { message: "\u95E8\u69DB\u5FC5\u987B\u5927\u4E8E 0", code: "BAD_PARAMS" } };
  if (!(reduction > 0)) return { data: null, error: { message: "\u51CF\u514D\u91D1\u989D\u5FC5\u987B\u5927\u4E8E 0", code: "BAD_PARAMS" } };
  if (reduction >= threshold) {
    return { data: null, error: { message: "\u51CF\u514D\u91D1\u989D\u5FC5\u987B\u5C0F\u4E8E\u95E8\u69DB", code: "BAD_PARAMS" } };
  }
  try {
    const created = await prisma.promotion.create({
      data: {
        name,
        type: "full_reduction",
        threshold,
        reduction,
        status: (body == null ? void 0 : body.status) === "inactive" ? "inactive" : "active",
        startAt: (body == null ? void 0 : body.startAt) ? new Date(body.startAt) : null,
        endAt: (body == null ? void 0 : body.endAt) ? new Date(body.endAt) : null
      }
    });
    return { data: created, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u521B\u5EFA\u5931\u8D25", code: "CREATE_ERROR" } };
  }
});

export { index_post as default };
//# sourceMappingURL=index.post5.mjs.map
