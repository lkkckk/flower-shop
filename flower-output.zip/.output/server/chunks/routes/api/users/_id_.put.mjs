import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, r as readBody, n as hashPassword, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role !== "admin") {
    return { data: null, error: { message: "\u4EC5\u7BA1\u7406\u5458\u53EF\u64CD\u4F5C", code: "FORBIDDEN" } };
  }
  const id = Number(getRouterParam(event, "id"));
  const body = await readBody(event);
  const { name, role, status, password } = body || {};
  const updateData = {};
  if (name == null ? void 0 : name.trim()) updateData.name = name.trim();
  if (role && ["staff", "cashier"].includes(role)) updateData.role = role;
  if (status && ["active", "inactive"].includes(status)) updateData.status = status;
  if (password == null ? void 0 : password.trim()) {
    updateData.passwordHash = await hashPassword(password.trim());
  }
  const user = await prisma.user.update({
    where: { id },
    data: updateData,
    select: { id: true, username: true, name: true, role: true, status: true, createdAt: true }
  });
  return { data: user, error: null };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
