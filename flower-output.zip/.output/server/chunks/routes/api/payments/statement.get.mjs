import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const statement_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const customerId = Number(query.customerId);
  if (!customerId) {
    return { data: null, error: { message: "\u7F3A\u5C11 customerId \u53C2\u6570", code: "INVALID_PARAMS" } };
  }
  const startDate = query.startDate ? dayjs(query.startDate).startOf("day").toDate() : dayjs().startOf("month").toDate();
  const endDate = query.endDate ? dayjs(query.endDate).endOf("day").toDate() : dayjs().endOf("month").toDate();
  try {
    const [customer, orders, payments, priorOrders, priorRepays] = await Promise.all([
      prisma.customer.findUnique({ where: { id: customerId } }),
      // 期间订单
      prisma.order.findMany({
        where: {
          customerId,
          createdAt: { gte: startDate, lte: endDate }
        },
        orderBy: { createdAt: "asc" },
        include: {
          items: {
            select: {
              id: true,
              productId: true,
              qty: true,
              unit: true,
              unitPrice: true,
              subtotal: true,
              product: { select: { name: true, baseUnit: true } }
            }
          }
        }
      }),
      // 期间还款流水（type=repay）
      prisma.payment.findMany({
        where: {
          customerId,
          type: "repay",
          createdAt: { gte: startDate, lte: endDate }
        },
        orderBy: { createdAt: "asc" }
      }),
      // 期初之前所有订单 owedAmount 之和
      prisma.order.aggregate({
        where: {
          customerId,
          createdAt: { lt: startDate }
        },
        _sum: { owedAmount: true }
      }),
      // 期初之前所有 repay 之和
      prisma.payment.aggregate({
        where: {
          customerId,
          type: "repay",
          createdAt: { lt: startDate }
        },
        _sum: { amount: true }
      })
    ]);
    if (!customer) {
      return { data: null, error: { message: "\u5BA2\u6237\u4E0D\u5B58\u5728", code: "NOT_FOUND" } };
    }
    const openingBalance = (priorOrders._sum.owedAmount || 0) - (priorRepays._sum.amount || 0);
    const totalSales = orders.reduce((sum, o) => sum + o.totalAmount, 0);
    const totalPaid = orders.reduce((sum, o) => sum + o.paidAmount, 0);
    const totalOwed = orders.reduce((sum, o) => sum + o.owedAmount, 0);
    const totalRepay = payments.reduce((sum, p) => sum + p.amount, 0);
    const closingBalance = openingBalance + totalOwed - totalRepay;
    return {
      data: {
        customer,
        startDate,
        endDate,
        openingBalance,
        orders,
        payments,
        summary: {
          totalSales,
          totalPaid,
          totalOwed,
          totalRepay,
          closingBalance
        }
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u751F\u6210\u5BF9\u8D26\u5355\u5931\u8D25", code: "STATEMENT_ERROR" }
    };
  }
});

export { statement_get as default };
//# sourceMappingURL=statement.get.mjs.map
