import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, r as readBody, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const id = parseInt(getRouterParam(event, "id") || "0");
  if (!id) return { data: null, error: { message: "\u53C2\u6570\u9519\u8BEF", code: "BAD_PARAMS" } };
  const body = await readBody(event);
  const data = {};
  if ((body == null ? void 0 : body.name) !== void 0) data.name = String(body.name).trim();
  if ((body == null ? void 0 : body.threshold) !== void 0) data.threshold = Number(body.threshold);
  if ((body == null ? void 0 : body.reduction) !== void 0) data.reduction = Number(body.reduction);
  if ((body == null ? void 0 : body.status) !== void 0) data.status = body.status === "inactive" ? "inactive" : "active";
  if ((body == null ? void 0 : body.startAt) !== void 0) data.startAt = body.startAt ? new Date(body.startAt) : null;
  if ((body == null ? void 0 : body.endAt) !== void 0) data.endAt = body.endAt ? new Date(body.endAt) : null;
  if (data.threshold !== void 0 && !(data.threshold > 0)) {
    return { data: null, error: { message: "\u95E8\u69DB\u5FC5\u987B\u5927\u4E8E 0", code: "BAD_PARAMS" } };
  }
  if (data.reduction !== void 0 && !(data.reduction > 0)) {
    return { data: null, error: { message: "\u51CF\u514D\u91D1\u989D\u5FC5\u987B\u5927\u4E8E 0", code: "BAD_PARAMS" } };
  }
  if (data.threshold !== void 0 && data.reduction !== void 0 && data.reduction >= data.threshold) {
    return { data: null, error: { message: "\u51CF\u514D\u91D1\u989D\u5FC5\u987B\u5C0F\u4E8E\u95E8\u69DB", code: "BAD_PARAMS" } };
  }
  try {
    const updated = await prisma.promotion.update({ where: { id }, data });
    return { data: updated, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u66F4\u65B0\u5931\u8D25", code: "UPDATE_ERROR" } };
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
