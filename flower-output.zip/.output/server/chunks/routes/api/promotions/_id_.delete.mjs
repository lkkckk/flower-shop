import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const id = parseInt(getRouterParam(event, "id") || "0");
  if (!id) return { data: null, error: { message: "\u53C2\u6570\u9519\u8BEF", code: "BAD_PARAMS" } };
  try {
    const updated = await prisma.promotion.update({
      where: { id },
      data: { status: "inactive" }
    });
    return { data: updated, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u505C\u7528\u5931\u8D25", code: "DELETE_ERROR" } };
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
