import { c as defineEventHandler, h as getCurrentUser, r as readBody, n as hashPassword, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role !== "admin") {
    return { data: null, error: { message: "\u4EC5\u7BA1\u7406\u5458\u53EF\u64CD\u4F5C", code: "FORBIDDEN" } };
  }
  const body = await readBody(event);
  const { username, name, role, password } = body || {};
  if (!(username == null ? void 0 : username.trim()) || !(name == null ? void 0 : name.trim()) || !(password == null ? void 0 : password.trim())) {
    return { data: null, error: { message: "\u7528\u6237\u540D\u3001\u59D3\u540D\u3001\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A", code: "VALIDATION_ERROR" } };
  }
  if (!["staff", "cashier"].includes(role)) {
    return { data: null, error: { message: "\u89D2\u8272\u65E0\u6548", code: "VALIDATION_ERROR" } };
  }
  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({
    data: { username: username.trim(), name: name.trim(), role, passwordHash, status: "active" },
    select: { id: true, username: true, name: true, role: true, status: true, createdAt: true }
  });
  return { data: user, error: null };
});

export { index_post as default };
//# sourceMappingURL=index.post6.mjs.map
