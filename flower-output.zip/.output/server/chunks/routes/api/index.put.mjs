import { c as defineEventHandler, h as getCurrentUser, r as readBody, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_put = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const body = await readBody(event);
  if (!Array.isArray(body) || body.length === 0) {
    return { data: null, error: { message: "\u8BF7\u6C42\u4F53\u5FC5\u987B\u662F\u975E\u7A7A\u6570\u7EC4", code: "BAD_PARAMS" } };
  }
  for (const it of body) {
    if (!it.key || typeof it.value !== "string") {
      return { data: null, error: { message: `\u5B57\u6BB5\u9519\u8BEF\uFF1A${JSON.stringify(it)}`, code: "BAD_PARAMS" } };
    }
  }
  try {
    await prisma.$transaction(
      body.map(
        (it) => prisma.setting.upsert({
          where: { key: it.key },
          update: { value: it.value },
          create: { key: it.key, value: it.value }
        })
      )
    );
    const all = await prisma.setting.findMany();
    const map = {};
    for (const r of all) map[r.key] = r.value;
    return { data: map, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message || "\u4FDD\u5B58\u5931\u8D25", code: "SAVE_ERROR" } };
  }
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
