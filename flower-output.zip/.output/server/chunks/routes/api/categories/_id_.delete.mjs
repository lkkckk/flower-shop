import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const id = Number(getRouterParam(event, "id"));
  const hasChildren = await prisma.category.count({ where: { parentId: id } });
  if (hasChildren > 0) {
    return { data: null, error: { message: "\u8BF7\u5148\u5220\u9664\u5B50\u5206\u7C7B", code: "HAS_CHILDREN" } };
  }
  const hasProducts = await prisma.product.count({ where: { categoryId: id } });
  if (hasProducts > 0) {
    return { data: null, error: { message: `\u8BE5\u5206\u7C7B\u4E0B\u6709 ${hasProducts} \u4E2A\u5546\u54C1\uFF0C\u8BF7\u5148\u8FC1\u79FB\u6216\u5220\u9664\u5546\u54C1`, code: "HAS_PRODUCTS" } };
  }
  await prisma.category.delete({ where: { id } });
  return { data: null, error: null };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
