import { c as defineEventHandler, h as getCurrentUser, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const cashier_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff") {
    return { data: null, error: { message: "\u672A\u767B\u5F55", code: "UNAUTHORIZED" } };
  }
  const query = getQuery(event);
  const startDate = query.startDate;
  const endDate = query.endDate;
  const cashierId = query.cashierId ? Number(query.cashierId) : void 0;
  const dateWhere = {};
  if (startDate) dateWhere.gte = new Date(startDate);
  if (endDate) {
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    dateWhere.lte = end;
  }
  const orderWhere = { status: { not: "cancelled" } };
  if (Object.keys(dateWhere).length) orderWhere.createdAt = dateWhere;
  if (cashierId) orderWhere.cashierId = cashierId;
  const orders = await prisma.order.findMany({
    where: orderWhere,
    select: {
      id: true,
      totalAmount: true,
      paidAmount: true,
      owedAmount: true,
      cashierId: true,
      cashier: { select: { id: true, name: true, username: true, role: true } },
      payments: { select: { amount: true, paymentMethod: true } }
    }
  });
  const map = /* @__PURE__ */ new Map();
  for (const o of orders) {
    const cid = (_a = o.cashierId) != null ? _a : 0;
    if (!map.has(cid)) {
      map.set(cid, {
        cashierId: cid,
        cashierName: ((_b = o.cashier) == null ? void 0 : _b.name) || (cid === 0 ? "\u672A\u8BB0\u5F55" : `\u7528\u6237${cid}`),
        cashierUsername: ((_c = o.cashier) == null ? void 0 : _c.username) || "",
        orderCount: 0,
        totalSales: 0,
        totalPaid: 0,
        totalOwed: 0,
        paymentBreakdown: {}
      });
    }
    const row = map.get(cid);
    row.orderCount++;
    row.totalSales += o.totalAmount;
    row.totalPaid += o.paidAmount;
    row.totalOwed += o.owedAmount;
    for (const p of o.payments) {
      row.paymentBreakdown[p.paymentMethod] = (row.paymentBreakdown[p.paymentMethod] || 0) + p.amount;
    }
  }
  const result = Array.from(map.values()).sort((a, b) => b.totalSales - a.totalSales);
  return { data: result, error: null };
});

export { cashier_get as default };
//# sourceMappingURL=cashier.get.mjs.map
