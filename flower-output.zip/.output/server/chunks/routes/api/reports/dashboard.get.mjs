import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const dashboard_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const query = getQuery(event);
  const startDate = query.startDate ? dayjs(query.startDate).startOf("day").toDate() : dayjs().startOf("day").toDate();
  const endDate = query.endDate ? dayjs(query.endDate).endOf("day").toDate() : dayjs().endOf("day").toDate();
  try {
    const orders = await prisma.order.findMany({
      where: {
        createdAt: { gte: startDate, lte: endDate },
        status: { notIn: ["cancelled"] }
      },
      orderBy: { createdAt: "asc" },
      include: {
        items: {
          include: {
            batch: { select: { costPrice: true } },
            product: { select: { id: true, name: true, baseUnit: true } }
          }
        }
      }
    });
    const payments = await prisma.payment.findMany({
      where: {
        type: "income",
        createdAt: { gte: startDate, lte: endDate }
      }
    });
    const totalSales = orders.reduce((sum, o) => sum + o.totalAmount, 0);
    const orderCount = orders.length;
    const avgOrderValue = orderCount > 0 ? totalSales / orderCount : 0;
    const totalPaid = orders.reduce((sum, o) => sum + o.paidAmount, 0);
    const totalOwed = orders.reduce((sum, o) => sum + o.owedAmount, 0);
    let totalCost = 0;
    const productMap = /* @__PURE__ */ new Map();
    for (const order of orders) {
      for (const item of order.items) {
        const itemCost = (((_a = item.batch) == null ? void 0 : _a.costPrice) || 0) * item.baseQty;
        totalCost += itemCost;
        const profit = item.subtotal - itemCost;
        const pid = item.productId;
        const existing = productMap.get(pid);
        if (existing) {
          existing.qty += item.baseQty;
          existing.amount += item.subtotal;
          existing.profit += profit;
        } else {
          productMap.set(pid, {
            productId: pid,
            productName: ((_b = item.product) == null ? void 0 : _b.name) || `#${pid}`,
            baseUnit: ((_c = item.product) == null ? void 0 : _c.baseUnit) || "",
            qty: item.baseQty,
            amount: item.subtotal,
            profit
          });
        }
      }
    }
    const grossProfit = totalSales - totalCost;
    const grossMargin = totalSales > 0 ? grossProfit / totalSales * 100 : 0;
    const topProducts = Array.from(productMap.values()).sort((a, b) => b.amount - a.amount).slice(0, 10);
    const methodMap = /* @__PURE__ */ new Map();
    for (const p of payments) {
      const m = p.paymentMethod || "unknown";
      const existing = methodMap.get(m);
      if (existing) {
        existing.count += 1;
        existing.amount += p.amount;
      } else {
        methodMap.set(m, { method: m, count: 1, amount: p.amount });
      }
    }
    const paymentMethods = Array.from(methodMap.values()).sort((a, b) => b.amount - a.amount);
    const dayMap = /* @__PURE__ */ new Map();
    for (const order of orders) {
      const d = dayjs(order.createdAt).format("YYYY-MM-DD");
      const existing = dayMap.get(d);
      const orderCost = order.items.reduce((s, i2) => {
        var _a2;
        return s + (((_a2 = i2.batch) == null ? void 0 : _a2.costPrice) || 0) * i2.baseQty;
      }, 0);
      if (existing) {
        existing.amount += order.totalAmount;
        existing.orderCount += 1;
        existing.cost += orderCost;
      } else {
        dayMap.set(d, { date: d, amount: order.totalAmount, orderCount: 1, cost: orderCost });
      }
    }
    const dailyTrend = [];
    let cursor = dayjs(startDate).startOf("day");
    const finalDay = dayjs(endDate).startOf("day");
    const maxDays = 90;
    let i = 0;
    while (cursor.valueOf() <= finalDay.valueOf() && i < maxDays) {
      const key = cursor.format("YYYY-MM-DD");
      const entry = dayMap.get(key);
      dailyTrend.push({
        date: key,
        amount: (entry == null ? void 0 : entry.amount) || 0,
        orderCount: (entry == null ? void 0 : entry.orderCount) || 0,
        profit: entry ? entry.amount - entry.cost : 0
      });
      cursor = cursor.add(1, "day");
      i++;
    }
    let slowProducts = [];
    try {
      const sevenDaysAgo = dayjs().subtract(7, "day").startOf("day").toDate();
      const activeProducts = await prisma.product.findMany({
        where: { status: "active" },
        include: {
          stockBatches: {
            where: { status: "in_stock", currentQty: { gt: 0 } },
            select: { currentQty: true }
          },
          orderItems: {
            where: { order: { createdAt: { gte: sevenDaysAgo } } },
            select: { id: true, order: { select: { createdAt: true } } }
          }
        }
      });
      slowProducts = activeProducts.map((p) => {
        const soldCount = p.orderItems.length;
        const currentStock = p.stockBatches.reduce((s, b) => s + b.currentQty, 0);
        const lastSoldAt = p.orderItems.length > 0 ? p.orderItems.reduce((latest, oi) => {
          var _a2;
          const d = (_a2 = oi.order) == null ? void 0 : _a2.createdAt;
          if (!d) return latest;
          if (!latest || d > latest) return d;
          return latest;
        }, null) : null;
        return {
          productId: p.id,
          productName: p.name,
          lastSoldAt,
          currentStock,
          soldCount
        };
      }).filter((p) => p.soldCount < 5 && p.currentStock > 0).sort((a, b) => a.soldCount - b.soldCount).slice(0, 20);
    } catch (e) {
      slowProducts = [];
    }
    return {
      data: {
        startDate,
        endDate,
        summary: {
          totalSales,
          orderCount,
          avgOrderValue,
          totalCost,
          grossProfit,
          grossMargin,
          totalPaid,
          totalOwed
        },
        paymentMethods,
        topProducts,
        slowProducts,
        dailyTrend
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u62A5\u8868\u5931\u8D25", code: "REPORT_ERROR" }
    };
  }
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
