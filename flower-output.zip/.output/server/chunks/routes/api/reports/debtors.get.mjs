import { c as defineEventHandler, h as getCurrentUser, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const debtors_get = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff") {
    return { data: null, error: { message: "\u672A\u767B\u5F55", code: "UNAUTHORIZED" } };
  }
  const customers = await prisma.customer.findMany({
    where: { totalOwed: { gt: 0 } },
    include: {
      orders: {
        where: { owedAmount: { gt: 0 }, status: { not: "cancelled" } },
        orderBy: { createdAt: "desc" },
        include: {
          payments: {
            where: { type: "income" },
            orderBy: { createdAt: "desc" }
          }
        }
      }
    },
    orderBy: { totalOwed: "desc" }
  });
  return {
    data: customers.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      balance: c.balance,
      totalOwed: c.totalOwed,
      orders: c.orders.map((o) => ({
        id: o.id,
        orderNo: o.orderNo,
        totalAmount: o.totalAmount,
        paidAmount: o.paidAmount,
        owedAmount: o.owedAmount,
        createdAt: o.createdAt,
        payments: o.payments.map((p) => ({
          id: p.id,
          amount: p.amount,
          paymentMethod: p.paymentMethod,
          createdAt: p.createdAt
        }))
      }))
    })),
    error: null
  };
});

export { debtors_get as default };
//# sourceMappingURL=debtors.get.mjs.map
