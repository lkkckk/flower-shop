import { c as defineEventHandler, h as getCurrentUser, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  const isCashier = (payload == null ? void 0 : payload.type) === "staff" && (payload == null ? void 0 : payload.role) === "cashier";
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const view = query.view || "by_batch";
  const productId = query.productId ? Number(query.productId) : void 0;
  const batchId = query.batchId ? Number(query.batchId) : void 0;
  const status = query.status;
  const expiringSoon = query.expiringSoon === "true" || query.expiringSoon === "1";
  try {
    if (view === "by_batch") {
      const where = {};
      if (batchId) where.id = batchId;
      if (productId) where.productId = productId;
      if (status) where.status = status;
      if (expiringSoon) {
        where.status = "in_stock";
        where.currentQty = { gt: 0 };
        where.expiryDate = { lte: dayjs().add(3, "day").endOf("day").toDate() };
      }
      const [list2, total2] = await Promise.all([
        prisma.stockBatch.findMany({
          where,
          include: { product: true },
          orderBy: { inboundDate: "desc" },
          skip: (page - 1) * pageSize,
          take: pageSize
        }),
        prisma.stockBatch.count({ where })
      ]);
      const sanitized = isCashier ? list2.map(({ costPrice: _c, ...rest }) => rest) : list2;
      return {
        data: { list: sanitized, total: total2, page, pageSize },
        error: null
      };
    }
    const productWhere = {};
    if (productId) productWhere.id = productId;
    const products = await prisma.product.findMany({
      where: productWhere,
      include: {
        stockBatches: {
          where: { status: "in_stock", currentQty: { gt: 0 } }
        }
      },
      orderBy: { updatedAt: "desc" }
    });
    let aggregated = products.map((p) => {
      const batches = p.stockBatches;
      const totalStock = batches.reduce((sum, b) => sum + b.currentQty, 0);
      const batchCount = batches.length;
      const earliestExpiry = batches.length > 0 ? batches.reduce((min, b) => min === null || b.expiryDate < min ? b.expiryDate : min, null) : null;
      const { stockBatches, ...rest } = p;
      return {
        ...rest,
        totalStock,
        batchCount,
        earliestExpiry
      };
    });
    if (expiringSoon) {
      const threshold = dayjs().add(3, "day").endOf("day").toDate();
      aggregated = aggregated.filter((p) => p.earliestExpiry !== null && p.earliestExpiry <= threshold && p.totalStock > 0);
    }
    const total = aggregated.length;
    const list = aggregated.slice((page - 1) * pageSize, page * pageSize);
    return {
      data: { list, total, page, pageSize },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5E93\u5B58\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get9.mjs.map
