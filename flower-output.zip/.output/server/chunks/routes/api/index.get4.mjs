import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import dayjs from 'dayjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const customerId = query.customerId ? Number(query.customerId) : void 0;
  const status = query.status;
  const cashierId = query.cashierId ? Number(query.cashierId) : void 0;
  const paymentMethod = query.paymentMethod;
  const sourceChannel = query.sourceChannel ? String(query.sourceChannel).trim() : void 0;
  const minAmount = query.minAmount !== void 0 && query.minAmount !== "" ? Number(query.minAmount) : void 0;
  const maxAmount = query.maxAmount !== void 0 && query.maxAmount !== "" ? Number(query.maxAmount) : void 0;
  const keyword = query.keyword ? String(query.keyword).trim() : void 0;
  const hasDebt = String(query.hasDebt || "") === "true";
  const hasDiscount = String(query.hasDiscount || "") === "true";
  const tag = query.tag ? String(query.tag).trim() : void 0;
  const startDate = query.startDate ? dayjs(query.startDate).startOf("day").toDate() : void 0;
  const endDate = query.endDate ? dayjs(query.endDate).endOf("day").toDate() : void 0;
  const orderType = (_a = query.orderType) != null ? _a : "non-preorder";
  const where = {};
  if (customerId) where.customerId = customerId;
  if (status) where.status = status;
  if (cashierId) where.cashierId = cashierId;
  if (orderType === "non-preorder") where.orderType = { not: "preorder" };
  else if (orderType !== "all") where.orderType = orderType;
  if (startDate || endDate) {
    where.createdAt = {};
    if (startDate) where.createdAt.gte = startDate;
    if (endDate) where.createdAt.lte = endDate;
  }
  if (sourceChannel) where.sourceChannel = { contains: sourceChannel, mode: "insensitive" };
  if (minAmount !== void 0 && !Number.isNaN(minAmount)) {
    where.totalAmount = { ...where.totalAmount || {}, gte: minAmount };
  }
  if (maxAmount !== void 0 && !Number.isNaN(maxAmount)) {
    where.totalAmount = { ...where.totalAmount || {}, lte: maxAmount };
  }
  if (hasDebt) where.owedAmount = { gt: 0 };
  if (hasDiscount) where.priceMode = { in: ["discount", "promotion"] };
  if (tag) where.tags = { contains: tag, mode: "insensitive" };
  if (paymentMethod) {
    where.payments = { some: { paymentMethod } };
  }
  if (keyword) {
    where.OR = [
      { orderNo: { contains: keyword, mode: "insensitive" } },
      { receiverName: { contains: keyword, mode: "insensitive" } },
      { receiverPhone: { contains: keyword } },
      { tags: { contains: keyword, mode: "insensitive" } },
      { customer: { is: { name: { contains: keyword, mode: "insensitive" } } } },
      { customer: { is: { phone: { contains: keyword } } } }
    ];
  }
  try {
    const [list, total, summary] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          customer: { select: { id: true, name: true, level: true, phone: true } },
          cashier: { select: { id: true, name: true } },
          items: {
            select: {
              id: true,
              productId: true,
              unit: true,
              qty: true,
              unitPrice: true,
              subtotal: true,
              grade: true,
              color: true,
              product: { select: { id: true, name: true, baseUnit: true } }
            }
          }
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.order.count({ where }),
      prisma.order.aggregate({
        where,
        _count: { _all: true },
        _sum: { totalAmount: true, paidAmount: true, owedAmount: true }
      })
    ]);
    return {
      data: {
        list,
        total,
        page,
        pageSize,
        summary: {
          count: summary._count._all,
          totalAmount: (_b = summary._sum.totalAmount) != null ? _b : 0,
          paidAmount: (_c = summary._sum.paidAmount) != null ? _c : 0,
          owedAmount: (_d = summary._sum.owedAmount) != null ? _d : 0
        }
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get4.mjs.map
