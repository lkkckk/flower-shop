import { c as defineEventHandler, h as getCurrentUser, r as readBody, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const body = await readBody(event);
  const { name, parentId, sort } = body || {};
  if (!(name == null ? void 0 : name.trim())) {
    return { data: null, error: { message: "\u5206\u7C7B\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A", code: "VALIDATION_ERROR" } };
  }
  const category = await prisma.category.create({
    data: {
      name: name.trim(),
      parentId: parentId ? Number(parentId) : null,
      sort: sort ? Number(sort) : 0
    }
  });
  return { data: category, error: null };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
