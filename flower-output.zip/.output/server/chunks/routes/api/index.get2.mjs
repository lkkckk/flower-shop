import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const DAY_MS = 24 * 60 * 60 * 1e3;
function computeRfm(lastOrderAt, orderCount, totalSpent) {
  if (!lastOrderAt) return "none";
  const days = Math.floor((Date.now() - lastOrderAt.getTime()) / DAY_MS);
  if (days > 90) return "churned";
  if (days > 30) return "sleeping";
  if (orderCount >= 3 && totalSpent >= 5e3) return "vip_active";
  return "new";
}
const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const keyword = query.keyword;
  const level = query.level;
  const rfmTag = query.rfmTag;
  const hasDebt = String(query.hasDebt || "") === "true";
  const where = {};
  if (keyword) {
    where.OR = [
      { name: { contains: keyword } },
      { phone: { contains: keyword } }
    ];
  }
  if (level) where.level = level;
  if (hasDebt) where.totalOwed = { gt: 0 };
  try {
    const [allCustomers, summary] = await Promise.all([
      prisma.customer.findMany({
        where,
        orderBy: { updatedAt: "desc" }
      }),
      prisma.customer.aggregate({
        where,
        _count: { _all: true },
        _sum: { totalOwed: true, balance: true }
      })
    ]);
    const customerIds = allCustomers.map((c) => c.id);
    const orderStats = customerIds.length === 0 ? [] : await prisma.order.groupBy({
      by: ["customerId"],
      where: { customerId: { in: customerIds }, status: { not: "cancelled" } },
      _count: { _all: true },
      _sum: { totalAmount: true },
      _max: { createdAt: true }
    });
    const statsMap = /* @__PURE__ */ new Map();
    for (const row of orderStats) {
      if (row.customerId == null) continue;
      statsMap.set(row.customerId, {
        lastOrderAt: (_a = row._max.createdAt) != null ? _a : null,
        orderCount: row._count._all,
        totalSpent: (_b = row._sum.totalAmount) != null ? _b : 0
      });
    }
    const enriched = allCustomers.map((c) => {
      var _a2;
      const s = (_a2 = statsMap.get(c.id)) != null ? _a2 : { lastOrderAt: null, orderCount: 0, totalSpent: 0 };
      const tag = computeRfm(s.lastOrderAt, s.orderCount, s.totalSpent);
      return {
        ...c,
        stats: { ...s, rfmTag: tag }
      };
    });
    const filtered = rfmTag ? enriched.filter((c) => c.stats.rfmTag === rfmTag) : enriched;
    const total = filtered.length;
    const slice = filtered.slice((page - 1) * pageSize, page * pageSize);
    const debtCount = await prisma.customer.count({
      where: { ...where, totalOwed: { gt: 0 } }
    });
    return {
      data: {
        list: slice,
        total,
        page,
        pageSize,
        summary: {
          count: summary._count._all,
          totalOwed: (_c = summary._sum.totalOwed) != null ? _c : 0,
          totalBalance: (_d = summary._sum.balance) != null ? _d : 0,
          debtCount
        }
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5BA2\u6237\u5217\u8868\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
