import { c as defineEventHandler, l as generateNotifications } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const regenerate_post = defineEventHandler(async (event) => {
  const user = event.context.user;
  if (!user || user.type !== "staff" || user.role !== "admin") {
    return { data: null, error: { message: "\u4EC5\u7BA1\u7406\u5458\u53EF\u64CD\u4F5C", code: "FORBIDDEN" } };
  }
  try {
    await generateNotifications();
    return { data: { success: true }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u901A\u77E5\u751F\u6210\u5931\u8D25", code: "GENERATE_ERROR" }
    };
  }
});

export { regenerate_post as default };
//# sourceMappingURL=regenerate.post.mjs.map
