import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const unreadCount_get = defineEventHandler(async () => {
  try {
    const count = await prisma.notification.count({ where: { userId: null, readAt: null } });
    return { data: { count }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u672A\u8BFB\u6570\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { unreadCount_get as default };
//# sourceMappingURL=unread-count.get.mjs.map
