import { c as defineEventHandler, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const markAllRead_post = defineEventHandler(async () => {
  try {
    const r = await prisma.notification.updateMany({
      where: { userId: null, readAt: null },
      data: { readAt: /* @__PURE__ */ new Date() }
    });
    return { data: { updated: r.count }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u6807\u8BB0\u5931\u8D25", code: "UPDATE_ERROR" }
    };
  }
});

export { markAllRead_post as default };
//# sourceMappingURL=mark-all-read.post.mjs.map
