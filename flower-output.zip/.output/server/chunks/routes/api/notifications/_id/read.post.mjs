import { c as defineEventHandler, j as getRouterParam, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const read_post = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u901A\u77E5 ID", code: "INVALID_PARAMS" } };
  }
  try {
    await prisma.notification.update({
      where: { id },
      data: { readAt: /* @__PURE__ */ new Date() }
    });
    return { data: { success: true }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u6807\u8BB0\u5931\u8D25", code: "UPDATE_ERROR" }
    };
  }
});

export { read_post as default };
//# sourceMappingURL=read.post.mjs.map
