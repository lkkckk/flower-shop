import { c as defineEventHandler, j as getRouterParam, r as readBody, p as prisma } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const repay_post = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u8BA2\u5355 ID", code: "INVALID_PARAMS" } };
  }
  const body = await readBody(event);
  const amount = Number(body == null ? void 0 : body.amount);
  const paymentMethod = String((body == null ? void 0 : body.paymentMethod) || "");
  const notes = (body == null ? void 0 : body.notes) ? String(body.notes) : null;
  if (!(amount > 0)) {
    return { data: null, error: { message: "\u8865\u6B3E\u91D1\u989D\u5FC5\u987B\u5927\u4E8E 0", code: "INVALID_PARAMS" } };
  }
  if (!["cash", "wechat", "alipay"].includes(paymentMethod)) {
    return { data: null, error: { message: "\u652F\u4ED8\u65B9\u5F0F\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" } };
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({ where: { id } });
      if (!order) throw new Error("\u8BA2\u5355\u4E0D\u5B58\u5728");
      if (order.owedAmount <= 0) throw new Error("\u8BE5\u8BA2\u5355\u5DF2\u65E0\u6B20\u6B3E");
      if (amount > order.owedAmount + 1e-6) {
        throw new Error(`\u8865\u6B3E\u91D1\u989D \xA5${amount.toFixed(2)} \u8D85\u8FC7\u5F53\u524D\u6B20\u6B3E \xA5${order.owedAmount.toFixed(2)}`);
      }
      const newPaid = order.paidAmount + amount;
      const newOwed = Math.max(0, order.owedAmount - amount);
      const newStatus = newOwed <= 1e-6 ? "paid" : "partial";
      const updated = await tx.order.update({
        where: { id },
        data: { paidAmount: newPaid, owedAmount: newOwed, status: newStatus }
      });
      const payment = await tx.payment.create({
        data: {
          orderId: id,
          customerId: order.customerId,
          amount,
          paymentMethod,
          type: "income",
          notes,
          operator: "system"
        }
      });
      if (order.customerId) {
        await tx.customer.update({
          where: { id: order.customerId },
          data: { totalOwed: { decrement: amount } }
        });
      }
      return { order: updated, payment };
    });
    return { data: result, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u8865\u6B3E\u5931\u8D25", code: "REPAY_ERROR" }
    };
  }
});

export { repay_post as default };
//# sourceMappingURL=repay.post.mjs.map
