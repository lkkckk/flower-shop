import { c as defineEventHandler, r as readBody, i as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const parseTags = (value) => (value || "").split(",").map((tag) => tag.trim()).filter(Boolean);
const serializeTags = (tags) => Array.from(new Set(tags)).join(",") || null;
const bulkTag_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const ids = Array.isArray(body == null ? void 0 : body.ids) ? body.ids.map((id) => Number(id)).filter((id) => Number.isInteger(id) && id > 0) : [];
  const tag = String((body == null ? void 0 : body.tag) || "").trim();
  const mode = ["append", "remove", "replace"].includes(body == null ? void 0 : body.mode) ? body.mode : "append";
  if (ids.length === 0) {
    throw createError({ statusCode: 400, message: "\u8BF7\u9009\u62E9\u8981\u6253\u6807\u7684\u8BA2\u5355" });
  }
  if (!tag) {
    throw createError({ statusCode: 400, message: "\u8BF7\u8F93\u5165\u6807\u7B7E" });
  }
  if (tag.includes(",")) {
    throw createError({ statusCode: 400, message: "\u6807\u7B7E\u4E0D\u80FD\u5305\u542B\u9017\u53F7" });
  }
  try {
    const orders = await prisma.order.findMany({
      where: { id: { in: ids } },
      select: { id: true, tags: true }
    });
    await prisma.$transaction(
      orders.map((order) => {
        const current = parseTags(order.tags);
        let next;
        if (mode === "replace") next = [tag];
        else if (mode === "remove") next = current.filter((item) => item !== tag);
        else next = [...current, tag];
        return prisma.order.update({
          where: { id: order.id },
          data: { tags: serializeTags(next) }
        });
      })
    );
    return { data: { updated: orders.length }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u6279\u91CF\u6253\u6807\u5931\u8D25", code: "BULK_TAG_ERROR" }
    };
  }
});

export { bulkTag_post as default };
//# sourceMappingURL=bulk-tag.post.mjs.map
