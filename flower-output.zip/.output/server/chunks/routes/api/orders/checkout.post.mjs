import { c as defineEventHandler, r as readBody, i as createError, p as prisma } from '../../../_/nitro.mjs';
import { a as allocateAndDeduct } from '../../../_/stockAllocator.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

function roundPrice(n) {
  return Math.max(0, Math.round(n * 100) / 100);
}
function pickBasePrice(basis, _mode) {
  return basis.defaultPrice;
}
function computeOrder(input) {
  var _a;
  const mode = input.mode;
  const rate = mode === "discount" ? Math.max(0, Math.min(100, (_a = input.discountRate) != null ? _a : 100)) : 100;
  const lineUnitPrices = [];
  const lineSubtotals = [];
  for (const item of input.items) {
    const base = pickBasePrice(item.basis);
    let unitPrice = base * (item.toBaseQty || 1);
    if (mode === "discount") unitPrice = unitPrice * (rate / 100);
    unitPrice = roundPrice(unitPrice);
    lineUnitPrices.push(unitPrice);
    lineSubtotals.push(roundPrice(unitPrice * item.qty));
  }
  const subtotal = roundPrice(lineSubtotals.reduce((s, n) => s + n, 0));
  let reduction = 0;
  let promotionApplicable = false;
  if (mode === "promotion" && input.promotion) {
    if (subtotal >= input.promotion.threshold) {
      reduction = roundPrice(input.promotion.reduction);
      promotionApplicable = true;
    }
  }
  const total = roundPrice(Math.max(0, subtotal - reduction));
  return { lineUnitPrices, lineSubtotals, subtotal, reduction, total, promotionApplicable };
}

const checkout_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const cart = body == null ? void 0 : body.cart;
  const payment = body == null ? void 0 : body.payment;
  if (!cart || !payment) {
    throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BF7\u6C42\u6570\u636E" });
  }
  if (!Array.isArray(cart.items) || cart.items.length === 0) {
    throw createError({ statusCode: 400, message: "\u8D2D\u7269\u8F66\u4E3A\u7A7A" });
  }
  const priceMode = ["retail", "discount", "promotion"].includes(cart.priceMode) ? cart.priceMode : "retail";
  const discountRate = priceMode === "discount" && typeof cart.discountRate === "number" ? cart.discountRate : void 0;
  const promotionId = priceMode === "promotion" && cart.promotionId ? Number(cart.promotionId) : null;
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const result = await prisma.$transaction(async (tx) => {
        var _a;
        const productIds = Array.from(
          new Set(cart.items.map((i) => Number(i.productId)).filter(Boolean))
        );
        const products = await tx.product.findMany({
          where: { id: { in: productIds } },
          select: {
            id: true,
            name: true,
            defaultPrice: true,
            baseUnit: true,
            unitConversions: { select: { fromUnit: true, toBaseQty: true } }
          }
        });
        const productMap = new Map(products.map((p) => [p.id, p]));
        let promotion = null;
        if (promotionId) {
          const p = await tx.promotion.findUnique({ where: { id: promotionId } });
          if (!p || p.status !== "active") {
            throw new Error("\u4FC3\u9500\u6D3B\u52A8\u4E0D\u5B58\u5728\u6216\u5DF2\u505C\u7528");
          }
          const now = /* @__PURE__ */ new Date();
          if (p.startAt && p.startAt > now) throw new Error("\u4FC3\u9500\u6D3B\u52A8\u5C1A\u672A\u5F00\u59CB");
          if (p.endAt && p.endAt < now) throw new Error("\u4FC3\u9500\u6D3B\u52A8\u5DF2\u8FC7\u671F");
          promotion = { id: p.id, threshold: p.threshold, reduction: p.reduction };
        }
        const lineInputs = cart.items.map((it) => {
          const p = productMap.get(Number(it.productId));
          if (!p) throw new Error(`\u5546\u54C1(id=${it.productId})\u4E0D\u5B58\u5728`);
          let toBaseQty = 1;
          if (it.unit && it.unit !== p.baseUnit) {
            const conv = p.unitConversions.find((u) => u.fromUnit === it.unit);
            if (conv) toBaseQty = conv.toBaseQty;
          }
          return {
            basis: { defaultPrice: p.defaultPrice },
            qty: Number(it.qty),
            toBaseQty
          };
        });
        const priceResult = computeOrder({
          items: lineInputs,
          mode: priceMode,
          discountRate,
          promotion
        });
        if (priceMode === "promotion" && !priceResult.promotionApplicable) {
          throw Object.assign(new Error("\u5F53\u524D\u5408\u8BA1\u672A\u8FBE\u5230\u6EE1\u51CF\u95E8\u69DB"), {
            code: "PROMOTION_NOT_APPLICABLE"
          });
        }
        const extraDiscount = Math.max(0, Number(cart.discount) || 0);
        const totalAmount = Math.max(0, priceResult.total - extraDiscount);
        const dateStr = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replace(/-/g, "");
        const todayStart = /* @__PURE__ */ new Date();
        todayStart.setHours(0, 0, 0, 0);
        const orderCount = await tx.order.count({
          where: { createdAt: { gte: todayStart } }
        });
        const orderNo = `O${dateStr}${(orderCount + 1).toString().padStart(4, "0")}`;
        if (payment.method === "balance") {
          if (!cart.customerId) throw new Error("\u6263\u9884\u5B58\u9700\u8981\u9009\u62E9\u5BA2\u6237");
          const r = await tx.customer.updateMany({
            where: { id: cart.customerId, balance: { gte: payment.paidAmount } },
            data: { balance: { decrement: payment.paidAmount } }
          });
          if (r.count === 0) throw new Error("\u9884\u5B58\u4F59\u989D\u4E0D\u8DB3\u4EE5\u652F\u4ED8\u5168\u989D\uFF08\u6216\u5DF2\u88AB\u5E76\u53D1\u6263\u9664\uFF09");
        }
        let status = "pending";
        if (payment.method === "credit") {
          status = "unpaid";
        } else if (payment.paidAmount >= totalAmount && totalAmount > 0) {
          status = "paid";
        } else if (payment.paidAmount > 0) {
          status = "partial";
        }
        const currentUser = event.context.user;
        const cashierId = body.cashierId ? Number(body.cashierId) : (currentUser == null ? void 0 : currentUser.sub) ? Number(currentUser.sub) : null;
        const order = await tx.order.create({
          data: {
            orderNo,
            orderType: "retail",
            customerId: cart.customerId || null,
            totalAmount,
            paidAmount: payment.paidAmount,
            owedAmount: payment.owedAmount,
            status,
            notes: cart.notes,
            priceMode,
            discountRate: priceMode === "discount" ? discountRate != null ? discountRate : null : null,
            promotionId: (_a = promotion == null ? void 0 : promotion.id) != null ? _a : null,
            cashierId
          }
        });
        const allocInputs = cart.items.map((item, idx) => {
          var _a2, _b;
          return {
            productId: Number(item.productId),
            unit: item.unit,
            qty: Number(item.qty),
            baseQty: Number(item.baseQty),
            unitPrice: priceResult.lineUnitPrices[idx],
            subtotal: priceResult.lineSubtotals[idx],
            originalPrice: (_b = (_a2 = productMap.get(Number(item.productId))) == null ? void 0 : _a2.defaultPrice) != null ? _b : null,
            productName: item.productName
          };
        });
        await allocateAndDeduct(tx, order.id, allocInputs, "system");
        if (cart.customerId) {
          const customerUpdate = {};
          if (payment.owedAmount > 0) {
            customerUpdate.balance = { decrement: payment.owedAmount };
            customerUpdate.totalOwed = { increment: payment.owedAmount };
          }
          const earnedPoints = Math.floor(totalAmount);
          if (earnedPoints > 0) customerUpdate.points = { increment: earnedPoints };
          if (Object.keys(customerUpdate).length > 0) {
            await tx.customer.update({ where: { id: cart.customerId }, data: customerUpdate });
          }
        }
        if (payment.paidAmount > 0) {
          await tx.payment.create({
            data: {
              orderId: order.id,
              customerId: cart.customerId || null,
              amount: payment.paidAmount,
              paymentMethod: payment.method,
              type: "income",
              operator: "system"
            }
          });
        }
        return { order, priceResult, totalAmount };
      });
      return {
        data: {
          order: result.order,
          total: result.totalAmount,
          subtotal: result.priceResult.subtotal,
          reduction: result.priceResult.reduction,
          priceMode,
          message: "\u7ED3\u8D26\u6210\u529F"
        },
        error: null
      };
    } catch (error) {
      lastError = error;
      if ((error == null ? void 0 : error.code) !== "P2002") break;
    }
  }
  return {
    data: null,
    error: {
      message: (lastError == null ? void 0 : lastError.code) === "P2002" ? "\u8BA2\u5355\u53F7\u51B2\u7A81\uFF0C\u8BF7\u91CD\u8BD5" : (lastError == null ? void 0 : lastError.message) || "\u7ED3\u8D26\u5931\u8D25",
      code: (lastError == null ? void 0 : lastError.code) || "CHECKOUT_FAILED",
      shortages: (lastError == null ? void 0 : lastError.shortages) || void 0
    }
  };
});

export { checkout_post as default };
//# sourceMappingURL=checkout.post.mjs.map
