import { c as defineEventHandler, j as getRouterParam, i as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id)) {
    throw createError({ statusCode: 400, message: "\u65E0\u6548\u7684\u8BA2\u5355 ID" });
  }
  try {
    const [order, payments] = await Promise.all([
      prisma.order.findUnique({
        where: { id },
        include: {
          customer: true,
          cashier: { select: { id: true, name: true, username: true } },
          promotion: { select: { id: true, name: true, threshold: true, reduction: true } },
          items: {
            include: {
              product: { select: { id: true, name: true, baseUnit: true, imageUrl: true } },
              batch: { select: { id: true, batchNo: true } }
            }
          }
        }
      }),
      prisma.payment.findMany({
        where: { orderId: id },
        orderBy: { createdAt: "asc" }
      })
    ]);
    if (!order) {
      throw createError({ statusCode: 404, message: "\u8BA2\u5355\u4E0D\u5B58\u5728" });
    }
    return {
      data: { ...order, paymentLogs: payments },
      error: null
    };
  } catch (error) {
    if (error.statusCode) throw error;
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u8BA2\u5355\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
