import { c as defineEventHandler, h as getCurrentUser, j as getRouterParam, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  const payload = getCurrentUser(event);
  if (!payload || payload.type !== "staff" || payload.role === "cashier") {
    return { data: null, error: { message: "\u6743\u9650\u4E0D\u8DB3", code: "FORBIDDEN" } };
  }
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id)) {
    return { data: null, error: { message: "\u65E0\u6548\u7684\u5546\u54C1 ID", code: "INVALID_ID" } };
  }
  const query = getQuery(event);
  const force = query.force === "true";
  try {
    if (!force) {
      await prisma.product.update({ where: { id }, data: { status: "inactive" } });
      return { data: { success: true, action: "deactivated" }, error: null };
    }
    const orderItemCount = await prisma.orderItem.count({ where: { productId: id } });
    if (orderItemCount > 0) {
      return {
        data: null,
        error: { message: `\u8BE5\u5546\u54C1\u5DF2\u6709 ${orderItemCount} \u6761\u8BA2\u5355\u8BB0\u5F55\uFF0C\u4E0D\u80FD\u5220\u9664`, code: "HAS_ORDER_ITEMS" }
      };
    }
    const stockCount = await prisma.stockBatch.count({
      where: { productId: id, currentQty: { gt: 0 } }
    });
    if (stockCount > 0) {
      return {
        data: null,
        error: { message: `\u8BE5\u5546\u54C1\u5C1A\u6709 ${stockCount} \u4E2A\u6279\u6B21\u6709\u5269\u4F59\u5E93\u5B58\uFF0C\u4E0D\u80FD\u5220\u9664`, code: "HAS_STOCK" }
      };
    }
    await prisma.product.delete({ where: { id } });
    return { data: { success: true, action: "deleted" }, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u5220\u9664\u5546\u54C1\u5931\u8D25", code: "DELETE_ERROR" }
    };
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
