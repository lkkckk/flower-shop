import { c as defineEventHandler, k as getQuery, p as prisma } from '../../../_/nitro.mjs';
import { h as hideWholesalePriceForCashier } from '../../../_/productVisibility.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const withStock_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const keyword = query.keyword;
  const category = query.category;
  const categoryId = query.categoryId ? Number(query.categoryId) : void 0;
  const where = { status: "active" };
  if (keyword) {
    where.name = { contains: keyword };
  }
  if (categoryId) {
    const allCats = await prisma.category.findMany({ select: { id: true, parentId: true } });
    const descendantIds = /* @__PURE__ */ new Set([categoryId]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const c of allCats) {
        if (c.parentId && descendantIds.has(c.parentId) && !descendantIds.has(c.id)) {
          descendantIds.add(c.id);
          changed = true;
        }
      }
    }
    where.categoryId = { in: Array.from(descendantIds) };
  } else if (category) {
    where.category = category;
  }
  try {
    const products = await prisma.product.findMany({
      where,
      include: {
        unitConversions: true,
        categoryRef: true,
        recipe: {
          include: {
            items: {
              include: {
                componentProduct: {
                  include: {
                    unitConversions: true,
                    stockBatches: {
                      where: { status: "in_stock", currentQty: { gt: 0 } },
                      select: { currentQty: true }
                    }
                  }
                }
              }
            }
          }
        },
        stockBatches: {
          where: { status: "in_stock", currentQty: { gt: 0 } },
          select: { currentQty: true }
        }
      },
      orderBy: { updatedAt: "desc" }
    });
    const list = products.map((p) => {
      var _a;
      const recipeItems = ((_a = p.recipe) == null ? void 0 : _a.enabled) ? p.recipe.items || [] : [];
      const recipeStock = recipeItems.length > 0 ? Math.min(...recipeItems.map((item) => {
        var _a2;
        const component = item.componentProduct;
        const componentStock = component.stockBatches.reduce((sum, batch) => sum + Number(batch.currentQty || 0), 0);
        const required = item.unit === component.baseUnit ? Number(item.qty || 0) : Number(item.qty || 0) * Number(((_a2 = component.unitConversions.find((u) => u.fromUnit === item.unit)) == null ? void 0 : _a2.toBaseQty) || 1);
        return required > 0 ? componentStock / required : 0;
      })) : null;
      const totalStock = recipeStock === null ? p.stockBatches.reduce((sum, batch) => sum + batch.currentQty, 0) : recipeStock;
      const { stockBatches, ...rest } = p;
      return {
        ...rest,
        totalStock
      };
    });
    return {
      data: { list: hideWholesalePriceForCashier(event, list) },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5E26\u5E93\u5B58\u7684\u5546\u54C1\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { withStock_get as default };
//# sourceMappingURL=with-stock.get.mjs.map
