import { c as defineEventHandler, j as getRouterParam, i as createError, p as prisma } from '../../../_/nitro.mjs';
import { p as productRecipeInclude } from '../../../_/productRecipe.mjs';
import { h as hideWholesalePriceForCashier } from '../../../_/productVisibility.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id)) {
    throw createError({
      statusCode: 400,
      message: "\u65E0\u6548\u7684\u5546\u54C1 ID"
    });
  }
  try {
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        unitConversions: true,
        recipe: { include: productRecipeInclude }
      }
    });
    if (!product) {
      throw createError({
        statusCode: 404,
        message: "\u5546\u54C1\u4E0D\u5B58\u5728",
        data: { code: "NOT_FOUND" }
      });
    }
    return {
      data: hideWholesalePriceForCashier(event, product),
      error: null
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u5546\u54C1\u8BE6\u60C5\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
