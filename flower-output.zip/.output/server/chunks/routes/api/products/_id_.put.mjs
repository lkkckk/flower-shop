import { c as defineEventHandler, j as getRouterParam, r as readBody, i as createError, p as prisma } from '../../../_/nitro.mjs';
import { p as productRecipeInclude, s as saveProductRecipe } from '../../../_/productRecipe.mjs';
import { i as isCashierRequest, h as hideWholesalePriceForCashier } from '../../../_/productVisibility.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  const body = await readBody(event);
  const isCashier = isCashierRequest(event);
  if (isNaN(id)) {
    throw createError({
      statusCode: 400,
      message: "\u65E0\u6548\u7684\u5546\u54C1 ID"
    });
  }
  try {
    const updatedProduct = await prisma.$transaction(async (tx) => {
      var _a, _b;
      await tx.unitConversion.deleteMany({
        where: { productId: id }
      });
      const product = await tx.product.update({
        where: { id },
        data: {
          name: body.name,
          category: body.category,
          categoryId: (_a = body.categoryId) != null ? _a : null,
          baseUnit: body.baseUnit,
          grade: body.grade,
          color: body.color,
          specification: body.specification,
          defaultPrice: body.defaultPrice,
          vipPrice: body.vipPrice,
          wholesalePrice: isCashier ? void 0 : body.wholesalePrice,
          shelfLifeDays: body.shelfLifeDays,
          attributes: body.attributes,
          status: body.status,
          unitConversions: {
            create: ((_b = body.unitConversions) == null ? void 0 : _b.map((uc) => ({
              fromUnit: uc.fromUnit,
              toBaseQty: uc.toBaseQty
            }))) || []
          }
        },
        include: {
          unitConversions: true,
          recipe: { include: productRecipeInclude }
        }
      });
      await saveProductRecipe(tx, id, body.recipe);
      if (body.recipe !== void 0) {
        return await tx.product.findUnique({
          where: { id },
          include: {
            unitConversions: true,
            recipe: { include: productRecipeInclude }
          }
        });
      }
      return product;
    });
    return {
      data: hideWholesalePriceForCashier(event, updatedProduct),
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u66F4\u65B0\u5546\u54C1\u5931\u8D25", code: "UPDATE_ERROR" }
    };
  }
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
