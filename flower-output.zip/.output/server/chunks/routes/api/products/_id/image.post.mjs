import { c as defineEventHandler, j as getRouterParam, p as prisma, m as readMultipartFormData } from '../../../../_/nitro.mjs';
import { mkdir, unlink, writeFile } from 'fs/promises';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const image_post = defineEventHandler(async (event) => {
  const productId = parseInt(getRouterParam(event, "id") || "0");
  if (!productId) {
    return { data: null, error: { message: "\u53C2\u6570\u9519\u8BEF", code: "BAD_PARAMS" } };
  }
  const product = await prisma.product.findUnique({ where: { id: productId }, select: { id: true, imageUrl: true } });
  if (!product) {
    return { data: null, error: { message: "\u5546\u54C1\u4E0D\u5B58\u5728", code: "NOT_FOUND" } };
  }
  const formData = await readMultipartFormData(event);
  const filePart = formData == null ? void 0 : formData.find((p) => p.name === "file");
  if (!(filePart == null ? void 0 : filePart.data) || !filePart.filename) {
    return { data: null, error: { message: "\u672A\u6536\u5230\u6587\u4EF6", code: "NO_FILE" } };
  }
  const ext = path.extname(filePart.filename).toLowerCase();
  const allowed = [".jpg", ".jpeg", ".png", ".webp"];
  if (!allowed.includes(ext)) {
    return { data: null, error: { message: "\u4EC5\u652F\u6301 jpg / png / webp \u683C\u5F0F", code: "INVALID_TYPE" } };
  }
  const uploadDir = path.join(process.cwd(), "public", "products");
  await mkdir(uploadDir, { recursive: true });
  if (product.imageUrl) {
    const oldPath = path.join(process.cwd(), "public", product.imageUrl.replace(/^\//, ""));
    await unlink(oldPath).catch(() => {
    });
  }
  const filename = `${productId}${ext}`;
  const filePath = path.join(uploadDir, filename);
  await writeFile(filePath, filePart.data);
  const imageUrl = `/products/${filename}`;
  const updated = await prisma.product.update({
    where: { id: productId },
    data: { imageUrl },
    select: { imageUrl: true }
  });
  return { data: { imageUrl: updated.imageUrl }, error: null };
});

export { image_post as default };
//# sourceMappingURL=image.post.mjs.map
