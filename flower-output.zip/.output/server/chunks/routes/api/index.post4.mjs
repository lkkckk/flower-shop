import { c as defineEventHandler, r as readBody, p as prisma } from '../../_/nitro.mjs';
import { p as productRecipeInclude, s as saveProductRecipe } from '../../_/productRecipe.mjs';
import { i as isCashierRequest, h as hideWholesalePriceForCashier } from '../../_/productVisibility.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const isCashier = isCashierRequest(event);
  try {
    const product = await prisma.$transaction(async (tx) => {
      var _a, _b;
      const createdProduct = await tx.product.create({
        data: {
          name: body.name,
          category: body.category,
          categoryId: (_a = body.categoryId) != null ? _a : null,
          baseUnit: body.baseUnit,
          grade: body.grade,
          color: body.color,
          specification: body.specification,
          defaultPrice: body.defaultPrice,
          vipPrice: body.vipPrice,
          wholesalePrice: isCashier ? void 0 : body.wholesalePrice,
          shelfLifeDays: body.shelfLifeDays,
          attributes: body.attributes,
          status: body.status || "active",
          unitConversions: {
            create: ((_b = body.unitConversions) == null ? void 0 : _b.map((uc) => ({
              fromUnit: uc.fromUnit,
              toBaseQty: uc.toBaseQty
            }))) || []
          }
        },
        include: {
          unitConversions: true,
          recipe: { include: productRecipeInclude }
        }
      });
      await saveProductRecipe(tx, createdProduct.id, body.recipe);
      if (body.recipe !== void 0) {
        return await tx.product.findUnique({
          where: { id: createdProduct.id },
          include: {
            unitConversions: true,
            recipe: { include: productRecipeInclude }
          }
        });
      }
      return createdProduct;
    });
    return {
      data: hideWholesalePriceForCashier(event, product),
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u521B\u5EFA\u5546\u54C1\u5931\u8D25", code: "CREATE_ERROR" }
    };
  }
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
