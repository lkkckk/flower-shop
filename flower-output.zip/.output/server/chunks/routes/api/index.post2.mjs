import { c as defineEventHandler, r as readBody, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const name = (body.name || "").trim();
  const phone = body.phone ? String(body.phone).trim() : null;
  const address = body.address || null;
  const level = body.level || "normal";
  const notes = body.notes || null;
  if (!name) {
    return {
      data: null,
      error: { message: "\u8BF7\u586B\u5199\u5BA2\u6237\u59D3\u540D", code: "INVALID_PARAMS" }
    };
  }
  if (!["normal", "member", "vip", "wholesale"].includes(level)) {
    return {
      data: null,
      error: { message: "\u5BA2\u6237\u7B49\u7EA7\u4E0D\u5408\u6CD5", code: "INVALID_PARAMS" }
    };
  }
  try {
    if (phone) {
      const exists = await prisma.customer.findUnique({ where: { phone } });
      if (exists) {
        return {
          data: null,
          error: { message: "\u8BE5\u624B\u673A\u53F7\u5DF2\u88AB\u5176\u4ED6\u5BA2\u6237\u4F7F\u7528", code: "PHONE_EXISTS" }
        };
      }
    }
    const customer = await prisma.customer.create({
      data: {
        name,
        phone,
        address,
        level,
        notes
      }
    });
    return { data: customer, error: null };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u521B\u5EFA\u5BA2\u6237\u5931\u8D25", code: "CREATE_ERROR" }
    };
  }
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
