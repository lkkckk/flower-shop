import { c as defineEventHandler, k as getQuery, p as prisma } from '../../_/nitro.mjs';
import dayjs from 'dayjs';
import { c as computeReminderStage } from '../../_/preorderReminder.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const status = query.status;
  const reminderStage = query.reminderStage;
  const keyword = (_a = query.q) == null ? void 0 : _a.trim();
  const deliveryStart = query.deliveryStart ? dayjs(query.deliveryStart).startOf("day").toDate() : void 0;
  const deliveryEnd = query.deliveryEnd ? dayjs(query.deliveryEnd).endOf("day").toDate() : void 0;
  const where = { orderType: "preorder" };
  if (status) where.status = status;
  if (deliveryStart || deliveryEnd) {
    where.deliveryTime = {};
    if (deliveryStart) where.deliveryTime.gte = deliveryStart;
    if (deliveryEnd) where.deliveryTime.lte = deliveryEnd;
  }
  if (keyword) {
    where.OR = [
      { orderNo: { contains: keyword } },
      { receiverName: { contains: keyword } },
      { receiverPhone: { contains: keyword } },
      { customer: { is: { name: { contains: keyword } } } },
      { customer: { is: { phone: { contains: keyword } } } }
    ];
  }
  try {
    const [rawList, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          customer: { select: { id: true, name: true, phone: true, level: true } },
          items: {
            select: {
              id: true,
              productId: true,
              qty: true,
              unit: true,
              subtotal: true,
              imageUrl: true,
              product: { select: { name: true, imageUrl: true } }
            }
          }
        },
        orderBy: [{ deliveryTime: "asc" }, { createdAt: "desc" }],
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.order.count({ where })
    ]);
    const now = /* @__PURE__ */ new Date();
    const list = rawList.map((o) => {
      const stage = computeReminderStage(o.deliveryTime, now);
      if (stage !== o.reminderStage) {
        prisma.order.update({
          where: { id: o.id },
          data: { reminderStage: stage, reminderUpdatedAt: now }
        }).catch(() => {
        });
      }
      return { ...o, reminderStage: stage };
    });
    const filtered = reminderStage ? list.filter((o) => o.reminderStage === reminderStage) : list;
    return {
      data: { list: filtered, total, page, pageSize },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: { message: error.message || "\u83B7\u53D6\u9884\u552E\u5355\u5217\u8868\u5931\u8D25", code: "FETCH_ERROR" }
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get5.mjs.map
