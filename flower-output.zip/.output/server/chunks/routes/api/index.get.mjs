import { c as defineEventHandler, p as prisma } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'dayjs';
import '@prisma/client';
import 'node:url';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async () => {
  var _a, _b;
  const [categories, counts] = await Promise.all([
    prisma.category.findMany({ orderBy: [{ sort: "asc" }, { id: "asc" }] }),
    prisma.product.groupBy({
      by: ["categoryId"],
      where: { status: "active", categoryId: { not: null } },
      _count: { _all: true }
    })
  ]);
  const countMap = /* @__PURE__ */ new Map();
  for (const row of counts) {
    if (row.categoryId != null) countMap.set(row.categoryId, row._count._all);
  }
  const map = /* @__PURE__ */ new Map();
  const roots = [];
  for (const cat of categories) {
    map.set(cat.id, { ...cat, productCount: (_a = countMap.get(cat.id)) != null ? _a : 0, children: [] });
  }
  for (const cat of categories) {
    const node = map.get(cat.id);
    if (cat.parentId) {
      (_b = map.get(cat.parentId)) == null ? void 0 : _b.children.push(node);
    } else {
      roots.push(node);
    }
  }
  return { data: roots, error: null };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
