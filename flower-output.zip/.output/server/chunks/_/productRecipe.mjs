const productRecipeInclude = {
  items: {
    orderBy: { sort: "asc" },
    include: {
      componentProduct: {
        select: {
          id: true,
          name: true,
          baseUnit: true,
          imageUrl: true,
          status: true,
          unitConversions: true
        }
      }
    }
  }
};
async function detectRecipeCycle(tx, rootProductId, initialComponentIds) {
  const visited = /* @__PURE__ */ new Set([rootProductId]);
  const queue = [...initialComponentIds];
  while (queue.length) {
    const current = queue.shift();
    if (current === rootProductId) {
      throw Object.assign(new Error("\u914D\u65B9\u5B58\u5728\u5FAA\u73AF\u5F15\u7528"), { code: "RECIPE_CYCLE" });
    }
    if (visited.has(current)) continue;
    visited.add(current);
    const sub = await tx.productRecipe.findUnique({
      where: { productId: current },
      include: { items: { select: { componentProductId: true } } }
    });
    if (!sub) continue;
    for (const item of sub.items) queue.push(item.componentProductId);
  }
}
function normalizeRecipeItems(recipe) {
  return Array.isArray(recipe == null ? void 0 : recipe.items) ? recipe.items.map((item, index) => ({
    componentProductId: Number(item.componentProductId),
    qty: Number(item.qty),
    unit: String(item.unit || "").trim(),
    sort: Number.isFinite(Number(item.sort)) ? Number(item.sort) : index,
    notes: item.notes || null
  })).filter((item) => item.componentProductId && item.qty > 0 && item.unit) : [];
}
async function saveProductRecipe(tx, productId, recipe) {
  if (recipe === void 0) return;
  await tx.productRecipe.deleteMany({ where: { productId } });
  const items = normalizeRecipeItems(recipe);
  const enabled = Boolean(recipe == null ? void 0 : recipe.enabled);
  const notes = (recipe == null ? void 0 : recipe.notes) || null;
  if (!enabled && items.length === 0 && !notes) return;
  const componentIds = items.map((item) => item.componentProductId);
  if (componentIds.includes(productId)) {
    throw Object.assign(new Error("\u914D\u65B9\u7EC4\u4EF6\u4E0D\u80FD\u9009\u62E9\u5546\u54C1\u81EA\u8EAB"), { code: "INVALID_RECIPE" });
  }
  const uniqueComponentIds = new Set(componentIds);
  if (uniqueComponentIds.size !== componentIds.length) {
    throw Object.assign(new Error("\u914D\u65B9\u7EC4\u4EF6\u4E0D\u80FD\u91CD\u590D"), { code: "INVALID_RECIPE" });
  }
  await detectRecipeCycle(tx, productId, componentIds);
  const components = await tx.product.findMany({
    where: { id: { in: componentIds } },
    include: { unitConversions: true }
  });
  const componentMap = new Map(components.map((product) => [product.id, product]));
  for (const item of items) {
    const component = componentMap.get(item.componentProductId);
    if (!component) {
      throw Object.assign(new Error(`\u914D\u65B9\u7EC4\u4EF6(id=${item.componentProductId})\u4E0D\u5B58\u5728`), {
        code: "INVALID_RECIPE"
      });
    }
    const units = /* @__PURE__ */ new Set([
      component.baseUnit,
      ...component.unitConversions.map((conversion) => conversion.fromUnit)
    ]);
    if (!units.has(item.unit)) {
      throw Object.assign(new Error(`\u7EC4\u4EF6\u3010${component.name}\u3011\u4E0D\u652F\u6301\u5355\u4F4D ${item.unit}`), {
        code: "INVALID_RECIPE"
      });
    }
  }
  await tx.productRecipe.create({
    data: {
      productId,
      enabled,
      notes,
      items: {
        create: items.map((item) => ({
          componentProductId: item.componentProductId,
          qty: item.qty,
          unit: item.unit,
          sort: item.sort,
          notes: item.notes
        }))
      }
    }
  });
}

export { productRecipeInclude as p, saveProductRecipe as s };
//# sourceMappingURL=productRecipe.mjs.map
