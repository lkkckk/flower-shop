function computeReminderStage(deliveryTime, now = /* @__PURE__ */ new Date()) {
  if (!deliveryTime) return "none";
  const delivery = typeof deliveryTime === "string" ? new Date(deliveryTime) : deliveryTime;
  if (Number.isNaN(delivery.getTime())) return "none";
  const startOfDay = (d) => {
    const x = new Date(d);
    x.setHours(0, 0, 0, 0);
    return x;
  };
  const dayDiff = Math.round(
    (startOfDay(delivery).getTime() - startOfDay(now).getTime()) / 864e5
  );
  if (dayDiff < 0) return "overdue";
  if (dayDiff === 0) return "due";
  if (dayDiff <= 3) return "d3";
  if (dayDiff <= 7) return "d7";
  return "none";
}
function daysUntil(deliveryTime, now = /* @__PURE__ */ new Date()) {
  if (!deliveryTime) return null;
  const d = typeof deliveryTime === "string" ? new Date(deliveryTime) : deliveryTime;
  if (Number.isNaN(d.getTime())) return null;
  const startOfDay = (x) => {
    const r = new Date(x);
    r.setHours(0, 0, 0, 0);
    return r;
  };
  return Math.round((startOfDay(d).getTime() - startOfDay(now).getTime()) / 864e5);
}

export { computeReminderStage as c, daysUntil as d };
//# sourceMappingURL=preorderReminder.mjs.map
