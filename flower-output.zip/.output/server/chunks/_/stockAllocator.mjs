function toBaseQty(product, unit, qty) {
  var _a;
  if (!unit || unit === product.baseUnit) return qty;
  const conversion = (_a = product.unitConversions) == null ? void 0 : _a.find((u) => u.fromUnit === unit);
  return qty * Number((conversion == null ? void 0 : conversion.toBaseQty) || 1);
}
function addRequirement(map, req) {
  const existing = map.get(req.productId);
  if (existing) {
    existing.requiredQty += req.requiredQty;
  } else {
    map.set(req.productId, { ...req });
  }
}
async function buildDeductionPlans(tx, items) {
  const productIds = Array.from(new Set(items.map((item) => Number(item.productId)).filter(Boolean)));
  const products = await tx.product.findMany({
    where: { id: { in: productIds } },
    include: {
      unitConversions: true,
      recipe: {
        include: {
          items: {
            orderBy: { sort: "asc" },
            include: {
              componentProduct: { include: { unitConversions: true } }
            }
          }
        }
      }
    }
  });
  const productMap = new Map(products.map((product) => [product.id, product]));
  const requirementMap = /* @__PURE__ */ new Map();
  const plans = items.map((item) => {
    const product = productMap.get(Number(item.productId));
    if (!product) {
      throw Object.assign(new Error(`\u5546\u54C1(id=${item.productId})\u4E0D\u5B58\u5728`), { code: "PRODUCT_NOT_FOUND" });
    }
    const recipe = product.recipe;
    const recipeItems = (recipe == null ? void 0 : recipe.enabled) ? recipe.items || [] : [];
    if (recipeItems.length > 0) {
      const components = recipeItems.map((recipeItem) => {
        const component = recipeItem.componentProduct;
        const requiredQty2 = toBaseQty(component, recipeItem.unit, Number(item.baseQty) * Number(recipeItem.qty));
        const componentReq = {
          productId: component.id,
          productName: component.name,
          baseUnit: component.baseUnit,
          requiredQty: requiredQty2
        };
        addRequirement(requirementMap, componentReq);
        return componentReq;
      });
      return { kind: "recipe", item, components };
    }
    const requiredQty = Number(item.baseQty);
    const directReq = {
      productId: Number(item.productId),
      productName: product.name || item.productName || String(item.productId),
      baseUnit: product.baseUnit,
      requiredQty
    };
    addRequirement(requirementMap, directReq);
    return { kind: "direct", item, ...directReq };
  });
  return { plans, requirements: Array.from(requirementMap.values()) };
}
async function assertEnoughStock(tx, requirements) {
  const shortages = [];
  for (const req of requirements) {
    const batches = await tx.stockBatch.findMany({
      where: { productId: req.productId, status: "in_stock", currentQty: { gt: 0 } },
      select: { currentQty: true }
    });
    const availableQty = batches.reduce((sum, batch) => sum + Number(batch.currentQty || 0), 0);
    if (availableQty + 1e-8 < req.requiredQty) {
      shortages.push({
        productId: req.productId,
        productName: req.productName,
        requiredQty: req.requiredQty,
        availableQty,
        shortageQty: req.requiredQty - availableQty,
        unit: req.baseUnit
      });
    }
  }
  if (shortages.length > 0) {
    const message = shortages.map((item) => `${item.productName} \u7F3A ${Number(item.shortageQty).toFixed(2)} ${item.unit}`).join("\uFF1B");
    throw Object.assign(new Error(`\u5E93\u5B58\u4E0D\u8DB3\uFF1A${message}`), {
      code: "INSUFFICIENT_STOCK",
      shortages
    });
  }
}
async function deductStockOnly(tx, orderId, requirement, operator) {
  let remaining = Number(requirement.requiredQty);
  if (remaining <= 0) return;
  const batches = await tx.stockBatch.findMany({
    where: { productId: requirement.productId, status: "in_stock", currentQty: { gt: 0 } },
    orderBy: { inboundDate: "asc" }
  });
  for (const batch of batches) {
    if (remaining <= 0) break;
    const take = Math.min(batch.currentQty, remaining);
    remaining -= take;
    const newQty = batch.currentQty - take;
    await tx.stockBatch.update({
      where: { id: batch.id },
      data: {
        currentQty: newQty,
        status: newQty <= 0 ? "sold_out" : "in_stock"
      }
    });
    await tx.stockMovement.create({
      data: {
        batchId: batch.id,
        type: "sale",
        qtyChange: -take,
        relatedOrderId: orderId,
        operator,
        notes: "\u914D\u65B9\u7EC4\u4EF6\u6263\u51CF"
      }
    });
  }
}
async function deductDirectAndCreateItems(tx, orderId, plan, operator) {
  var _a, _b, _c, _d, _e;
  const item = plan.item;
  let remaining = Number(plan.requiredQty);
  const totalBase = remaining;
  if (totalBase <= 0) return;
  const batches = await tx.stockBatch.findMany({
    where: { productId: plan.productId, status: "in_stock", currentQty: { gt: 0 } },
    orderBy: { inboundDate: "asc" }
  });
  for (const batch of batches) {
    if (remaining <= 0) break;
    const take = Math.min(batch.currentQty, remaining);
    remaining -= take;
    const newQty = batch.currentQty - take;
    await tx.stockBatch.update({
      where: { id: batch.id },
      data: {
        currentQty: newQty,
        status: newQty <= 0 ? "sold_out" : "in_stock"
      }
    });
    await tx.stockMovement.create({
      data: {
        batchId: batch.id,
        type: "sale",
        qtyChange: -take,
        relatedOrderId: orderId,
        operator
      }
    });
    const proportion = take / totalBase;
    await tx.orderItem.create({
      data: {
        orderId,
        productId: item.productId,
        batchId: batch.id,
        unit: item.unit,
        qty: Number(item.qty) * proportion,
        baseQty: take,
        unitPrice: item.unitPrice,
        originalPrice: (_a = item.originalPrice) != null ? _a : null,
        subtotal: item.subtotal * proportion,
        grade: (_b = item.grade) != null ? _b : null,
        color: (_c = item.color) != null ? _c : null,
        notes: (_d = item.notes) != null ? _d : null,
        imageUrl: (_e = item.imageUrl) != null ? _e : null
      }
    });
  }
}
async function allocateAndDeduct(tx, orderId, items, operator = "system") {
  var _a, _b, _c, _d, _e;
  const { plans, requirements } = await buildDeductionPlans(tx, items);
  await assertEnoughStock(tx, requirements);
  for (const plan of plans) {
    if (plan.kind === "direct") {
      await deductDirectAndCreateItems(tx, orderId, plan, operator);
    } else {
      const item = plan.item;
      await tx.orderItem.create({
        data: {
          orderId,
          productId: item.productId,
          batchId: null,
          unit: item.unit,
          qty: Number(item.qty),
          baseQty: Number(item.baseQty),
          unitPrice: item.unitPrice,
          originalPrice: (_a = item.originalPrice) != null ? _a : null,
          subtotal: item.subtotal,
          grade: (_b = item.grade) != null ? _b : null,
          color: (_c = item.color) != null ? _c : null,
          notes: (_d = item.notes) != null ? _d : null,
          imageUrl: (_e = item.imageUrl) != null ? _e : null
        }
      });
      for (const component of plan.components) {
        await deductStockOnly(tx, orderId, component, operator);
      }
    }
  }
}
async function allocatePreorderItems(tx, orderId, operator = "system") {
  const placeholders = await tx.orderItem.findMany({
    where: { orderId, batchId: null },
    include: { product: { select: { name: true } } }
  });
  if (placeholders.length === 0) return;
  const items = placeholders.map((row) => {
    var _a;
    return {
      productId: row.productId,
      unit: row.unit,
      qty: row.qty,
      baseQty: row.baseQty,
      unitPrice: row.unitPrice,
      subtotal: row.subtotal,
      originalPrice: row.originalPrice,
      imageUrl: row.imageUrl,
      productName: (_a = row.product) == null ? void 0 : _a.name,
      grade: row.grade,
      color: row.color,
      notes: row.notes
    };
  });
  await tx.orderItem.deleteMany({ where: { orderId, batchId: null } });
  await allocateAndDeduct(tx, orderId, items, operator);
}

export { allocateAndDeduct as a, allocatePreorderItems as b };
//# sourceMappingURL=stockAllocator.mjs.map
