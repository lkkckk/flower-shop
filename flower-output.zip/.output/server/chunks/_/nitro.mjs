import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http from 'node:http';
import https from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import dayjs from 'dayjs';
import prismaClientPkg from '@prisma/client';
import { fileURLToPath } from 'node:url';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/");
  }
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/") ? input : input + "/";
  }
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c=class{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c.prototype,i$1.prototype),Object.assign(c.prototype,l$1.prototype),c}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function parse(multipartBodyBuffer, boundary) {
  let lastline = "";
  let state = 0 /* INIT */;
  let buffer = [];
  const allParts = [];
  let currentPartHeaders = [];
  for (let i = 0; i < multipartBodyBuffer.length; i++) {
    const prevByte = i > 0 ? multipartBodyBuffer[i - 1] : null;
    const currByte = multipartBodyBuffer[i];
    const newLineChar = currByte === 10 || currByte === 13;
    if (!newLineChar) {
      lastline += String.fromCodePoint(currByte);
    }
    const newLineDetected = currByte === 10 && prevByte === 13;
    if (0 /* INIT */ === state && newLineDetected) {
      if ("--" + boundary === lastline) {
        state = 1 /* READING_HEADERS */;
      }
      lastline = "";
    } else if (1 /* READING_HEADERS */ === state && newLineDetected) {
      if (lastline.length > 0) {
        const i2 = lastline.indexOf(":");
        if (i2 > 0) {
          const name = lastline.slice(0, i2).toLowerCase();
          const value = lastline.slice(i2 + 1).trim();
          currentPartHeaders.push([name, value]);
        }
      } else {
        state = 2 /* READING_DATA */;
        buffer = [];
      }
      lastline = "";
    } else if (2 /* READING_DATA */ === state) {
      if (lastline.length > boundary.length + 4) {
        lastline = "";
      }
      if ("--" + boundary === lastline) {
        const j = buffer.length - lastline.length;
        const part = buffer.slice(0, j - 1);
        allParts.push(process$1(part, currentPartHeaders));
        buffer = [];
        currentPartHeaders = [];
        lastline = "";
        state = 3 /* READING_PART_SEPARATOR */;
      } else {
        buffer.push(currByte);
      }
      if (newLineDetected) {
        lastline = "";
      }
    } else if (3 /* READING_PART_SEPARATOR */ === state && newLineDetected) {
      state = 1 /* READING_HEADERS */;
    }
  }
  return allParts;
}
function process$1(data, headers) {
  const dataObj = {};
  const contentDispositionHeader = headers.find((h) => h[0] === "content-disposition")?.[1] || "";
  for (const i of contentDispositionHeader.split(";")) {
    const s = i.split("=");
    if (s.length !== 2) {
      continue;
    }
    const key = (s[0] || "").trim();
    if (key === "name" || key === "filename") {
      const _value = (s[1] || "").trim().replace(/"/g, "");
      dataObj[key] = Buffer.from(_value, "latin1").toString("utf8");
    }
  }
  const contentType = headers.find((h) => h[0] === "content-type")?.[1] || "";
  if (contentType) {
    dataObj.type = contentType;
  }
  dataObj.data = Buffer.from(data);
  return dataObj;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}
function getRequestIP(event, opts = {}) {
  if (event.context.clientAddress) {
    return event.context.clientAddress;
  }
  if (opts.xForwardedFor) {
    const xForwardedFor = getRequestHeader(event, "x-forwarded-for")?.split(",").shift()?.trim();
    if (xForwardedFor) {
      return xForwardedFor;
    }
  }
  if (event.node.req.socket.remoteAddress) {
    return event.node.req.socket.remoteAddress;
  }
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
async function readMultipartFormData(event) {
  const contentType = getRequestHeader(event, "content-type");
  if (!contentType || !contentType.startsWith("multipart/form-data")) {
    return;
  }
  const boundary = contentType.match(/boundary=([^;]*)(;|$)/i)?.[1];
  if (!boundary) {
    return;
  }
  const body = await readRawBody(event, false);
  if (!body) {
    return;
  }
  return parse(body, boundary);
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
createFetch({ fetch, Headers: Headers$1, AbortController });

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {}
};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "c4cc670e-c6a6-4ae8-9adf-3b493661f78d",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/api/**": {
        "cors": true,
        "headers": {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "*",
          "access-control-allow-headers": "*",
          "access-control-max-age": "0",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Max-Age": "86400"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable",
          "Cache-Control": "public, max-age=31536000, immutable"
        }
      },
      "/images/**": {
        "headers": {
          "Cache-Control": "public, max-age=86400"
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      }
    }
  },
  "public": {}
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

/**
* Nitro internal functions extracted from https://github.com/nitrojs/nitro/blob/v2/src/runtime/internal/utils.ts
*/
function isJsonRequest(event) {
	// If the client specifically requests HTML, then avoid classifying as JSON.
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		// let Nitro handle JSON errors
		return;
	}
	// invoke default Nitro error handler (which will log appropriately if required)
	const defaultRes = await defaultHandler(error, event, { json: true });
	// let Nitro handle redirect if appropriate
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	// remove proto/hostname/port from URL
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	// add default server message (keep sanitized for unhandled errors)
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	// we will be rendering this error internally so we can pass along the error.data safely
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	// Access request headers
	const reqHeaders = getRequestHeaders(event);
	// Detect to avoid recursion in SSR rendering of errors
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
	// HTML response (via SSR)
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	// Fallback to static rendered error page
	if (!res) {
		const { template } = await import('./error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

function defineNitroPlugin(def) {
  return def;
}

var _a;
const { PrismaClient } = prismaClientPkg;
const globalForPrisma = globalThis;
const prisma = (_a = globalForPrisma.prisma) != null ? _a : new PrismaClient();

async function loadSettings() {
  const rows = await prisma.setting.findMany({
    where: { key: { in: ["lowStockThreshold", "expiringDays", "debtOverdueDays", "safetyStockDays"] } }
  });
  const map = {};
  for (const r of rows) map[r.key] = r.value;
  return map;
}
const todayKey = () => dayjs().format("YYYY-MM-DD");
async function upsertNotification(params) {
  const dedupeKey = `${params.type}:${params.refId}:${todayKey()}`;
  try {
    await prisma.notification.upsert({
      where: { dedupeKey },
      create: {
        type: params.type,
        level: params.level || "info",
        title: params.title,
        body: params.body,
        refType: params.refType,
        refId: params.refId,
        dedupeKey
      },
      update: {
        // 已存在则不动 readAt / createdAt，仅刷新文案与级别（数字可能变了）
        title: params.title,
        body: params.body,
        level: params.level || "info"
      }
    });
  } catch {
  }
}
async function genLowStock(settings) {
  var _a, _b;
  const threshold = Math.max(1, Number(settings.lowStockThreshold) || 10);
  const products = await prisma.product.findMany({
    where: { status: "active" },
    select: { id: true, name: true, baseUnit: true }
  });
  const stockAgg = await prisma.stockBatch.groupBy({
    by: ["productId"],
    where: { status: { in: ["in_stock", "discounted"] } },
    _sum: { currentQty: true }
  });
  const stockMap = /* @__PURE__ */ new Map();
  for (const r of stockAgg) stockMap.set(r.productId, (_a = r._sum.currentQty) != null ? _a : 0);
  for (const p of products) {
    const stock = (_b = stockMap.get(p.id)) != null ? _b : 0;
    if (stock < threshold) {
      await upsertNotification({
        type: "low_stock",
        level: stock === 0 ? "urgent" : "warn",
        title: stock === 0 ? `${p.name} \u5DF2\u65E0\u5E93\u5B58` : `${p.name} \u5E93\u5B58\u504F\u4F4E`,
        body: `\u5F53\u524D\u5728\u5E93 ${stock} ${p.baseUnit}\uFF0C\u9608\u503C ${threshold}\uFF0C\u5EFA\u8BAE\u5C3D\u5FEB\u8865\u8D27\u3002`,
        refType: "product",
        refId: p.id
      });
    }
  }
}
async function genExpiringBatch(settings) {
  const days = Math.max(1, Number(settings.expiringDays) || 3);
  const now = /* @__PURE__ */ new Date();
  const until = dayjs().add(days, "day").endOf("day").toDate();
  const batches = await prisma.stockBatch.findMany({
    where: {
      status: { in: ["in_stock", "discounted"] },
      currentQty: { gt: 0 },
      expiryDate: { gte: now, lte: until }
    },
    include: { product: { select: { name: true, baseUnit: true } } }
  });
  for (const b of batches) {
    const daysLeft = Math.max(0, Math.ceil((b.expiryDate.getTime() - now.getTime()) / 864e5));
    await upsertNotification({
      type: "expiring_batch",
      level: daysLeft <= 1 ? "urgent" : "warn",
      title: `${b.product.name} \u6279\u6B21 ${b.batchNo} \u4E34\u671F`,
      body: `\u5269\u4F59 ${b.currentQty} ${b.product.baseUnit}\uFF0C${daysLeft === 0 ? "\u4ECA\u65E5\u5230\u671F" : `\u8FD8\u6709 ${daysLeft} \u5929\u5230\u671F`}\u3002`,
      refType: "batch",
      refId: b.id
    });
  }
}
async function genDebtOverdue(settings) {
  var _a;
  const days = Math.max(1, Number(settings.debtOverdueDays) || 30);
  const threshold = dayjs().subtract(days, "day").toDate();
  const debtors = await prisma.customer.findMany({
    where: { totalOwed: { gt: 0 } },
    select: { id: true, name: true, totalOwed: true }
  });
  if (debtors.length === 0) return;
  const lastOrders = await prisma.order.groupBy({
    by: ["customerId"],
    where: { customerId: { in: debtors.map((d) => d.id) } },
    _max: { createdAt: true }
  });
  const lastMap = /* @__PURE__ */ new Map();
  for (const r of lastOrders) {
    if (r.customerId != null) lastMap.set(r.customerId, (_a = r._max.createdAt) != null ? _a : null);
  }
  for (const d of debtors) {
    const last = lastMap.get(d.id);
    if (!last) continue;
    if (last <= threshold) {
      const daysAgo = Math.floor((Date.now() - last.getTime()) / 864e5);
      await upsertNotification({
        type: "debt_overdue",
        level: "warn",
        title: `${d.name} \u6B20\u6B3E\u5DF2 ${daysAgo} \u5929\u672A\u8FD8`,
        body: `\u5F53\u524D\u7D2F\u8BA1\u6B20\u6B3E \xA5${d.totalOwed.toFixed(2)}\uFF0C\u6700\u8FD1\u4E00\u6B21\u4E0B\u5355 ${dayjs(last).format("YYYY-MM-DD")}\u3002`,
        refType: "customer",
        refId: d.id
      });
    }
  }
}
async function genAnomalyOrder() {
  var _a;
  const since = dayjs().subtract(24, "hour").toDate();
  const avgAgg = await prisma.order.aggregate({
    where: {
      orderType: { not: "preorder" },
      status: { not: "cancelled" },
      createdAt: { gte: dayjs().subtract(30, "day").toDate() }
    },
    _avg: { totalAmount: true }
  });
  const avgAmount = avgAgg._avg.totalAmount || 0;
  const largeAmountThreshold = Math.max(1e3, avgAmount * 3);
  const orders = await prisma.order.findMany({
    where: {
      orderType: { not: "preorder" },
      status: { not: "cancelled" },
      createdAt: { gte: since },
      OR: [
        { totalAmount: { gte: largeAmountThreshold } },
        { discountRate: { lte: 70 } },
        { owedAmount: { gte: 300 } }
      ]
    },
    include: { customer: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 50
  });
  for (const o of orders) {
    const reasons = [];
    if (o.totalAmount >= largeAmountThreshold) {
      reasons.push(`\u91D1\u989D \xA5${o.totalAmount.toFixed(2)} \u9AD8\u4E8E\u5F02\u5E38\u9608\u503C \xA5${largeAmountThreshold.toFixed(2)}`);
    }
    if (o.discountRate !== null && o.discountRate !== void 0 && o.discountRate <= 70) {
      reasons.push(`\u6298\u6263\u7387 ${o.discountRate}% \u504F\u4F4E`);
    }
    if (o.owedAmount >= 300) {
      reasons.push(`\u672A\u6536 \xA5${o.owedAmount.toFixed(2)}`);
    }
    if (reasons.length === 0) continue;
    await upsertNotification({
      type: "anomaly_order",
      level: o.owedAmount >= 300 || o.totalAmount >= largeAmountThreshold * 1.5 ? "urgent" : "warn",
      title: `\u8BA2\u5355 ${o.orderNo} \u53EF\u80FD\u5F02\u5E38`,
      body: `${((_a = o.customer) == null ? void 0 : _a.name) || "\u6563\u5BA2"} \xB7 ${reasons.join("\uFF1B")}\u3002`,
      refType: "order",
      refId: o.id
    });
  }
}
async function pruneOldNotifications() {
  const cutoff = dayjs().subtract(90, "day").toDate();
  await prisma.notification.deleteMany({ where: { createdAt: { lt: cutoff } } });
}
async function generateNotifications() {
  const settings = await loadSettings();
  await Promise.all([
    genLowStock(settings),
    genExpiringBatch(settings),
    genDebtOverdue(settings),
    genAnomalyOrder()
  ]);
  await pruneOldNotifications();
}

const INTERVAL_MS = 30 * 60 * 1e3;
const FIRST_DELAY_MS = 60 * 1e3;
const _bixvcRNJTYee9vmm9zpDvDWdfWXnNhbnyS_IQB6CLOc = defineNitroPlugin(() => {
  if (process.env.NOTIFICATION_TICK_DISABLED === "1") return;
  const safeRun = async () => {
    try {
      await generateNotifications();
    } catch (e) {
      console.error("[notification-tick] failed:", e);
    }
  };
  setTimeout(() => {
    safeRun();
    setInterval(safeRun, INTERVAL_MS);
  }, FIRST_DELAY_MS);
});

const plugins = [
  _bixvcRNJTYee9vmm9zpDvDWdfWXnNhbnyS_IQB6CLOc
];

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2026-05-19T11:27:00.957Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1a-a1cIDLljyn/zLf+iveG+HSGws5Y\"",
    "mtime": "2026-05-19T11:27:00.958Z",
    "size": 26,
    "path": "../public/robots.txt"
  },
  "/css/nuxt-google-fonts.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"4864-Z+G6mqYjsr4bUcCKJ/RAlvHGEAg\"",
    "mtime": "2026-05-20T15:26:05.553Z",
    "size": 18532,
    "path": "../public/css/nuxt-google-fonts.css.br"
  },
  "/css/nuxt-google-fonts.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"260d6-Fy0J4h0biV7kIuEo4co9ZQQBiKA\"",
    "mtime": "2026-05-20T15:26:05.464Z",
    "size": 155862,
    "path": "../public/css/nuxt-google-fonts.css.gz"
  },
  "/fonts/Noto_Sans_SC-normal-400-cyrillic.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-19T14:13:21.221Z",
    "size": 10008,
    "path": "../public/fonts/Noto_Sans_SC-normal-400-cyrillic.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-400-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-19T14:13:21.426Z",
    "size": 8244,
    "path": "../public/fonts/Noto_Sans_SC-normal-400-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-400-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-19T14:13:21.535Z",
    "size": 25240,
    "path": "../public/fonts/Noto_Sans_SC-normal-400-latin.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-400-text.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-19T14:13:21.127Z",
    "size": 76800,
    "path": "../public/fonts/Noto_Sans_SC-normal-400-text.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-400-vietnamese.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-19T14:13:21.326Z",
    "size": 9096,
    "path": "../public/fonts/Noto_Sans_SC-normal-400-vietnamese.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-500-cyrillic.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-19T14:13:21.221Z",
    "size": 10008,
    "path": "../public/fonts/Noto_Sans_SC-normal-500-cyrillic.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-500-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-19T14:13:21.426Z",
    "size": 8244,
    "path": "../public/fonts/Noto_Sans_SC-normal-500-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-500-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-19T14:13:21.535Z",
    "size": 25240,
    "path": "../public/fonts/Noto_Sans_SC-normal-500-latin.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-500-text.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-19T14:13:21.127Z",
    "size": 76800,
    "path": "../public/fonts/Noto_Sans_SC-normal-500-text.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-500-vietnamese.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-19T14:13:21.326Z",
    "size": 9096,
    "path": "../public/fonts/Noto_Sans_SC-normal-500-vietnamese.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-600-cyrillic.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-19T14:13:21.221Z",
    "size": 10008,
    "path": "../public/fonts/Noto_Sans_SC-normal-600-cyrillic.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-600-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-19T14:13:21.426Z",
    "size": 8244,
    "path": "../public/fonts/Noto_Sans_SC-normal-600-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-600-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-19T14:13:21.535Z",
    "size": 25240,
    "path": "../public/fonts/Noto_Sans_SC-normal-600-latin.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-600-text.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-19T14:13:21.127Z",
    "size": 76800,
    "path": "../public/fonts/Noto_Sans_SC-normal-600-text.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-700-cyrillic.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-19T14:13:21.221Z",
    "size": 10008,
    "path": "../public/fonts/Noto_Sans_SC-normal-700-cyrillic.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-600-vietnamese.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-19T14:13:21.326Z",
    "size": 9096,
    "path": "../public/fonts/Noto_Sans_SC-normal-600-vietnamese.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-700-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-19T14:13:21.426Z",
    "size": 8244,
    "path": "../public/fonts/Noto_Sans_SC-normal-700-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-700-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-19T14:13:21.535Z",
    "size": 25240,
    "path": "../public/fonts/Noto_Sans_SC-normal-700-latin.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-700-text.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-19T14:13:21.127Z",
    "size": 76800,
    "path": "../public/fonts/Noto_Sans_SC-normal-700-text.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-700-vietnamese.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-19T14:13:21.326Z",
    "size": 9096,
    "path": "../public/fonts/Noto_Sans_SC-normal-700-vietnamese.woff2"
  },
  "/css/nuxt-google-fonts.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"812e1-DWT+n6ImnYHgmnMNjXQgLsjU4/g\"",
    "mtime": "2026-05-19T14:13:22.059Z",
    "size": 529121,
    "path": "../public/css/nuxt-google-fonts.css"
  },
  "/fonts/Noto_Sans_SC-normal-800-cyrillic.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-19T14:13:21.221Z",
    "size": 10008,
    "path": "../public/fonts/Noto_Sans_SC-normal-800-cyrillic.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-800-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-19T14:13:21.426Z",
    "size": 8244,
    "path": "../public/fonts/Noto_Sans_SC-normal-800-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-800-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-19T14:13:21.535Z",
    "size": 25240,
    "path": "../public/fonts/Noto_Sans_SC-normal-800-latin.woff2"
  },
  "/fonts/Outfit-normal-400-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-19T14:13:21.826Z",
    "size": 14808,
    "path": "../public/fonts/Outfit-normal-400-latin-ext.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-800-vietnamese.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-19T14:13:21.326Z",
    "size": 9096,
    "path": "../public/fonts/Noto_Sans_SC-normal-800-vietnamese.woff2"
  },
  "/fonts/Noto_Sans_SC-normal-800-text.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-19T14:13:21.127Z",
    "size": 76800,
    "path": "../public/fonts/Noto_Sans_SC-normal-800-text.woff2"
  },
  "/fonts/Outfit-normal-400-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-19T14:13:21.936Z",
    "size": 32292,
    "path": "../public/fonts/Outfit-normal-400-latin.woff2"
  },
  "/fonts/Outfit-normal-500-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-19T14:13:21.826Z",
    "size": 14808,
    "path": "../public/fonts/Outfit-normal-500-latin-ext.woff2"
  },
  "/fonts/Outfit-normal-500-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-19T14:13:21.936Z",
    "size": 32292,
    "path": "../public/fonts/Outfit-normal-500-latin.woff2"
  },
  "/fonts/Outfit-normal-600-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-19T14:13:21.826Z",
    "size": 14808,
    "path": "../public/fonts/Outfit-normal-600-latin-ext.woff2"
  },
  "/fonts/Outfit-normal-600-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-19T14:13:21.936Z",
    "size": 32292,
    "path": "../public/fonts/Outfit-normal-600-latin.woff2"
  },
  "/fonts/Outfit-normal-700-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-19T14:13:21.826Z",
    "size": 14808,
    "path": "../public/fonts/Outfit-normal-700-latin-ext.woff2"
  },
  "/fonts/Outfit-normal-700-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-19T14:13:21.936Z",
    "size": 32292,
    "path": "../public/fonts/Outfit-normal-700-latin.woff2"
  },
  "/fonts/Outfit-normal-800-latin-ext.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-19T14:13:21.826Z",
    "size": 14808,
    "path": "../public/fonts/Outfit-normal-800-latin-ext.woff2"
  },
  "/_nuxt/-14QgBge.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5022-7TFdWcs3/0aR1u/qeoOeVmCpBzI\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 20514,
    "path": "../public/_nuxt/-14QgBge.js"
  },
  "/fonts/Outfit-normal-800-latin.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-19T14:13:21.936Z",
    "size": 32292,
    "path": "../public/fonts/Outfit-normal-800-latin.woff2"
  },
  "/_nuxt/-14QgBge.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"14f9-IU5S70ljH1gl7Qj43BYtqQxXU78\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 5369,
    "path": "../public/_nuxt/-14QgBge.js.br"
  },
  "/_nuxt/-14QgBge.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"174f-nsBffeMW7PKHZB7yUxMMHGO8pJQ\"",
    "mtime": "2026-05-20T15:26:05.405Z",
    "size": 5967,
    "path": "../public/_nuxt/-14QgBge.js.gz"
  },
  "/_nuxt/2-I7jChq.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"865-FzEJjSRQqd893cqR4BxBEucmz/o\"",
    "mtime": "2026-05-20T15:26:05.405Z",
    "size": 2149,
    "path": "../public/_nuxt/2-I7jChq.js.br"
  },
  "/_nuxt/2-I7jChq.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"14e5-ArlG7rxTTLyqvHqygyTtN48zGTQ\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 5349,
    "path": "../public/_nuxt/2-I7jChq.js"
  },
  "/_nuxt/2-I7jChq.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"958-2irmwH1ZsKI8sXH+Db2yMJ87jtQ\"",
    "mtime": "2026-05-20T15:26:05.405Z",
    "size": 2392,
    "path": "../public/_nuxt/2-I7jChq.js.gz"
  },
  "/_nuxt/3HZhupU9.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"192e-s63KQhBncKVr6ypAn5rXOokSGxo\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 6446,
    "path": "../public/_nuxt/3HZhupU9.js"
  },
  "/_nuxt/3HZhupU9.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"8bd-E3bHgKo0mw5yJXFSOkuI/20jXSs\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 2237,
    "path": "../public/_nuxt/3HZhupU9.js.br"
  },
  "/_nuxt/3HZhupU9.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9b6-SXw2/38AGp4HCh60l9H4YIBD3E4\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 2486,
    "path": "../public/_nuxt/3HZhupU9.js.gz"
  },
  "/_nuxt/AOmwrEs0.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2343-oXhswpvYYXgL4b+gaT9GLA15xq4\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 9027,
    "path": "../public/_nuxt/AOmwrEs0.js"
  },
  "/_nuxt/AOmwrEs0.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c3f-3w1hR2NNsqPVeA2tQQBrxoX9XDE\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 3135,
    "path": "../public/_nuxt/AOmwrEs0.js.br"
  },
  "/_nuxt/AOmwrEs0.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e8f-OGx906HTfWJiBHq5bVlh9BEE0ik\"",
    "mtime": "2026-05-20T15:26:05.406Z",
    "size": 3727,
    "path": "../public/_nuxt/AOmwrEs0.js.gz"
  },
  "/_nuxt/B02SJ8rg.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"44a0-fcnnNGf0SF8IyMs0h7lxSdKrPLg\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 17568,
    "path": "../public/_nuxt/B02SJ8rg.js"
  },
  "/_nuxt/B02SJ8rg.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"12d8-hIb+JA2glJk9a48YkaPp0LopvKg\"",
    "mtime": "2026-05-20T15:26:05.415Z",
    "size": 4824,
    "path": "../public/_nuxt/B02SJ8rg.js.br"
  },
  "/_nuxt/B02SJ8rg.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16b7-9ISRUn4aARN4XeGOWAfimuJfMNw\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 5815,
    "path": "../public/_nuxt/B02SJ8rg.js.gz"
  },
  "/_nuxt/B7cZmc98.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"160d-gxxUjnDAZXtd4zdsQADHIzG4Pew\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 5645,
    "path": "../public/_nuxt/B7cZmc98.js"
  },
  "/_nuxt/B7cZmc98.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"952-BXPb2icjRXf3lijgUJ19MOmBT+g\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 2386,
    "path": "../public/_nuxt/B7cZmc98.js.gz"
  },
  "/_nuxt/B9M9yliy.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5ba-DvWe6ftnSwQ0+2XuFRmmi2yjNeg\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1466,
    "path": "../public/_nuxt/B9M9yliy.js"
  },
  "/_nuxt/B7cZmc98.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"84b-+D865eG/rXZJGYoiS4vg2GEriSY\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 2123,
    "path": "../public/_nuxt/B7cZmc98.js.br"
  },
  "/_nuxt/B9M9yliy.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"35a-M7JuYJdau2v6oQMUoIe94OZ9HcQ\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 858,
    "path": "../public/_nuxt/B9M9yliy.js.gz"
  },
  "/_nuxt/B9M9yliy.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2df-sBf8lVtHbTE4rkism5mcXsQJZFA\"",
    "mtime": "2026-05-20T15:26:05.411Z",
    "size": 735,
    "path": "../public/_nuxt/B9M9yliy.js.br"
  },
  "/_nuxt/B9vJIU5W.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"50c9-m37z1bp+JN1WvRkWlzm2aVUo32k\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 20681,
    "path": "../public/_nuxt/B9vJIU5W.js"
  },
  "/_nuxt/B9vJIU5W.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1aa7-yVLlGlnica8nU2qIdlq7ykTkOqQ\"",
    "mtime": "2026-05-20T15:26:05.464Z",
    "size": 6823,
    "path": "../public/_nuxt/B9vJIU5W.js.br"
  },
  "/_nuxt/B9vJIU5W.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1d68-JRHKBsEsZ3cmljYQB2b1xPWvlug\"",
    "mtime": "2026-05-20T15:26:05.415Z",
    "size": 7528,
    "path": "../public/_nuxt/B9vJIU5W.js.gz"
  },
  "/_nuxt/BB4xfzbo.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"518-j43yUcThcR/uMl+UYBxX/IoAQjs\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1304,
    "path": "../public/_nuxt/BB4xfzbo.js"
  },
  "/_nuxt/BB4xfzbo.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b7-HQTYyL1AUvyg7RmlM6LbOLmBBuQ\"",
    "mtime": "2026-05-20T15:26:05.463Z",
    "size": 695,
    "path": "../public/_nuxt/BB4xfzbo.js.br"
  },
  "/_nuxt/BB4xfzbo.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"331-3XqrM7JQPRXaqBaVaM2Qp3Fp4s0\"",
    "mtime": "2026-05-20T15:26:05.463Z",
    "size": 817,
    "path": "../public/_nuxt/BB4xfzbo.js.gz"
  },
  "/_nuxt/BC0T5t73.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"41c-0JuxxUbs591vN4j4z7x2nBU7rZU\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1052,
    "path": "../public/_nuxt/BC0T5t73.js"
  },
  "/_nuxt/BC0T5t73.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"244-VycwIZ3jXBA8t6/XyBHejs3o77c\"",
    "mtime": "2026-05-20T15:26:05.487Z",
    "size": 580,
    "path": "../public/_nuxt/BC0T5t73.js.br"
  },
  "/_nuxt/BC0T5t73.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ca-ah4u0wGh8djFNv0JCoE49VR6S8I\"",
    "mtime": "2026-05-20T15:26:05.487Z",
    "size": 714,
    "path": "../public/_nuxt/BC0T5t73.js.gz"
  },
  "/_nuxt/BCYpgjqj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"72-Rk9hm/N+ox05OTbtpT8h/VdxhqU\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 114,
    "path": "../public/_nuxt/BCYpgjqj.js"
  },
  "/_nuxt/BE25QtOu.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"47e-vfvRzPYrDdMpNaJbtoHJq1ImwwU\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1150,
    "path": "../public/_nuxt/BE25QtOu.js"
  },
  "/_nuxt/BE25QtOu.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"259-mzUIqa+YTbArC43fV12QBhsDE6c\"",
    "mtime": "2026-05-20T15:26:05.487Z",
    "size": 601,
    "path": "../public/_nuxt/BE25QtOu.js.br"
  },
  "/_nuxt/BE25QtOu.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ae-sFwCPphRKHMUodzU2rgv/ETvcKc\"",
    "mtime": "2026-05-20T15:26:05.487Z",
    "size": 686,
    "path": "../public/_nuxt/BE25QtOu.js.gz"
  },
  "/_nuxt/BezRKGrJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"97-CKzW8GKP6pZEZ6zkDhGzE9P5fl4\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 151,
    "path": "../public/_nuxt/BezRKGrJ.js"
  },
  "/_nuxt/Bg7UFr6l.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2cce-f8L6XQTxK+Lv8pvq4Sn5XEYa5cI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 11470,
    "path": "../public/_nuxt/Bg7UFr6l.js"
  },
  "/_nuxt/Bg7UFr6l.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ec1-qCKPjMiRmXYdLoWFvlfa4CXmP/U\"",
    "mtime": "2026-05-20T15:26:05.515Z",
    "size": 3777,
    "path": "../public/_nuxt/Bg7UFr6l.js.br"
  },
  "/_nuxt/Bg7UFr6l.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1042-OAR44TdnwGaNm9JS5wRvbrTo1EQ\"",
    "mtime": "2026-05-20T15:26:05.500Z",
    "size": 4162,
    "path": "../public/_nuxt/Bg7UFr6l.js.gz"
  },
  "/_nuxt/BhiGtPJP.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1dfe-gvmixQ4/rcYOOTWlkA82TXhV+mo\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 7678,
    "path": "../public/_nuxt/BhiGtPJP.js"
  },
  "/_nuxt/BhiGtPJP.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"9d2-atnzm6sboN17Hp1N01X/xpKJ4CI\"",
    "mtime": "2026-05-20T15:26:05.518Z",
    "size": 2514,
    "path": "../public/_nuxt/BhiGtPJP.js.br"
  },
  "/_nuxt/BhiGtPJP.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"ac0-VnAcP+OdydwG/jdVJY10dNZFB2s\"",
    "mtime": "2026-05-20T15:26:05.518Z",
    "size": 2752,
    "path": "../public/_nuxt/BhiGtPJP.js.gz"
  },
  "/_nuxt/BiIQc1sO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"38b-hg1p1komm8ZQAYeHdQ69YpYQG7Y\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 907,
    "path": "../public/_nuxt/BiIQc1sO.js"
  },
  "/_nuxt/BIDEDpP7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3a1-id0u81m15hHesuyUCcP2mmCywTk\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 929,
    "path": "../public/_nuxt/BIDEDpP7.js"
  },
  "/_nuxt/BIVDT6Zm.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"20b9-But/sVIjPHmNKcXKYzHP5FF7x/o\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 8377,
    "path": "../public/_nuxt/BIVDT6Zm.js"
  },
  "/_nuxt/BIVDT6Zm.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"8e1-ewfksRwuV+iDSnDWrRNe08HqEkA\"",
    "mtime": "2026-05-20T15:26:05.519Z",
    "size": 2273,
    "path": "../public/_nuxt/BIVDT6Zm.js.br"
  },
  "/_nuxt/BIVDT6Zm.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9cb-iGXuVpuhEhmONkGTelVJFBIHwJQ\"",
    "mtime": "2026-05-20T15:26:05.518Z",
    "size": 2507,
    "path": "../public/_nuxt/BIVDT6Zm.js.gz"
  },
  "/_nuxt/BLBWerHv.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4aa-8RYleaV1e5GGf9j/oqa0Oqj5LHs\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1194,
    "path": "../public/_nuxt/BLBWerHv.js"
  },
  "/_nuxt/BLBWerHv.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"26b-9ZsvyAEyKy+eMiSAl3YO58h4uGk\"",
    "mtime": "2026-05-20T15:26:05.525Z",
    "size": 619,
    "path": "../public/_nuxt/BLBWerHv.js.br"
  },
  "/_nuxt/BLBWerHv.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ca-UlofO02+nSamuoC5F4Qho3kgdS0\"",
    "mtime": "2026-05-20T15:26:05.525Z",
    "size": 714,
    "path": "../public/_nuxt/BLBWerHv.js.gz"
  },
  "/_nuxt/BlwKEMxG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"152-zHrx+bjtHI019Sb5ULGTH0HlS5g\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 338,
    "path": "../public/_nuxt/BlwKEMxG.js"
  },
  "/_nuxt/BNYkUgfS.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"329d-2w/BdLW0GSnAwX7Ny4Aa2Z4krFo\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 12957,
    "path": "../public/_nuxt/BNYkUgfS.js"
  },
  "/_nuxt/BNYkUgfS.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"114d-UhgxxWWf0vK0/Rq3epza9sK/2LU\"",
    "mtime": "2026-05-20T15:26:05.553Z",
    "size": 4429,
    "path": "../public/_nuxt/BNYkUgfS.js.gz"
  },
  "/_nuxt/BNYkUgfS.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"fc9-vwSoFGDmigPPDAm/DFxnO2LkYfs\"",
    "mtime": "2026-05-20T15:26:05.571Z",
    "size": 4041,
    "path": "../public/_nuxt/BNYkUgfS.js.br"
  },
  "/_nuxt/BO1A91JD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2068-gsXabOaifh+i9k+7c5nARFPfqao\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 8296,
    "path": "../public/_nuxt/BO1A91JD.js"
  },
  "/_nuxt/BO1A91JD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"afc-88NRWqdvCZIF4KAKPoO7LpG3GbY\"",
    "mtime": "2026-05-20T15:26:05.553Z",
    "size": 2812,
    "path": "../public/_nuxt/BO1A91JD.js.br"
  },
  "/_nuxt/BO1A91JD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"cfb-HJFXFfcmBL9mRqpO2ldjR2eSWn8\"",
    "mtime": "2026-05-20T15:26:05.553Z",
    "size": 3323,
    "path": "../public/_nuxt/BO1A91JD.js.gz"
  },
  "/_nuxt/BPV-2kt4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3b9-dotxJcGiGTKRAJVSLPEdfN550iI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 953,
    "path": "../public/_nuxt/BPV-2kt4.js"
  },
  "/_nuxt/BryJ4Y2v.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"649-tOZeamcXt0MtB9XFeZamNtX9KiQ\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1609,
    "path": "../public/_nuxt/BryJ4Y2v.js"
  },
  "/_nuxt/BryJ4Y2v.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"33f-kPPFOMcayAzsEHD19L4rLsAb6+c\"",
    "mtime": "2026-05-20T15:26:05.574Z",
    "size": 831,
    "path": "../public/_nuxt/BryJ4Y2v.js.br"
  },
  "/_nuxt/BryJ4Y2v.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3c1-lo3q5of7wMOrffd6okODNz4Z0Bk\"",
    "mtime": "2026-05-20T15:26:05.571Z",
    "size": 961,
    "path": "../public/_nuxt/BryJ4Y2v.js.gz"
  },
  "/_nuxt/BSachBXK.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"14f5-6AHkWP59tKYT+TEwNpE+YpknVo8\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 5365,
    "path": "../public/_nuxt/BSachBXK.js"
  },
  "/_nuxt/BSachBXK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"77d-sDZAMr0HPglzZwWp2bWBW9cpD0Y\"",
    "mtime": "2026-05-20T15:26:05.584Z",
    "size": 1917,
    "path": "../public/_nuxt/BSachBXK.js.br"
  },
  "/_nuxt/Bt7JwOIy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"36f-TXOlS5IHvnzREONcwsK5/BLVwhw\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 879,
    "path": "../public/_nuxt/Bt7JwOIy.js"
  },
  "/_nuxt/BSachBXK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"84c-fsfrL4b5JCbj5MBbXaIxXrvHPqk\"",
    "mtime": "2026-05-20T15:26:05.584Z",
    "size": 2124,
    "path": "../public/_nuxt/BSachBXK.js.gz"
  },
  "/_nuxt/BtcI3snF.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4ea-MapPdl7sUfhAQY4vQCVPlRwQBBI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1258,
    "path": "../public/_nuxt/BtcI3snF.js"
  },
  "/_nuxt/BtcI3snF.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1e6-v26sR+EHoV9pAGifLiSXyiEFNmQ\"",
    "mtime": "2026-05-20T15:26:05.579Z",
    "size": 486,
    "path": "../public/_nuxt/BtcI3snF.js.br"
  },
  "/_nuxt/BtZStUSN.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a1b-JZIg0M32hj3y9nq52F76bDCqNUM\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 2587,
    "path": "../public/_nuxt/BtZStUSN.js"
  },
  "/_nuxt/BtZStUSN.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"515-wD3V202WDSV+UUdquO9j7cBcjtg\"",
    "mtime": "2026-05-20T15:26:05.584Z",
    "size": 1301,
    "path": "../public/_nuxt/BtZStUSN.js.gz"
  },
  "/_nuxt/BtcI3snF.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"246-Ebh5hrqkyyJAyXhML1T1y1ZSRd4\"",
    "mtime": "2026-05-20T15:26:05.579Z",
    "size": 582,
    "path": "../public/_nuxt/BtcI3snF.js.gz"
  },
  "/_nuxt/BtZStUSN.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"466-ZCI8CdiXK1Yn5NhXOK/c0oTSU8E\"",
    "mtime": "2026-05-20T15:26:05.585Z",
    "size": 1126,
    "path": "../public/_nuxt/BtZStUSN.js.br"
  },
  "/_nuxt/BvN9SCTZ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"ce7-54W7uyVr4CHMjX9yiU1e/WNQyUY\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 3303,
    "path": "../public/_nuxt/BvN9SCTZ.js"
  },
  "/_nuxt/BvN9SCTZ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4bd-LTB1F7dmzxuGv6tcVjIKfjVW6g8\"",
    "mtime": "2026-05-20T15:26:05.619Z",
    "size": 1213,
    "path": "../public/_nuxt/BvN9SCTZ.js.br"
  },
  "/_nuxt/BvN9SCTZ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"586-whZpSZ1pjiPS1JFZd+OLHF6cwJc\"",
    "mtime": "2026-05-20T15:26:05.619Z",
    "size": 1414,
    "path": "../public/_nuxt/BvN9SCTZ.js.gz"
  },
  "/_nuxt/BWqr6nhO.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a3f2-cUPujyU7SoBbpqOTJUlPRb0C+/M\"",
    "mtime": "2026-05-20T15:26:05.984Z",
    "size": 41970,
    "path": "../public/_nuxt/BWqr6nhO.js.br"
  },
  "/_nuxt/BXT6JJzG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"821-DFyvzI4OXCq83ZffCWG7ZHkOroM\"",
    "mtime": "2026-05-20T15:26:05.659Z",
    "size": 2081,
    "path": "../public/_nuxt/BXT6JJzG.js.br"
  },
  "/_nuxt/BXT6JJzG.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"14e3-zEgM8/5J94x6r6ejyMJmQotBEFE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 5347,
    "path": "../public/_nuxt/BXT6JJzG.js"
  },
  "/_nuxt/BWqr6nhO.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bb07-OjW4CvrO7LBNmjr1FQB7SWwYR6w\"",
    "mtime": "2026-05-20T15:26:05.693Z",
    "size": 47879,
    "path": "../public/_nuxt/BWqr6nhO.js.gz"
  },
  "/_nuxt/BWqr6nhO.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"25664-mVJLKDHklnZWcUxg3i9a745crrU\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 153188,
    "path": "../public/_nuxt/BWqr6nhO.js"
  },
  "/_nuxt/BXT6JJzG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"97b-bcwDMurzSA3SgvoAcvHXRMeu/p0\"",
    "mtime": "2026-05-20T15:26:05.619Z",
    "size": 2427,
    "path": "../public/_nuxt/BXT6JJzG.js.gz"
  },
  "/_nuxt/ByJtIlAM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d0-HsnkuIL77Iu5VIpOk8Bmr5XD190\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 976,
    "path": "../public/_nuxt/ByJtIlAM.js"
  },
  "/_nuxt/BYZNlRBI.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"318a-bfosr/NjjVAP5ojb++Pc7otG340\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 12682,
    "path": "../public/_nuxt/BYZNlRBI.js"
  },
  "/_nuxt/BYZNlRBI.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"e97-W1BV+s7Ymmo2nUmfsuINW33iMWc\"",
    "mtime": "2026-05-20T15:26:05.660Z",
    "size": 3735,
    "path": "../public/_nuxt/BYZNlRBI.js.br"
  },
  "/_nuxt/BYZNlRBI.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"103d-3xvrzl6XTMwnRL2avg1315bamhg\"",
    "mtime": "2026-05-20T15:26:05.653Z",
    "size": 4157,
    "path": "../public/_nuxt/BYZNlRBI.js.gz"
  },
  "/_nuxt/C0yyIjGK.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4b5-Uof2vdFomkSbvnouysWhzGrzqXA\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1205,
    "path": "../public/_nuxt/C0yyIjGK.js"
  },
  "/_nuxt/C0yyIjGK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"282-JBG38NiNHguUybYk3Y7C8BRCwuA\"",
    "mtime": "2026-05-20T15:26:05.659Z",
    "size": 642,
    "path": "../public/_nuxt/C0yyIjGK.js.br"
  },
  "/_nuxt/C0yyIjGK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2e5-5DU0fb57sxNC8upEBWi5dRUx3m0\"",
    "mtime": "2026-05-20T15:26:05.659Z",
    "size": 741,
    "path": "../public/_nuxt/C0yyIjGK.js.gz"
  },
  "/_nuxt/C3EVgROp.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1b9c-BkRDknIF/z2KyGTG/FLjDMOwQ0I\"",
    "mtime": "2026-05-20T15:26:05.660Z",
    "size": 7068,
    "path": "../public/_nuxt/C3EVgROp.js.br"
  },
  "/_nuxt/C3EVgROp.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5766-AYb+r9zPcAknR5LoxSkt8E1JgFM\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 22374,
    "path": "../public/_nuxt/C3EVgROp.js"
  },
  "/_nuxt/C3EVgROp.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"203d-EUcAPgKlYZg/SxnvNzn8qKB32s0\"",
    "mtime": "2026-05-20T15:26:05.659Z",
    "size": 8253,
    "path": "../public/_nuxt/C3EVgROp.js.gz"
  },
  "/_nuxt/C4po3w5l.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5a5d-bl8zJMplg7Ziqrq+RlsE6fUWI1w\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 23133,
    "path": "../public/_nuxt/C4po3w5l.js"
  },
  "/_nuxt/C4po3w5l.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1f5b-y289UaME/mCfXPoqryw+5gR4JmM\"",
    "mtime": "2026-05-20T15:26:05.660Z",
    "size": 8027,
    "path": "../public/_nuxt/C4po3w5l.js.gz"
  },
  "/_nuxt/C4po3w5l.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1b9f-iGwDm58RtUn8Y2qLZZB/HjggIlM\"",
    "mtime": "2026-05-20T15:26:05.707Z",
    "size": 7071,
    "path": "../public/_nuxt/C4po3w5l.js.br"
  },
  "/_nuxt/C5Q3-CCb.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1074-OVvJD6M/qcsTryRrKi46D8tBDoA\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 4212,
    "path": "../public/_nuxt/C5Q3-CCb.js"
  },
  "/_nuxt/C5Q3-CCb.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5d9-y2RzBz950DoCItHs+zVKna8kfw0\"",
    "mtime": "2026-05-20T15:26:05.660Z",
    "size": 1497,
    "path": "../public/_nuxt/C5Q3-CCb.js.br"
  },
  "/_nuxt/C5Q3-CCb.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"714-LWu2Hm4fYT8N/68yJurlwJ2Nvyo\"",
    "mtime": "2026-05-20T15:26:05.660Z",
    "size": 1812,
    "path": "../public/_nuxt/C5Q3-CCb.js.gz"
  },
  "/_nuxt/CBIlniYp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"76-fCbjXgAe3YyjQuFyO29ehIWTTjw\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 118,
    "path": "../public/_nuxt/CBIlniYp.js"
  },
  "/_nuxt/CbVSRt7Y.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"75f4-weqko12eWMlhdj6rxgs9eKZuQe8\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 30196,
    "path": "../public/_nuxt/CbVSRt7Y.js"
  },
  "/_nuxt/CbVSRt7Y.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bef-/SowtlleOUS7yZsD8GbbnCr2w5s\"",
    "mtime": "2026-05-20T15:26:05.768Z",
    "size": 7151,
    "path": "../public/_nuxt/CbVSRt7Y.js.br"
  },
  "/_nuxt/CbVSRt7Y.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1f1b-5imwHFVBfyDvlHfXpNr2J62xJs4\"",
    "mtime": "2026-05-20T15:26:05.709Z",
    "size": 7963,
    "path": "../public/_nuxt/CbVSRt7Y.js.gz"
  },
  "/_nuxt/CB_vtTYf.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a316-kAlCEan7Xfdyfkdm67oHvbnGHZ4\"",
    "mtime": "2026-05-20T15:26:05.996Z",
    "size": 41750,
    "path": "../public/_nuxt/CB_vtTYf.js.br"
  },
  "/_nuxt/CB_vtTYf.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bb5c-/V0Jsb4ZXa0HstYFfAead48m3DE\"",
    "mtime": "2026-05-20T15:26:05.819Z",
    "size": 47964,
    "path": "../public/_nuxt/CB_vtTYf.js.gz"
  },
  "/_nuxt/Ce6EQv-5.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23b-op3FNeKZcM9d092LWOt/758XegY\"",
    "mtime": "2026-05-20T15:26:05.759Z",
    "size": 571,
    "path": "../public/_nuxt/Ce6EQv-5.js.br"
  },
  "/_nuxt/Ce6EQv-5.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"46a-fV2EWZC7ghb3EqJhlyNeVRS0HP0\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1130,
    "path": "../public/_nuxt/Ce6EQv-5.js"
  },
  "/_nuxt/Ce6EQv-5.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"292-/vir3yb9mjk0IRLEzyKYiG88N40\"",
    "mtime": "2026-05-20T15:26:05.709Z",
    "size": 658,
    "path": "../public/_nuxt/Ce6EQv-5.js.gz"
  },
  "/_nuxt/CgPRzE2m.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"48dd-3NvMvrmGDrbujr/0cYXrCts6/cQ\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 18653,
    "path": "../public/_nuxt/CgPRzE2m.js"
  },
  "/_nuxt/CgPRzE2m.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"14df-M8ISIppY5qKkSJGsw5jvHmH3MJU\"",
    "mtime": "2026-05-20T15:26:05.819Z",
    "size": 5343,
    "path": "../public/_nuxt/CgPRzE2m.js.br"
  },
  "/_nuxt/CB_vtTYf.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"25b31-nrslsuEEMspViZLnDSYScCiw70c\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 154417,
    "path": "../public/_nuxt/CB_vtTYf.js"
  },
  "/_nuxt/CgPRzE2m.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16e4-8mrKQL1A+NJs96pc2H8yYpt5rSY\"",
    "mtime": "2026-05-20T15:26:05.768Z",
    "size": 5860,
    "path": "../public/_nuxt/CgPRzE2m.js.gz"
  },
  "/_nuxt/CH8wxebb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14b-62dA0Jj7tl/bmEdzPEqvDkRW1as\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 331,
    "path": "../public/_nuxt/CH8wxebb.js"
  },
  "/_nuxt/CHvg9l4s.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b9f1-/i9wbKP74bX23HSXUxw7khUbuXI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 47601,
    "path": "../public/_nuxt/CHvg9l4s.js"
  },
  "/_nuxt/CHvg9l4s.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"386e-qJsyyQ+rSBLsvxU9r8CpD9YkJ6g\"",
    "mtime": "2026-05-20T15:26:05.975Z",
    "size": 14446,
    "path": "../public/_nuxt/CHvg9l4s.js.br"
  },
  "/_nuxt/CHvg9l4s.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4126-KA4f42JIiBKgO1Eq1y31JStlhcQ\"",
    "mtime": "2026-05-20T15:26:05.835Z",
    "size": 16678,
    "path": "../public/_nuxt/CHvg9l4s.js.gz"
  },
  "/_nuxt/CjaG_Kf4.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"7a8-f3sEtUVYK+SbgGsBNg+UzpW2YHA\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1960,
    "path": "../public/_nuxt/CjaG_Kf4.js"
  },
  "/_nuxt/CjaG_Kf4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3ee-2qL4O5hgCJMegCGvkhA+v5LtwSU\"",
    "mtime": "2026-05-20T15:26:05.807Z",
    "size": 1006,
    "path": "../public/_nuxt/CjaG_Kf4.js.br"
  },
  "/_nuxt/CjaG_Kf4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4a5-WAG8s351SLo606CV0Z1C1jJ8wy4\"",
    "mtime": "2026-05-20T15:26:05.807Z",
    "size": 1189,
    "path": "../public/_nuxt/CjaG_Kf4.js.gz"
  },
  "/_nuxt/CjTAj-n-.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"41c-W+pdAnbwtWzUuRCVc6szng9zjks\"",
    "mtime": "2026-05-20T15:26:05.807Z",
    "size": 1052,
    "path": "../public/_nuxt/CjTAj-n-.js.br"
  },
  "/_nuxt/CjTAj-n-.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"af9-NQ+fRdh3Ank04tjv/wBGrzeWAFE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 2809,
    "path": "../public/_nuxt/CjTAj-n-.js"
  },
  "/_nuxt/CjTAj-n-.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"500-O2/Sg4Lk+EC2jRuUlgUHP2CSMf4\"",
    "mtime": "2026-05-20T15:26:05.807Z",
    "size": 1280,
    "path": "../public/_nuxt/CjTAj-n-.js.gz"
  },
  "/_nuxt/CKsRfNyJ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5e32-SVkFhu9tMeW7mp1Os/n0iEsrZeI\"",
    "mtime": "2026-05-20T15:26:05.984Z",
    "size": 24114,
    "path": "../public/_nuxt/CKsRfNyJ.js.br"
  },
  "/_nuxt/CKsRfNyJ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6ada-FnYIyS1hIgF/ET2nv+lFdEafymc\"",
    "mtime": "2026-05-20T15:26:05.975Z",
    "size": 27354,
    "path": "../public/_nuxt/CKsRfNyJ.js.gz"
  },
  "/_nuxt/CLnHKwvQ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"107d-vxB/UxrvWWtZVpLfoeWnUkXhP7c\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 4221,
    "path": "../public/_nuxt/CLnHKwvQ.js"
  },
  "/_nuxt/CKsRfNyJ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"166e6-wCiNQ+4NDROpvOtKmet4zpBWoRs\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 91878,
    "path": "../public/_nuxt/CKsRfNyJ.js"
  },
  "/_nuxt/CLnHKwvQ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"64e-rdVBPaozyklso1uRk0a28tQJcus\"",
    "mtime": "2026-05-20T15:26:05.975Z",
    "size": 1614,
    "path": "../public/_nuxt/CLnHKwvQ.js.br"
  },
  "/_nuxt/CLnHKwvQ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7ad-bQfAbQKpr+Jlr4NxYptDHAekzUg\"",
    "mtime": "2026-05-20T15:26:05.975Z",
    "size": 1965,
    "path": "../public/_nuxt/CLnHKwvQ.js.gz"
  },
  "/_nuxt/Cnhps8WK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3ea-hahRfEyB/SIN6GsteizJ+NLakys\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1002,
    "path": "../public/_nuxt/Cnhps8WK.js"
  },
  "/_nuxt/CPGUAKnx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"36e-yL0LuNCdYpf3/WC0r+IrtMbUQ/M\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 878,
    "path": "../public/_nuxt/CPGUAKnx.js"
  },
  "/_nuxt/CPxhDQBG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5d1-LUa8cvLa7gfhoTn163YYvH3Vep4\"",
    "mtime": "2026-05-20T15:26:06.028Z",
    "size": 1489,
    "path": "../public/_nuxt/CPxhDQBG.js.br"
  },
  "/_nuxt/CPxhDQBG.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"ce3-Le7J/XiOZ0FjXZ9u+RFRV8v20JY\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 3299,
    "path": "../public/_nuxt/CPxhDQBG.js"
  },
  "/_nuxt/CPxhDQBG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6d2-2KAr2pqnXhNn31zneevSemwvSig\"",
    "mtime": "2026-05-20T15:26:06.019Z",
    "size": 1746,
    "path": "../public/_nuxt/CPxhDQBG.js.gz"
  },
  "/_nuxt/CqQnJMWc.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"10db-jG6e9NAv7H54sV7YDWV9nSkgyVo\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 4315,
    "path": "../public/_nuxt/CqQnJMWc.js"
  },
  "/_nuxt/CqQnJMWc.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6f9-FEGEiykSR9YscxbjT8iWtVftHd8\"",
    "mtime": "2026-05-20T15:26:06.029Z",
    "size": 1785,
    "path": "../public/_nuxt/CqQnJMWc.js.br"
  },
  "/_nuxt/CqQnJMWc.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7bc-10VAUwul7s5abc10wjOCmn9Vt7Y\"",
    "mtime": "2026-05-20T15:26:06.028Z",
    "size": 1980,
    "path": "../public/_nuxt/CqQnJMWc.js.gz"
  },
  "/_nuxt/CQ_vJYo9.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1155-7Httg5m7rCMIsrpk8iszYz57JmQ\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 4437,
    "path": "../public/_nuxt/CQ_vJYo9.js"
  },
  "/_nuxt/CQ_vJYo9.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"71c-lt/T4thupZbUIjDog1EVZviTx1c\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 1820,
    "path": "../public/_nuxt/CQ_vJYo9.js.br"
  },
  "/_nuxt/CQ_vJYo9.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7f1-Jvr7LHGXN1gmZScLz0ZrhKhS/Uw\"",
    "mtime": "2026-05-20T15:26:06.038Z",
    "size": 2033,
    "path": "../public/_nuxt/CQ_vJYo9.js.gz"
  },
  "/_nuxt/Crvh4U75.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1b1b-ZHeirNe6JQYkApfRLAAx78zul+E\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 6939,
    "path": "../public/_nuxt/Crvh4U75.js"
  },
  "/_nuxt/Crvh4U75.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"9d6-d/TfvzCaaaUGbFArPahUe+cGidA\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 2518,
    "path": "../public/_nuxt/Crvh4U75.js.br"
  },
  "/_nuxt/Crvh4U75.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bae-AY+4W13yXzeTH9HnNamphl3k+Uo\"",
    "mtime": "2026-05-20T15:26:06.060Z",
    "size": 2990,
    "path": "../public/_nuxt/Crvh4U75.js.gz"
  },
  "/_nuxt/Cs-fsS2d.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"58cc1-0OLq4hySN3y8aqD9hVNIDziRWvE\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 363713,
    "path": "../public/_nuxt/Cs-fsS2d.js"
  },
  "/_nuxt/cszk34JD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"760-UbDHIwu+/7WFW7d+Zj+TLn5rH68\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1888,
    "path": "../public/_nuxt/cszk34JD.js"
  },
  "/_nuxt/Cs-fsS2d.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2008f-ZS06dZMULzL26ShsB93Bki+c3Ks\"",
    "mtime": "2026-05-20T15:26:06.239Z",
    "size": 131215,
    "path": "../public/_nuxt/Cs-fsS2d.js.gz"
  },
  "/_nuxt/Cs-fsS2d.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1b874-AOeZ14v0ZLUW0yxlxCKQvwfVvGs\"",
    "mtime": "2026-05-20T15:26:06.872Z",
    "size": 112756,
    "path": "../public/_nuxt/Cs-fsS2d.js.br"
  },
  "/_nuxt/cszk34JD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"23d-KywK5z0SOLRL7uSHUQawEanFHIs\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 573,
    "path": "../public/_nuxt/cszk34JD.js.gz"
  },
  "/_nuxt/CtBMi9uJ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"70f-rjeMLt4XpEK0NIFjbCRy8PCkDE0\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1807,
    "path": "../public/_nuxt/CtBMi9uJ.js"
  },
  "/_nuxt/CtBMi9uJ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1d7-/diHVYsvA2uMzkIKoglrlh+uKSM\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 471,
    "path": "../public/_nuxt/CtBMi9uJ.js.br"
  },
  "/_nuxt/CtBMi9uJ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"249-iubrlvBrSETCZ1Cg/+4hdnC4S0Y\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 585,
    "path": "../public/_nuxt/CtBMi9uJ.js.gz"
  },
  "/_nuxt/cszk34JD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1e0-tR51na9Pp5/DFri9dro9Qsc0veU\"",
    "mtime": "2026-05-20T15:26:06.072Z",
    "size": 480,
    "path": "../public/_nuxt/cszk34JD.js.br"
  },
  "/_nuxt/CtGWORGZ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1b64-RbbXOcFed4msPELGJWnZA8bgKI0\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 7012,
    "path": "../public/_nuxt/CtGWORGZ.js"
  },
  "/_nuxt/CtGWORGZ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"913-Vluay1o95zVNBilDGA/bNJJQZ/o\"",
    "mtime": "2026-05-20T15:26:06.108Z",
    "size": 2323,
    "path": "../public/_nuxt/CtGWORGZ.js.br"
  },
  "/_nuxt/CtGWORGZ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a20-HWGB0mO4u1lkUaKWSUPHCmTj7GU\"",
    "mtime": "2026-05-20T15:26:06.073Z",
    "size": 2592,
    "path": "../public/_nuxt/CtGWORGZ.js.gz"
  },
  "/_nuxt/CwxFTaP0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"299-JKyRPv0iXMFTaGuoRg5Y2Tw/HSY\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 665,
    "path": "../public/_nuxt/CwxFTaP0.js"
  },
  "/_nuxt/D3sq7ZPk.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"eea-/YjYyoer2e2zbTmHum4u1W1alaw\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 3818,
    "path": "../public/_nuxt/D3sq7ZPk.js"
  },
  "/_nuxt/D3sq7ZPk.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5d6-tDFrBkHhYtXM0zCos2xjVkZutRM\"",
    "mtime": "2026-05-20T15:26:06.114Z",
    "size": 1494,
    "path": "../public/_nuxt/D3sq7ZPk.js.br"
  },
  "/_nuxt/D3sq7ZPk.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6b5-B8iRrFy8DtbmK3CCIkv5hO2ap4E\"",
    "mtime": "2026-05-20T15:26:06.092Z",
    "size": 1717,
    "path": "../public/_nuxt/D3sq7ZPk.js.gz"
  },
  "/_nuxt/D6_S6sfY.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2d3-RU7fEktbjDonu29kv1ZPHEVvZRM\"",
    "mtime": "2026-05-20T15:26:06.114Z",
    "size": 723,
    "path": "../public/_nuxt/D6_S6sfY.js.br"
  },
  "/_nuxt/D6_S6sfY.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5e0-cLnh0NkyXPpbYFnRFLabarGpklc\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1504,
    "path": "../public/_nuxt/D6_S6sfY.js"
  },
  "/_nuxt/D6_S6sfY.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"343-YYsn1rgq7Pmdz+VxrXiQh+rhsc4\"",
    "mtime": "2026-05-20T15:26:06.114Z",
    "size": 835,
    "path": "../public/_nuxt/D6_S6sfY.js.gz"
  },
  "/_nuxt/D8DejqpU.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"294b-ctbDQJolJYer4J8IQ2qiiyQNLpA\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 10571,
    "path": "../public/_nuxt/D8DejqpU.js"
  },
  "/_nuxt/D8DejqpU.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"dd3-Imh1HpSaFZUPwjDpAOxN0fG4Xf8\"",
    "mtime": "2026-05-20T15:26:06.151Z",
    "size": 3539,
    "path": "../public/_nuxt/D8DejqpU.js.br"
  },
  "/_nuxt/D8DejqpU.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f5e-TLIWVoBsoHMCQ4G/bCsYFeeUibg\"",
    "mtime": "2026-05-20T15:26:06.114Z",
    "size": 3934,
    "path": "../public/_nuxt/D8DejqpU.js.gz"
  },
  "/_nuxt/D9FKhxEp.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"66b3-A48BnGs3JIO3gb7F0H4dWimFBk0\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 26291,
    "path": "../public/_nuxt/D9FKhxEp.js"
  },
  "/_nuxt/D9FKhxEp.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1d51-jijy/XRVzpEV0+B1kgbScYYmCrQ\"",
    "mtime": "2026-05-20T15:26:06.151Z",
    "size": 7505,
    "path": "../public/_nuxt/D9FKhxEp.js.br"
  },
  "/_nuxt/D9FKhxEp.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"22d5-p6Yvs5DytOQ6XZRqK+eBYyEa0xI\"",
    "mtime": "2026-05-20T15:26:06.114Z",
    "size": 8917,
    "path": "../public/_nuxt/D9FKhxEp.js.gz"
  },
  "/_nuxt/D9zPUemI.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1276-7pd0KmRNOANF8w4RqFeIU+VRjOs\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 4726,
    "path": "../public/_nuxt/D9zPUemI.js"
  },
  "/_nuxt/D9zPUemI.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6ba-uLJTYmiCs0Eix2nIL8yLDt+z/m8\"",
    "mtime": "2026-05-20T15:26:06.151Z",
    "size": 1722,
    "path": "../public/_nuxt/D9zPUemI.js.br"
  },
  "/_nuxt/D9zPUemI.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7ee-sXVVjII4Wqwg8bSqXbxJ1SUqFjs\"",
    "mtime": "2026-05-20T15:26:06.151Z",
    "size": 2030,
    "path": "../public/_nuxt/D9zPUemI.js.gz"
  },
  "/_nuxt/DakftmwZ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4099-X2pgG715ofBZuBcRITr6k69xYYg\"",
    "mtime": "2026-05-20T15:26:06.245Z",
    "size": 16537,
    "path": "../public/_nuxt/DakftmwZ.js.br"
  },
  "/_nuxt/DakftmwZ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"cd05-FBioSL14oJNfanv7Q0mxObAMncU\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 52485,
    "path": "../public/_nuxt/DakftmwZ.js"
  },
  "/_nuxt/DBQ7HTaD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"81-YPxoQcq1+zq4pIlsKHcpxjdruJo\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 129,
    "path": "../public/_nuxt/DBQ7HTaD.js"
  },
  "/_nuxt/DakftmwZ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"49c0-qPsbTEAt/A11xoWR4puMLQE2QFA\"",
    "mtime": "2026-05-20T15:26:06.202Z",
    "size": 18880,
    "path": "../public/_nuxt/DakftmwZ.js.gz"
  },
  "/_nuxt/default.Dmc0DTNp.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"1726-SP/YE0oa6GP8EGe3ekTeE/TbjVo\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 5926,
    "path": "../public/_nuxt/default.Dmc0DTNp.css"
  },
  "/_nuxt/default.Dmc0DTNp.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"5fb-WY8gXMChFSO0YQtskotvcNtVWCM\"",
    "mtime": "2026-05-20T15:26:06.155Z",
    "size": 1531,
    "path": "../public/_nuxt/default.Dmc0DTNp.css.br"
  },
  "/_nuxt/default.Dmc0DTNp.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6f7-yQUfoJghNe/klpQJ+ORoU+z0Rf8\"",
    "mtime": "2026-05-20T15:26:06.151Z",
    "size": 1783,
    "path": "../public/_nuxt/default.Dmc0DTNp.css.gz"
  },
  "/_nuxt/delivery-slip.zKrKxSn0.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"b00-B0M/LRvbm6ar+6Uz68hAX1g1+JQ\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 2816,
    "path": "../public/_nuxt/delivery-slip.zKrKxSn0.css"
  },
  "/_nuxt/delivery-slip.zKrKxSn0.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2e6-o6IuyHOyjxF/kAT8QNT9cgIY91k\"",
    "mtime": "2026-05-20T15:26:06.201Z",
    "size": 742,
    "path": "../public/_nuxt/delivery-slip.zKrKxSn0.css.br"
  },
  "/_nuxt/delivery-slip.zKrKxSn0.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"394-ZDNFFoDP4z7Z+zw8fYyJRak41Wo\"",
    "mtime": "2026-05-20T15:26:06.201Z",
    "size": 916,
    "path": "../public/_nuxt/delivery-slip.zKrKxSn0.css.gz"
  },
  "/_nuxt/DFtsfriV.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"db3-SWIXwMHI0O81NYJU8AOpw8tv++0\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 3507,
    "path": "../public/_nuxt/DFtsfriV.js"
  },
  "/_nuxt/DFtsfriV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4ae-rAsLLfpROxnuRITr6BzodPvhtVY\"",
    "mtime": "2026-05-20T15:26:06.202Z",
    "size": 1198,
    "path": "../public/_nuxt/DFtsfriV.js.br"
  },
  "/_nuxt/DFtsfriV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"54d-CQj/1YCd5XCPE+hMs6Oxwzwnp1I\"",
    "mtime": "2026-05-20T15:26:06.202Z",
    "size": 1357,
    "path": "../public/_nuxt/DFtsfriV.js.gz"
  },
  "/_nuxt/DGJWJhcA.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"3243-UOWG89kfFHkHV/5fWC3M4HEFWx8\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 12867,
    "path": "../public/_nuxt/DGJWJhcA.js"
  },
  "/_nuxt/DGJWJhcA.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"104f-EIgqyisoaFeIFUHsy2mrJ7F5+bI\"",
    "mtime": "2026-05-20T15:26:06.202Z",
    "size": 4175,
    "path": "../public/_nuxt/DGJWJhcA.js.br"
  },
  "/_nuxt/DGJWJhcA.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"123e-/bjCIcll/4Rh/thJXvLHxl90n5s\"",
    "mtime": "2026-05-20T15:26:06.202Z",
    "size": 4670,
    "path": "../public/_nuxt/DGJWJhcA.js.gz"
  },
  "/_nuxt/DjvBa-1E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3e-pUclDn9an7oRNGoPIMWjc1WHxMY\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 62,
    "path": "../public/_nuxt/DjvBa-1E.js"
  },
  "/_nuxt/DKNHSoiD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1f24-r6Mz/ehkORONn5dWVhhRga1LwHE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 7972,
    "path": "../public/_nuxt/DKNHSoiD.js"
  },
  "/_nuxt/DKNHSoiD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"798-KXbobStdP5XNALlGgT++ez7ffC8\"",
    "mtime": "2026-05-20T15:26:06.244Z",
    "size": 1944,
    "path": "../public/_nuxt/DKNHSoiD.js.br"
  },
  "/_nuxt/DKNHSoiD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"92e-9tV/JiiXcNbET772FIwLSaAD8mU\"",
    "mtime": "2026-05-20T15:26:06.243Z",
    "size": 2350,
    "path": "../public/_nuxt/DKNHSoiD.js.gz"
  },
  "/_nuxt/Dl7nPB0I.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"247-BbqcjFvR/Ea6tIEGa3K1wbAHoNc\"",
    "mtime": "2026-05-20T15:26:06.244Z",
    "size": 583,
    "path": "../public/_nuxt/Dl7nPB0I.js.br"
  },
  "/_nuxt/Dl7nPB0I.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"462-k1OPRCUm7osF6Q2YLkv8+xxyMGs\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1122,
    "path": "../public/_nuxt/Dl7nPB0I.js"
  },
  "/_nuxt/Dl7nPB0I.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"29f-F6zbDSpHZnB7xXcAgJgRT5GPI/4\"",
    "mtime": "2026-05-20T15:26:06.244Z",
    "size": 671,
    "path": "../public/_nuxt/Dl7nPB0I.js.gz"
  },
  "/_nuxt/DlAUqK2U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5b-eFCz/UrraTh721pgAl0VxBNR1es\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 91,
    "path": "../public/_nuxt/DlAUqK2U.js"
  },
  "/_nuxt/DlNIqG9h.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3f1-xV1d3jQOyDVjlsVkVR89eaO9xY0\"",
    "mtime": "2026-05-20T15:26:06.245Z",
    "size": 1009,
    "path": "../public/_nuxt/DlNIqG9h.js.br"
  },
  "/_nuxt/DlNIqG9h.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"46a-W2bsKvM94dgO0NjgK1w6FVvk5Eg\"",
    "mtime": "2026-05-20T15:26:06.245Z",
    "size": 1130,
    "path": "../public/_nuxt/DlNIqG9h.js.gz"
  },
  "/_nuxt/DlNIqG9h.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"831-ZKVkYZdhFXLJYchAyyyKebjfoHw\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 2097,
    "path": "../public/_nuxt/DlNIqG9h.js"
  },
  "/_nuxt/DneLHUYD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"db1-5sb0ZXHx9f58LAfO3sS+fImZghk\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 3505,
    "path": "../public/_nuxt/DneLHUYD.js"
  },
  "/_nuxt/DneLHUYD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"545-5f4PsUbpwEm6dhHv/rzwxohaTiw\"",
    "mtime": "2026-05-20T15:26:06.284Z",
    "size": 1349,
    "path": "../public/_nuxt/DneLHUYD.js.br"
  },
  "/_nuxt/DneLHUYD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"620-wyqaSpGI1jN4CvpJg4n6TJay2ok\"",
    "mtime": "2026-05-20T15:26:06.284Z",
    "size": 1568,
    "path": "../public/_nuxt/DneLHUYD.js.gz"
  },
  "/_nuxt/DOxZxuMR.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"22f5-IyAhF7MxXe6Aw51MdCO884+oG4c\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 8949,
    "path": "../public/_nuxt/DOxZxuMR.js"
  },
  "/_nuxt/DOxZxuMR.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ba0-xPWbLW/gU/quEkXECl/0fV36oKY\"",
    "mtime": "2026-05-20T15:26:06.285Z",
    "size": 2976,
    "path": "../public/_nuxt/DOxZxuMR.js.br"
  },
  "/_nuxt/DOxZxuMR.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"da1-zpoBsor3edWco7YYtqZ23uieGtI\"",
    "mtime": "2026-05-20T15:26:06.284Z",
    "size": 3489,
    "path": "../public/_nuxt/DOxZxuMR.js.gz"
  },
  "/_nuxt/DP0m6EKD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"158a-kFpOaRVQq+RPvTf81qNP8oSAQes\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 5514,
    "path": "../public/_nuxt/DP0m6EKD.js"
  },
  "/_nuxt/DP0m6EKD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7c3-P0/A4qcVO1yGaj+rDmYLJa895uo\"",
    "mtime": "2026-05-20T15:26:06.285Z",
    "size": 1987,
    "path": "../public/_nuxt/DP0m6EKD.js.br"
  },
  "/_nuxt/DP0m6EKD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8a4-BeKOz3mj+QyacQ9KRs5rdUPSVoM\"",
    "mtime": "2026-05-20T15:26:06.285Z",
    "size": 2212,
    "path": "../public/_nuxt/DP0m6EKD.js.gz"
  },
  "/_nuxt/DrOtRCSJ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"18a7-ubEPa3ZRacX6le4UIUPGZuW5yZY\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 6311,
    "path": "../public/_nuxt/DrOtRCSJ.js"
  },
  "/_nuxt/DrOtRCSJ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"9d1-2nX/ku/VWlV3cJgI/jmYQv8uHsA\"",
    "mtime": "2026-05-20T15:26:06.321Z",
    "size": 2513,
    "path": "../public/_nuxt/DrOtRCSJ.js.br"
  },
  "/_nuxt/DrOtRCSJ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bb0-ryJ2edVxCU1C7uCWexPFG7II8Rk\"",
    "mtime": "2026-05-20T15:26:06.321Z",
    "size": 2992,
    "path": "../public/_nuxt/DrOtRCSJ.js.gz"
  },
  "/_nuxt/DRt1PW6B.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"484c-SOSXeT3+wwNzTkZrQSvrETvpHl4\"",
    "mtime": "2026-05-20T15:26:06.420Z",
    "size": 18508,
    "path": "../public/_nuxt/DRt1PW6B.js.br"
  },
  "/_nuxt/DRt1PW6B.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"e4f4-ygB126x+Nm+RajWlCOzmatSJba8\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 58612,
    "path": "../public/_nuxt/DRt1PW6B.js"
  },
  "/_nuxt/DRt1PW6B.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5023-Z8lXvLpj2REvUNDVMy206OcCvdY\"",
    "mtime": "2026-05-20T15:26:06.322Z",
    "size": 20515,
    "path": "../public/_nuxt/DRt1PW6B.js.gz"
  },
  "/_nuxt/DsOADAP2.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"d7b-hyzN9Y8CBw/ELazFy+QmWz/Ncko\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 3451,
    "path": "../public/_nuxt/DsOADAP2.js"
  },
  "/_nuxt/DsOADAP2.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"536-IkAnqyqplN/gbshq+HaIVLqsDJo\"",
    "mtime": "2026-05-20T15:26:06.321Z",
    "size": 1334,
    "path": "../public/_nuxt/DsOADAP2.js.br"
  },
  "/_nuxt/DsOADAP2.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"661-Jy6kyc7JRXAu/6g59k1WpnKGCN4\"",
    "mtime": "2026-05-20T15:26:06.321Z",
    "size": 1633,
    "path": "../public/_nuxt/DsOADAP2.js.gz"
  },
  "/_nuxt/DthuxEun.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"434d-qd81/4UqBtofP7kLrDUhmCru7FI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 17229,
    "path": "../public/_nuxt/DthuxEun.js"
  },
  "/_nuxt/DthuxEun.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"13fa-QRPiHAQZM7V7gD3sg6/OTxAizHg\"",
    "mtime": "2026-05-20T15:26:06.358Z",
    "size": 5114,
    "path": "../public/_nuxt/DthuxEun.js.br"
  },
  "/_nuxt/DthuxEun.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"17e6-OwVKuAgTEOTR7NMFzNObSTwyMWA\"",
    "mtime": "2026-05-20T15:26:06.321Z",
    "size": 6118,
    "path": "../public/_nuxt/DthuxEun.js.gz"
  },
  "/_nuxt/DVw2Bpf3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2da-Q5vjLUXP3f/nNFy3rx+bmswgr+Y\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 730,
    "path": "../public/_nuxt/DVw2Bpf3.js"
  },
  "/_nuxt/Dx3lTyBU.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b4c-GviL7ahl3KT7RTHivdDshIaRdzY\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 2892,
    "path": "../public/_nuxt/Dx3lTyBU.js"
  },
  "/_nuxt/Dx3lTyBU.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"37a-YI1gyXa1mhJmkMKh/xTs9sHNOOY\"",
    "mtime": "2026-05-20T15:26:06.369Z",
    "size": 890,
    "path": "../public/_nuxt/Dx3lTyBU.js.br"
  },
  "/_nuxt/Dx3lTyBU.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3e7-Wp9Y/cyDNniXhyfzcbZnL67uOQs\"",
    "mtime": "2026-05-20T15:26:06.364Z",
    "size": 999,
    "path": "../public/_nuxt/Dx3lTyBU.js.gz"
  },
  "/_nuxt/DX4X8Onv.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"20d9-goC2ArqaXs7k3uAdJHHqX/nUbcE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 8409,
    "path": "../public/_nuxt/DX4X8Onv.js"
  },
  "/_nuxt/DX4X8Onv.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bfe-N/G0jC+zL7a68icrrp+quHBQmMk\"",
    "mtime": "2026-05-20T15:26:06.364Z",
    "size": 3070,
    "path": "../public/_nuxt/DX4X8Onv.js.gz"
  },
  "/_nuxt/DX4X8Onv.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a0a-8tvia45I6UvzFvxJSH6UHfI58/4\"",
    "mtime": "2026-05-20T15:26:06.364Z",
    "size": 2570,
    "path": "../public/_nuxt/DX4X8Onv.js.br"
  },
  "/_nuxt/Dx97QkCd.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"255c-/qPVH7w0de6cOIMW8ilG8q4UxMA\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 9564,
    "path": "../public/_nuxt/Dx97QkCd.js"
  },
  "/_nuxt/Dx97QkCd.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c5a-t0fRzUybdtltqqiusJgotkZ5aP4\"",
    "mtime": "2026-05-20T15:26:06.407Z",
    "size": 3162,
    "path": "../public/_nuxt/Dx97QkCd.js.br"
  },
  "/_nuxt/Dy4fhYWn.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6ab-73JtJ3fQARdGHWq1en+1xoUBuJk\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1707,
    "path": "../public/_nuxt/Dy4fhYWn.js"
  },
  "/_nuxt/Dx97QkCd.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"eac-klJKRYPYRTEz7HrKuV26OcBY9Ps\"",
    "mtime": "2026-05-20T15:26:06.369Z",
    "size": 3756,
    "path": "../public/_nuxt/Dx97QkCd.js.gz"
  },
  "/_nuxt/Dy4fhYWn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1e9-FGpiMYqTVwlihnWlNbNnUvIDUzs\"",
    "mtime": "2026-05-20T15:26:06.369Z",
    "size": 489,
    "path": "../public/_nuxt/Dy4fhYWn.js.gz"
  },
  "/_nuxt/Dy4fhYWn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"192-VV73gKoofKGzigqliyjOl63R8eU\"",
    "mtime": "2026-05-20T15:26:06.369Z",
    "size": 402,
    "path": "../public/_nuxt/Dy4fhYWn.js.br"
  },
  "/_nuxt/DY7uzvOZ.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"3bf1-+HUj1oM5temBfADvAXviTwgTTck\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 15345,
    "path": "../public/_nuxt/DY7uzvOZ.js"
  },
  "/_nuxt/DY7uzvOZ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"11e9-mvu+LDMa9rltb/57ynuuVlceLPk\"",
    "mtime": "2026-05-20T15:26:06.412Z",
    "size": 4585,
    "path": "../public/_nuxt/DY7uzvOZ.js.br"
  },
  "/_nuxt/DY7uzvOZ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1416-/wOE0hZwnxYaBH/dy57L3MFqQ5I\"",
    "mtime": "2026-05-20T15:26:06.407Z",
    "size": 5142,
    "path": "../public/_nuxt/DY7uzvOZ.js.gz"
  },
  "/_nuxt/Dzx4pygP.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"136e-ziCPn/omR0c5F6MJyuX4XSnAu2k\"",
    "mtime": "2026-05-20T15:26:06.412Z",
    "size": 4974,
    "path": "../public/_nuxt/Dzx4pygP.js.br"
  },
  "/_nuxt/Dzx4pygP.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"3f6e-PHTD7JAHZYO+niQKv+csK4qWt2Y\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 16238,
    "path": "../public/_nuxt/Dzx4pygP.js"
  },
  "/_nuxt/edit.DcjrOQTK.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4d-XsZwf/Ldyk0VUaEcHB5yiaoEaiA\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 77,
    "path": "../public/_nuxt/edit.DcjrOQTK.css"
  },
  "/_nuxt/Dzx4pygP.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1640-adfB0rAJ20JZ+lhtigV+XTZV2Kg\"",
    "mtime": "2026-05-20T15:26:06.412Z",
    "size": 5696,
    "path": "../public/_nuxt/Dzx4pygP.js.gz"
  },
  "/_nuxt/entry.Cwy5tlxD.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"78333-IfCz9C+cwcylmWdJPgoFyEAECrI\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 492339,
    "path": "../public/_nuxt/entry.Cwy5tlxD.css"
  },
  "/_nuxt/entry.Cwy5tlxD.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"58ae-AIp9feI59GH3kKLnp7UnOq1o0sY\"",
    "mtime": "2026-05-20T15:26:06.707Z",
    "size": 22702,
    "path": "../public/_nuxt/entry.Cwy5tlxD.css.br"
  },
  "/_nuxt/error-404.M1Ug_QKG.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"97e-dTnR+C4sn8HLqF/Uj+pGRBoSDok\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 2430,
    "path": "../public/_nuxt/error-404.M1Ug_QKG.css"
  },
  "/_nuxt/error-404.M1Ug_QKG.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2cd-Twc2y/e77IPpUHRox9l5rMvF+PM\"",
    "mtime": "2026-05-20T15:26:06.458Z",
    "size": 717,
    "path": "../public/_nuxt/error-404.M1Ug_QKG.css.br"
  },
  "/_nuxt/entry.Cwy5tlxD.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"274a5-GHxcukfsd/bqLuWJbCvzV5WCQHQ\"",
    "mtime": "2026-05-20T15:26:06.551Z",
    "size": 160933,
    "path": "../public/_nuxt/entry.Cwy5tlxD.css.gz"
  },
  "/_nuxt/error-404.M1Ug_QKG.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"352-Sbi96HMcjyjYovqEFL9gCW8WdfU\"",
    "mtime": "2026-05-20T15:26:06.458Z",
    "size": 850,
    "path": "../public/_nuxt/error-404.M1Ug_QKG.css.gz"
  },
  "/_nuxt/error-500.DqAghvHc.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"773-kQOMw0mMDwkvM5A3Tq8it6qZzc0\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1907,
    "path": "../public/_nuxt/error-500.DqAghvHc.css"
  },
  "/_nuxt/error-500.DqAghvHc.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"26a-Tvo8Z8lAl9uIhGsYiX/WG8v0MZE\"",
    "mtime": "2026-05-20T15:26:06.458Z",
    "size": 618,
    "path": "../public/_nuxt/error-500.DqAghvHc.css.br"
  },
  "/_nuxt/error-500.DqAghvHc.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d4-IQnc7xVUs0I+JAdQMW+4fxskAkw\"",
    "mtime": "2026-05-20T15:26:06.458Z",
    "size": 724,
    "path": "../public/_nuxt/error-500.DqAghvHc.css.gz"
  },
  "/_nuxt/EtqXfgWA.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"8a0-GhwlAxsuy1eTIL2FfmGJaYhAfZ8\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 2208,
    "path": "../public/_nuxt/EtqXfgWA.js"
  },
  "/_nuxt/EtqXfgWA.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"494-xxh5R0mjRqcW1BcWPaXn4zyvnbA\"",
    "mtime": "2026-05-20T15:26:06.480Z",
    "size": 1172,
    "path": "../public/_nuxt/EtqXfgWA.js.gz"
  },
  "/_nuxt/EtqXfgWA.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3b6-x4pwSBrByvhRAfeeC698yofizag\"",
    "mtime": "2026-05-20T15:26:06.480Z",
    "size": 950,
    "path": "../public/_nuxt/EtqXfgWA.js.br"
  },
  "/_nuxt/f4hW42wO.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6077-8O3G/vS7N2h5AhVAgyT3TA4f3ak\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 24695,
    "path": "../public/_nuxt/f4hW42wO.js"
  },
  "/_nuxt/f4hW42wO.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1d7d-lS9WUvRfs/vF+C3s0zYMX/+8vJY\"",
    "mtime": "2026-05-20T15:26:06.520Z",
    "size": 7549,
    "path": "../public/_nuxt/f4hW42wO.js.br"
  },
  "/_nuxt/f4hW42wO.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2068-v5pZiBxS2j2I5r2HwzvglhcdJhw\"",
    "mtime": "2026-05-20T15:26:06.501Z",
    "size": 8296,
    "path": "../public/_nuxt/f4hW42wO.js.gz"
  },
  "/_nuxt/FfAVPT4I.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1278-oOS0Gkn9SVoBNYGS0qhpA8sFtxw\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 4728,
    "path": "../public/_nuxt/FfAVPT4I.js"
  },
  "/_nuxt/FfAVPT4I.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"665-oA+gcGGHfacdijUhKv5J4uT+E7w\"",
    "mtime": "2026-05-20T15:26:06.519Z",
    "size": 1637,
    "path": "../public/_nuxt/FfAVPT4I.js.gz"
  },
  "/_nuxt/FfAVPT4I.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"569-EX03YDYryChrzdW3a0ORq92tXhA\"",
    "mtime": "2026-05-20T15:26:06.519Z",
    "size": 1385,
    "path": "../public/_nuxt/FfAVPT4I.js.br"
  },
  "/_nuxt/Ghcy35Ta.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"12a9-Ns8qsSvVcH1XjJ5HHbm80o014VI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 4777,
    "path": "../public/_nuxt/Ghcy35Ta.js"
  },
  "/_nuxt/Ghcy35Ta.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"805-ky8YdzHw5CppEP7UUUBtz8YyFEM\"",
    "mtime": "2026-05-20T15:26:06.520Z",
    "size": 2053,
    "path": "../public/_nuxt/Ghcy35Ta.js.br"
  },
  "/_nuxt/Ghcy35Ta.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"963-CzVs0LWxST6WUsJEbTHZu0UlDCw\"",
    "mtime": "2026-05-20T15:26:06.520Z",
    "size": 2403,
    "path": "../public/_nuxt/Ghcy35Ta.js.gz"
  },
  "/_nuxt/GlaJchqb.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4048-GIa5NUKDnnJPTg5nzdDDPWcfQTo\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 16456,
    "path": "../public/_nuxt/GlaJchqb.js"
  },
  "/_nuxt/GlaJchqb.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"122c-XYnUhEKz2sZKeQn+9ljdrXPynLE\"",
    "mtime": "2026-05-20T15:26:06.525Z",
    "size": 4652,
    "path": "../public/_nuxt/GlaJchqb.js.br"
  },
  "/_nuxt/GlaJchqb.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"155e-wg5maP+8CYe7o3A5EaZ2UcrcFYs\"",
    "mtime": "2026-05-20T15:26:06.520Z",
    "size": 5470,
    "path": "../public/_nuxt/GlaJchqb.js.gz"
  },
  "/_nuxt/inbound.B8IaLsr6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"220-ZrP9akIA/tyVm+X3CKmczydrY3Q\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 544,
    "path": "../public/_nuxt/inbound.B8IaLsr6.css"
  },
  "/_nuxt/index.BEo8Igia.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"36f-+xBEMQU1/7oXOT/zCt3EwD0/Fgw\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 879,
    "path": "../public/_nuxt/index.BEo8Igia.css"
  },
  "/_nuxt/index.CaJ7US3P.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"1648-pGUcRWeWR5E84FgjLKEfSbV+uS4\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 5704,
    "path": "../public/_nuxt/index.CaJ7US3P.css"
  },
  "/_nuxt/index.CaJ7US3P.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"4eb-mXAVOqUv55fssla5w7Flp+I4agM\"",
    "mtime": "2026-05-20T15:26:06.551Z",
    "size": 1259,
    "path": "../public/_nuxt/index.CaJ7US3P.css.br"
  },
  "/_nuxt/index.CaJ7US3P.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5cd-HCJ1WvbFxVK1xfdvc0aH0MbUL3E\"",
    "mtime": "2026-05-20T15:26:06.551Z",
    "size": 1485,
    "path": "../public/_nuxt/index.CaJ7US3P.css.gz"
  },
  "/_nuxt/index.CFRujpK7.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"468-5+Vzsi883d4TH3dhGp7dhZRRFwQ\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1128,
    "path": "../public/_nuxt/index.CFRujpK7.css"
  },
  "/_nuxt/index.CFRujpK7.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"163-cp37UUMFSBTrP1cEMvpqdzi2thE\"",
    "mtime": "2026-05-20T15:26:06.565Z",
    "size": 355,
    "path": "../public/_nuxt/index.CFRujpK7.css.br"
  },
  "/_nuxt/index.CFRujpK7.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1c2-WF8PNN9IqyZyjXwixwlhA0lk+Mk\"",
    "mtime": "2026-05-20T15:26:06.554Z",
    "size": 450,
    "path": "../public/_nuxt/index.CFRujpK7.css.gz"
  },
  "/_nuxt/index.CqiyFLdC.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2a2-ztPLqzviQ92nUyK54A/RQ3nrYLc\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 674,
    "path": "../public/_nuxt/index.CqiyFLdC.css"
  },
  "/_nuxt/index.CSpvFvjT.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"167-ayZwwwCz6EZCRGJ1pmWQpv2c8dE\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 359,
    "path": "../public/_nuxt/index.CSpvFvjT.css"
  },
  "/_nuxt/index.C_M75ZE9.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"43b-OFWciZIOJS0DT06Q+Vj1y5CJbIg\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1083,
    "path": "../public/_nuxt/index.C_M75ZE9.css"
  },
  "/_nuxt/index.C_M75ZE9.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"16e-DPA45lA0TGHCNedAyuKQkyl8ZSg\"",
    "mtime": "2026-05-20T15:26:06.587Z",
    "size": 366,
    "path": "../public/_nuxt/index.C_M75ZE9.css.br"
  },
  "/_nuxt/index.DGqcDsB9.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"1106-qV09LEVDJkePzHD934uJCpIGTZ4\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 4358,
    "path": "../public/_nuxt/index.DGqcDsB9.css"
  },
  "/_nuxt/index.C_M75ZE9.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1cb-QSuPAa2juHJHUkCHbW5mLEl73oU\"",
    "mtime": "2026-05-20T15:26:06.587Z",
    "size": 459,
    "path": "../public/_nuxt/index.C_M75ZE9.css.gz"
  },
  "/_nuxt/index.DGqcDsB9.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"42f-BZzlFLe/mO1mcO9lSfMR/hMNIJg\"",
    "mtime": "2026-05-20T15:26:06.587Z",
    "size": 1071,
    "path": "../public/_nuxt/index.DGqcDsB9.css.br"
  },
  "/_nuxt/index.DGqcDsB9.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4ef-tZRQbvUP/rskBe7GxMR19eNC64U\"",
    "mtime": "2026-05-20T15:26:06.587Z",
    "size": 1263,
    "path": "../public/_nuxt/index.DGqcDsB9.css.gz"
  },
  "/_nuxt/index.DWnqRvID.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"155-7I/JeFeqMh4Ag1cppOC0tfjh1ho\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 341,
    "path": "../public/_nuxt/index.DWnqRvID.css"
  },
  "/_nuxt/index.DyGTFPMV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7e-24YU6LoREWm2CNkUZ6dj7Eb7/a0\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 126,
    "path": "../public/_nuxt/index.DyGTFPMV.css"
  },
  "/_nuxt/index.FM7tD2-G.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"378-W2mc6hYn+WLJBff8wIJ3iYwW/aE\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 888,
    "path": "../public/_nuxt/index.FM7tD2-G.css"
  },
  "/_nuxt/index.S4ylBlY5.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"9f0-ZaUIAOETtGf++VVm8pgWKk43qB4\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 2544,
    "path": "../public/_nuxt/index.S4ylBlY5.css"
  },
  "/_nuxt/index.S4ylBlY5.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"24c-3ZRMRF6x301ibcX2SO06JdNddlc\"",
    "mtime": "2026-05-20T15:26:06.662Z",
    "size": 588,
    "path": "../public/_nuxt/index.S4ylBlY5.css.br"
  },
  "/_nuxt/index.S4ylBlY5.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d4-4msDgW/kxNwBeYWrCT8sDvbb6sA\"",
    "mtime": "2026-05-20T15:26:06.662Z",
    "size": 724,
    "path": "../public/_nuxt/index.S4ylBlY5.css.gz"
  },
  "/_nuxt/index.xG-n8-bQ.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"2001-qUwkJRi9QkCc9So47dpSsVWUKX8\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 8193,
    "path": "../public/_nuxt/index.xG-n8-bQ.css"
  },
  "/_nuxt/index.xG-n8-bQ.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"5fb-yp2sAZFUzQGcLwt1AAGJAS8J3RE\"",
    "mtime": "2026-05-20T15:26:06.662Z",
    "size": 1531,
    "path": "../public/_nuxt/index.xG-n8-bQ.css.br"
  },
  "/_nuxt/index.xG-n8-bQ.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"709-j/Vr/Bxtdl1sadMLVerY0N+5Kvw\"",
    "mtime": "2026-05-20T15:26:06.662Z",
    "size": 1801,
    "path": "../public/_nuxt/index.xG-n8-bQ.css.gz"
  },
  "/_nuxt/ip920-GG.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"8c62-ttqIYEz/qZCREXSIAk2g5mzc6ig\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 35938,
    "path": "../public/_nuxt/ip920-GG.js"
  },
  "/_nuxt/ip920-GG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b7a-g015g5jFc7gX2xVnl7NXjSjT8RI\"",
    "mtime": "2026-05-20T15:26:06.703Z",
    "size": 11130,
    "path": "../public/_nuxt/ip920-GG.js.br"
  },
  "/_nuxt/ip920-GG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3099-i8mu88UzGUq5xjtqeZqp2ULavO8\"",
    "mtime": "2026-05-20T15:26:06.664Z",
    "size": 12441,
    "path": "../public/_nuxt/ip920-GG.js.gz"
  },
  "/_nuxt/iUCXbbZT.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2ddc-lQn+8cxfb7PJN8Xvpl35MhyIgCI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 11740,
    "path": "../public/_nuxt/iUCXbbZT.js"
  },
  "/_nuxt/iUCXbbZT.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"fc2-VAlhuKqfi2qZi9FKcjaonHEGuUI\"",
    "mtime": "2026-05-20T15:26:06.664Z",
    "size": 4034,
    "path": "../public/_nuxt/iUCXbbZT.js.br"
  },
  "/_nuxt/iUCXbbZT.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"124e-f2cgQVzMAsdmmbkZ3ez96Tur480\"",
    "mtime": "2026-05-20T15:26:06.664Z",
    "size": 4686,
    "path": "../public/_nuxt/iUCXbbZT.js.gz"
  },
  "/_nuxt/JxbNvNYn.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5e4-6KEkIU/Mm0+cylMN68VhnuozH4Q\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1508,
    "path": "../public/_nuxt/JxbNvNYn.js"
  },
  "/_nuxt/JxbNvNYn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2d6-iPJ3wPNB0ASxPPdMzIaKRqFD9Is\"",
    "mtime": "2026-05-20T15:26:06.703Z",
    "size": 726,
    "path": "../public/_nuxt/JxbNvNYn.js.br"
  },
  "/_nuxt/JxbNvNYn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"327-EGjMaDwEJK2vaBvitUPoazGArjo\"",
    "mtime": "2026-05-20T15:26:06.703Z",
    "size": 807,
    "path": "../public/_nuxt/JxbNvNYn.js.gz"
  },
  "/_nuxt/lga2prTV.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4990-MjQxOtoeamjMP0pMt2Rf7i1H7zg\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 18832,
    "path": "../public/_nuxt/lga2prTV.js"
  },
  "/_nuxt/lga2prTV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1762-YTJC6MynXdePv7ZbwrJVMFbBM30\"",
    "mtime": "2026-05-20T15:26:06.707Z",
    "size": 5986,
    "path": "../public/_nuxt/lga2prTV.js.br"
  },
  "/_nuxt/lga2prTV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1c1c-ibamgfegGqOJNd37LodlYmjq7Ug\"",
    "mtime": "2026-05-20T15:26:06.703Z",
    "size": 7196,
    "path": "../public/_nuxt/lga2prTV.js.gz"
  },
  "/_nuxt/login.BYICVlB-.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"4ea-OMIqeQOV1HiEkUjtI5PDnb7xw8I\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1258,
    "path": "../public/_nuxt/login.BYICVlB-.css"
  },
  "/_nuxt/login.BYICVlB-.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1c6-mnojfni1C6GlmffKWL5bb6jACQM\"",
    "mtime": "2026-05-20T15:26:06.706Z",
    "size": 454,
    "path": "../public/_nuxt/login.BYICVlB-.css.br"
  },
  "/_nuxt/login.BYICVlB-.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"214-PO5f5xpvP0EiSnNPzTK+4qx/l9A\"",
    "mtime": "2026-05-20T15:26:06.706Z",
    "size": 532,
    "path": "../public/_nuxt/login.BYICVlB-.css.gz"
  },
  "/_nuxt/M9fJbGuP.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"375d-gl5O8+3Yh9CTO481knYrNS0Bmpc\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 14173,
    "path": "../public/_nuxt/M9fJbGuP.js"
  },
  "/_nuxt/M9fJbGuP.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"112c-noxecg9C0bPLUwhKEU1n446i8l8\"",
    "mtime": "2026-05-20T15:26:06.738Z",
    "size": 4396,
    "path": "../public/_nuxt/M9fJbGuP.js.br"
  },
  "/_nuxt/M9fJbGuP.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1424-kqMXZFC6tFwetKoVgmJzX1M3Vs0\"",
    "mtime": "2026-05-20T15:26:06.713Z",
    "size": 5156,
    "path": "../public/_nuxt/M9fJbGuP.js.gz"
  },
  "/_nuxt/mK3u6GGn.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"653-MaXF1kd931RSa8DyU3FPoXzHV+E\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1619,
    "path": "../public/_nuxt/mK3u6GGn.js"
  },
  "/_nuxt/mK3u6GGn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2db-GBTSI23GGXHbnkTfgl7eA0/cVNA\"",
    "mtime": "2026-05-20T15:26:06.744Z",
    "size": 731,
    "path": "../public/_nuxt/mK3u6GGn.js.br"
  },
  "/_nuxt/mK3u6GGn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"34e-DpBWQUZJBRAjNKMaqL0X0cN9yLA\"",
    "mtime": "2026-05-20T15:26:06.739Z",
    "size": 846,
    "path": "../public/_nuxt/mK3u6GGn.js.gz"
  },
  "/_nuxt/new.oPTt0W7K.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4d-v2qkSHVPUrF7KbZwzZOnr8atS/I\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 77,
    "path": "../public/_nuxt/new.oPTt0W7K.css"
  },
  "/_nuxt/Noto_Sans_SC-normal-400-cyrillic.CRA5_Pf1.woff2": {
    "type": "font/woff2",
    "etag": "\"2718-BYt1bekVEbtN1BCaemAgO6xx6hQ\"",
    "mtime": "2026-05-20T15:26:04.552Z",
    "size": 10008,
    "path": "../public/_nuxt/Noto_Sans_SC-normal-400-cyrillic.CRA5_Pf1.woff2"
  },
  "/_nuxt/Noto_Sans_SC-normal-400-latin-ext.CqPqLCfe.woff2": {
    "type": "font/woff2",
    "etag": "\"2034-1zKknrBXeRKZIWnxoctIUp/IuGY\"",
    "mtime": "2026-05-20T15:26:04.574Z",
    "size": 8244,
    "path": "../public/_nuxt/Noto_Sans_SC-normal-400-latin-ext.CqPqLCfe.woff2"
  },
  "/_nuxt/Noto_Sans_SC-normal-400-latin.DYAKOyvl.woff2": {
    "type": "font/woff2",
    "etag": "\"6298-+Cq+BOIvO9yQiIDFDP1LCUTSp4U\"",
    "mtime": "2026-05-20T15:26:04.574Z",
    "size": 25240,
    "path": "../public/_nuxt/Noto_Sans_SC-normal-400-latin.DYAKOyvl.woff2"
  },
  "/_nuxt/Noto_Sans_SC-normal-400-text.BfzSEbFz.woff2": {
    "type": "font/woff2",
    "etag": "\"12c00-Zx48HivoVmXJ01kDtTRe6PnTNU0\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 76800,
    "path": "../public/_nuxt/Noto_Sans_SC-normal-400-text.BfzSEbFz.woff2"
  },
  "/_nuxt/Noto_Sans_SC-normal-400-vietnamese.y5SU35Rl.woff2": {
    "type": "font/woff2",
    "etag": "\"2388-chStg4lTb1rOp8p0Vz+2FMgxRvU\"",
    "mtime": "2026-05-20T15:26:04.574Z",
    "size": 9096,
    "path": "../public/_nuxt/Noto_Sans_SC-normal-400-vietnamese.y5SU35Rl.woff2"
  },
  "/_nuxt/Outfit-normal-400-latin-ext.DdQaqQDo.woff2": {
    "type": "font/woff2",
    "etag": "\"39d8-sqVel30br8w1wJ7fkoMuV0KPYjs\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 14808,
    "path": "../public/_nuxt/Outfit-normal-400-latin-ext.DdQaqQDo.woff2"
  },
  "/_nuxt/Outfit-normal-400-latin.Bc-8i84L.woff2": {
    "type": "font/woff2",
    "etag": "\"7e24-2KMW98v6RuaYdskl5Y+/e3wavw0\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 32292,
    "path": "../public/_nuxt/Outfit-normal-400-latin.Bc-8i84L.woff2"
  },
  "/_nuxt/PgxjBVFh.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"41c-/CnK8/304Ewrjiveya9JA5zZfEI\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1052,
    "path": "../public/_nuxt/PgxjBVFh.js"
  },
  "/_nuxt/PgxjBVFh.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"228-TF6Hj4Zr73l/QvS/mYrlLqe16Mo\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 552,
    "path": "../public/_nuxt/PgxjBVFh.js.br"
  },
  "/_nuxt/PgxjBVFh.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"278-OWcdj9qgBwwxCfcOHsiTyDqo3fE\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 632,
    "path": "../public/_nuxt/PgxjBVFh.js.gz"
  },
  "/_nuxt/pos.LdTRl_CV.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"204-DKNhYRieltm8MFQMd7RSV+ENwzg\"",
    "mtime": "2026-05-20T15:26:06.771Z",
    "size": 516,
    "path": "../public/_nuxt/pos.LdTRl_CV.css.br"
  },
  "/_nuxt/pos.LdTRl_CV.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"6e7-eOMr/9yuyw2KxStQCKHq/IaNOZo\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1767,
    "path": "../public/_nuxt/pos.LdTRl_CV.css"
  },
  "/_nuxt/PreparationBoard.B_DG7fHz.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"a2e-/Sj60dXUv+cPxo+N0TCBOOZF9lQ\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 2606,
    "path": "../public/_nuxt/PreparationBoard.B_DG7fHz.css"
  },
  "/_nuxt/pos.LdTRl_CV.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"275-1fnyoyS7xc+uiDXiUdISqhkuTjI\"",
    "mtime": "2026-05-20T15:26:06.771Z",
    "size": 629,
    "path": "../public/_nuxt/pos.LdTRl_CV.css.gz"
  },
  "/_nuxt/PreparationBoard.B_DG7fHz.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"265-9N7fPqg9ws7ikxxAGSz67DyQhZ0\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 613,
    "path": "../public/_nuxt/PreparationBoard.B_DG7fHz.css.br"
  },
  "/_nuxt/PreparationBoard.B_DG7fHz.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d2-WDo9BRm2biQqNQZsGen+sHnJgVw\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 722,
    "path": "../public/_nuxt/PreparationBoard.B_DG7fHz.css.gz"
  },
  "/_nuxt/print.FZBA9vGA.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"457-eTLyG+nx2D8CKuDVIKMreaefHs4\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1111,
    "path": "../public/_nuxt/print.FZBA9vGA.css"
  },
  "/_nuxt/print.FZBA9vGA.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"180-FnRIOeg8HURML+xVhKOHLStKZew\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 384,
    "path": "../public/_nuxt/print.FZBA9vGA.css.br"
  },
  "/_nuxt/print.FZBA9vGA.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"200-2clJVvvKiJ2dAB/SF0i10HC/Hgo\"",
    "mtime": "2026-05-20T15:26:06.774Z",
    "size": 512,
    "path": "../public/_nuxt/print.FZBA9vGA.css.gz"
  },
  "/_nuxt/s8Xr8MBX.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"10d54-O1Bv0JMNofGW80ck2DGsHt1DjAY\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 68948,
    "path": "../public/_nuxt/s8Xr8MBX.js"
  },
  "/_nuxt/s8Xr8MBX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4dfe-2tZLGvKFJXDeETuzIacopuzsAXc\"",
    "mtime": "2026-05-20T15:26:06.896Z",
    "size": 19966,
    "path": "../public/_nuxt/s8Xr8MBX.js.br"
  },
  "/_nuxt/s8Xr8MBX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"560e-fmG8Yb+z8gq6bXcBh+QYpeUxLEU\"",
    "mtime": "2026-05-20T15:26:06.822Z",
    "size": 22030,
    "path": "../public/_nuxt/s8Xr8MBX.js.gz"
  },
  "/_nuxt/ScheduleBoard.CYq76Bg0.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"363-6P5MNvASf1YR7L6JZyDyb5vaGP8\"",
    "mtime": "2026-05-20T15:26:06.799Z",
    "size": 867,
    "path": "../public/_nuxt/ScheduleBoard.CYq76Bg0.css.br"
  },
  "/_nuxt/ScheduleBoard.CYq76Bg0.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"dca-3Ibxc/4NyXJ8jx7/H3+RebreArY\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 3530,
    "path": "../public/_nuxt/ScheduleBoard.CYq76Bg0.css"
  },
  "/_nuxt/ScheduleBoard.CYq76Bg0.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"404-tRm/epokZYgLaCWOeKjJYfPSV60\"",
    "mtime": "2026-05-20T15:26:06.779Z",
    "size": 1028,
    "path": "../public/_nuxt/ScheduleBoard.CYq76Bg0.css.gz"
  },
  "/_nuxt/syBOQd5l.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6d7-z52PpNfRysepn0EtIPb24qNsTwA\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1751,
    "path": "../public/_nuxt/syBOQd5l.js"
  },
  "/_nuxt/syBOQd5l.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"34d-ISllKLsj3fNLlWB3iD44lbDD+ys\"",
    "mtime": "2026-05-20T15:26:06.799Z",
    "size": 845,
    "path": "../public/_nuxt/syBOQd5l.js.br"
  },
  "/_nuxt/syBOQd5l.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3d9-WV3x2tAt+wvN1FfpQypUPw0KT8Q\"",
    "mtime": "2026-05-20T15:26:06.799Z",
    "size": 985,
    "path": "../public/_nuxt/syBOQd5l.js.gz"
  },
  "/_nuxt/vCu2co3e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e3-tz5tW5Rh9jirx2bOXvX9Scy6wJU\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 227,
    "path": "../public/_nuxt/vCu2co3e.js"
  },
  "/_nuxt/w4QWzuVH.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"50d-uOQaQP5OnlBQI6e6fHXUYt8OVkA\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1293,
    "path": "../public/_nuxt/w4QWzuVH.js"
  },
  "/_nuxt/w4QWzuVH.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23c-65ga7FN+H6dYf2QhmtXyPaMJwOU\"",
    "mtime": "2026-05-20T15:26:06.813Z",
    "size": 572,
    "path": "../public/_nuxt/w4QWzuVH.js.br"
  },
  "/_nuxt/w4QWzuVH.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2a9-n8J/8gK1o2Ma4tmN41lct/aRSTA\"",
    "mtime": "2026-05-20T15:26:06.813Z",
    "size": 681,
    "path": "../public/_nuxt/w4QWzuVH.js.gz"
  },
  "/_nuxt/Wb01iu9o.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"bbc-X35UBVtZguWZgOF7+0GzOxVwytE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 3004,
    "path": "../public/_nuxt/Wb01iu9o.js"
  },
  "/_nuxt/Wb01iu9o.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"500-sbZipbrdMpqih27t9ssDeikH0YI\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 1280,
    "path": "../public/_nuxt/Wb01iu9o.js.br"
  },
  "/_nuxt/Wb01iu9o.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5b3-VwskRf/1Yse6huyc+/uDasv55LM\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 1459,
    "path": "../public/_nuxt/Wb01iu9o.js.gz"
  },
  "/_nuxt/xc1t1rzp.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4b3-S/cLcgQ1ONpwlulPsrnyKd+pspE\"",
    "mtime": "2026-05-20T15:26:04.576Z",
    "size": 1203,
    "path": "../public/_nuxt/xc1t1rzp.js"
  },
  "/_nuxt/xc1t1rzp.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"275-nm9dB+YokvtkUgD2zKEDzm6d9ig\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 629,
    "path": "../public/_nuxt/xc1t1rzp.js.br"
  },
  "/_nuxt/xc1t1rzp.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2cd-FHXgrCE+dM9k6mFr5/ibCaxmtwg\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 717,
    "path": "../public/_nuxt/xc1t1rzp.js.gz"
  },
  "/_nuxt/xYFpWvXA.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5ac-U5MhpSYOKJHJP71Oyxr3yBPEiTw\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 1452,
    "path": "../public/_nuxt/xYFpWvXA.js"
  },
  "/_nuxt/xYFpWvXA.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2e4-iQGDj0vW5HSP+TYacm5M1F82arM\"",
    "mtime": "2026-05-20T15:26:06.828Z",
    "size": 740,
    "path": "../public/_nuxt/xYFpWvXA.js.br"
  },
  "/_nuxt/xYFpWvXA.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"355-5K5h7fwlEgElX2F16TsZe1LqJd8\"",
    "mtime": "2026-05-20T15:26:06.828Z",
    "size": 853,
    "path": "../public/_nuxt/xYFpWvXA.js.gz"
  },
  "/_nuxt/_customerId_.DZl4Ssbr.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"5b7-LPHbxSPj2JxzEup81RYW1IXdLYk\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 1463,
    "path": "../public/_nuxt/_customerId_.DZl4Ssbr.css"
  },
  "/_nuxt/_customerId_.DZl4Ssbr.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1cd-rZc7oCQDDGPhAnGCob48lDR44LE\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 461,
    "path": "../public/_nuxt/_customerId_.DZl4Ssbr.css.br"
  },
  "/_nuxt/_customerId_.DZl4Ssbr.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"257-0cMA1gFis5wkJh5nTo1k0c1Q1u8\"",
    "mtime": "2026-05-20T15:26:06.827Z",
    "size": 599,
    "path": "../public/_nuxt/_customerId_.DZl4Ssbr.css.gz"
  },
  "/_nuxt/_id_.B7DPmU4y.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7b-ca/deClmAIKhU0wSF/N6Jm6pYsA\"",
    "mtime": "2026-05-20T15:26:04.575Z",
    "size": 123,
    "path": "../public/_nuxt/_id_.B7DPmU4y.css"
  },
  "/_nuxt/_WnVyCuL.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2ed9-aVioFjbPKRa8lV1uSdgfUzNwuaQ\"",
    "mtime": "2026-05-20T15:26:04.578Z",
    "size": 11993,
    "path": "../public/_nuxt/_WnVyCuL.js"
  },
  "/_nuxt/_WnVyCuL.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"11b2-uHy/edt0mNKHYIyZYWoHzfvBXxk\"",
    "mtime": "2026-05-20T15:26:06.837Z",
    "size": 4530,
    "path": "../public/_nuxt/_WnVyCuL.js.gz"
  },
  "/_nuxt/_WnVyCuL.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ffe-HvSIMZb+7pysPJzXzzQBwKDYXQU\"",
    "mtime": "2026-05-20T15:26:06.848Z",
    "size": 4094,
    "path": "../public/_nuxt/_WnVyCuL.js.br"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-MpV/bRfmMuOYhDThoE2cur9LKPk\"",
    "mtime": "2026-05-20T15:26:05.070Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/builds/meta/c4cc670e-c6a6-4ae8-9adf-3b493661f78d.json": {
    "type": "application/json",
    "etag": "\"58-i0TFmMbu8VTAQ4Ur5VlLZrbOfrY\"",
    "mtime": "2026-05-20T15:26:05.071Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/c4cc670e-c6a6-4ae8-9adf-3b493661f78d.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _kVivA6 = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const TOKEN_MAX_AGE_SECONDS = 60 * 60 * 24;
const TOKEN_EXPIRES_IN = "1d";
const getSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error("JWT_SECRET \u672A\u914D\u7F6E\u6216\u957F\u5EA6\u4E0D\u8DB3 16 \u5B57\u7B26\uFF0C\u8BF7\u68C0\u67E5 .env");
  }
  return secret;
};
const signToken = (payload) => {
  return jwt.sign(payload, getSecret(), { expiresIn: TOKEN_EXPIRES_IN });
};
const verifyToken = (token) => {
  try {
    const payload = jwt.verify(token, getSecret());
    if (!payload.iat || Math.floor(Date.now() / 1e3) - payload.iat > TOKEN_MAX_AGE_SECONDS) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
};
const hashPassword = async (plain) => {
  return bcrypt.hash(plain, 10);
};
const verifyPassword = async (plain, hash) => {
  return bcrypt.compare(plain, hash);
};
const getCurrentUser = (event) => {
  var _a, _b;
  return (_b = (_a = event == null ? void 0 : event.context) == null ? void 0 : _a.user) != null ? _b : null;
};

const EXACT_PUBLIC = /* @__PURE__ */ new Set([
  "/api/health",
  "/api/auth/login",
  "/api/auth/wx-login"
]);
const PREFIX_PUBLIC = [
  "/api/public/"
];
const CASHIER_EXACT_ALLOW = /* @__PURE__ */ new Set([
  "/api/categories",
  "/api/customers",
  "/api/products",
  "/api/stocks",
  "/api/preorders/schedule",
  "/api/preorders/stats/hot"
]);
const CASHIER_PREFIX_ALLOW = [
  "/api/auth/",
  "/api/orders",
  "/api/categories/",
  "/api/customers/",
  "/api/products/",
  "/api/stocks/stocktake",
  "/api/promotions",
  "/api/settings",
  // 允许读 lowStockThreshold；写操作由 API 内部角色校验
  "/api/notifications"
  // 铃铛 + 通知列表（生成/regenerate 在 handler 内做 admin 校验）
];
const isPublicPath = (path) => {
  if (EXACT_PUBLIC.has(path)) return true;
  return PREFIX_PUBLIC.some((p) => path.startsWith(p));
};
const isCashierAllowed = (path) => {
  if (CASHIER_EXACT_ALLOW.has(path)) return true;
  if (/^\/api\/preorders\/\d+\/(made|urgent)$/.test(path)) return true;
  return CASHIER_PREFIX_ALLOW.some((p) => path === p || path.startsWith(p));
};
const _qC2co0 = defineEventHandler(async (event) => {
  const url = getRequestURL(event);
  const path = url.pathname;
  if (!path.startsWith("/api/")) return;
  if (event.method === "OPTIONS") return;
  const auth = getHeader(event, "authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const payload = token ? verifyToken(token) : null;
  if (payload) {
    event.context.user = payload;
  }
  if (isPublicPath(path)) return;
  if (!payload) {
    throw createError$1({
      statusCode: 401,
      statusMessage: "Unauthorized",
      data: { message: "\u672A\u767B\u5F55\u6216\u51ED\u8BC1\u5DF2\u8FC7\u671F", code: "UNAUTHORIZED" }
    });
  }
  if (payload.type === "staff" && payload.role === "cashier" && !isCashierAllowed(path)) {
    throw createError$1({
      statusCode: 403,
      statusMessage: "Forbidden",
      data: { message: "\u5F53\u524D\u89D2\u8272\u65E0\u6743\u8BBF\u95EE\u8BE5\u8D44\u6E90", code: "ROLE_FORBIDDEN" }
    });
  }
});

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_wcBWr7 = () => import('../routes/api/auth/login.post.mjs');
const _lazy_MhNtxA = () => import('../routes/api/auth/me.get.mjs');
const _lazy_l9SbAQ = () => import('../routes/api/auth/wx-login.post.mjs');
const _lazy_9Xagqg = () => import('../routes/api/categories/_id_.delete.mjs');
const _lazy_xR_S7N = () => import('../routes/api/categories/_id_.put.mjs');
const _lazy_wj59AL = () => import('../routes/api/index.get.mjs');
const _lazy_Xs2zsG = () => import('../routes/api/index.post.mjs');
const _lazy_48mguO = () => import('../routes/api/customers/_id_.delete.mjs');
const _lazy_i_IaXA = () => import('../routes/api/customers/_id_.get.mjs');
const _lazy_Kqny7O = () => import('../routes/api/customers/_id_.put.mjs');
const _lazy_F4e2eA = () => import('../routes/api/customers/_id/favorites.get.mjs');
const _lazy__zOIZy = () => import('../routes/api/customers/_id/recharge.post.mjs');
const _lazy_wn1jAR = () => import('../routes/api/customers/_id/repay.post.mjs');
const _lazy_cBtGtv = () => import('../routes/api/customers/debt-summary.get.mjs');
const _lazy_NKyadb = () => import('../routes/api/index.get2.mjs');
const _lazy_N2vUzB = () => import('../routes/api/index.post2.mjs');
const _lazy_6yRXnW = () => import('../routes/api/customers/search.get.mjs');
const _lazy_DDv64i = () => import('../routes/api/health.get.mjs');
const _lazy_tJOrRI = () => import('../routes/api/notifications/_id/read.post.mjs');
const _lazy_u6hq0b = () => import('../routes/api/index.get3.mjs');
const _lazy_qeIuwf = () => import('../routes/api/notifications/mark-all-read.post.mjs');
const _lazy_cNTViR = () => import('../routes/api/notifications/regenerate.post.mjs');
const _lazy_WkCaWc = () => import('../routes/api/notifications/unread-count.get.mjs');
const _lazy_nMFnJA = () => import('../routes/api/orders/_id_.get.mjs');
const _lazy_hPuUJl = () => import('../routes/api/orders/_id/repay.post.mjs');
const _lazy_tapoU4 = () => import('../routes/api/orders/bulk-tag.post.mjs');
const _lazy_vkOPCF = () => import('../routes/api/orders/checkout.post.mjs');
const _lazy_VDeZ0r = () => import('../routes/api/index.get4.mjs');
const _lazy_5lL1Bj = () => import('../routes/api/payments/statement.get.mjs');
const _lazy_P6D7ZY = () => import('../routes/api/preorders/_id_.get.mjs');
const _lazy_WgBe94 = () => import('../routes/api/preorders/_id_.put.mjs');
const _lazy_9NR9UK = () => import('../routes/api/preorders/_id/advance.post.mjs');
const _lazy_FP1_ea = () => import('../routes/api/preorders/_id/made.patch.mjs');
const _lazy_ZJ01xX = () => import('../routes/api/preorders/_id/urgent.patch.mjs');
const _lazy_CyG28M = () => import('../routes/api/index.get5.mjs');
const _lazy_Vy3enn = () => import('../routes/api/index.post3.mjs');
const _lazy_1yFYY9 = () => import('../routes/api/preorders/schedule.get.mjs');
const _lazy_itLPkc = () => import('../routes/api/preorders/stats/hot.get.mjs');
const _lazy_BKoq6o = () => import('../routes/api/preorders/upcoming.get.mjs');
const _lazy_sZNiNV = () => import('../routes/api/products/_id_.delete.mjs');
const _lazy_wuRPb5 = () => import('../routes/api/products/_id_.get.mjs');
const _lazy_SLqT3l = () => import('../routes/api/products/_id_.put.mjs');
const _lazy_7gLAYk = () => import('../routes/api/products/_id/image.post.mjs');
const _lazy_BKhPkU = () => import('../routes/api/index.get6.mjs');
const _lazy_ajg4UP = () => import('../routes/api/index.post4.mjs');
const _lazy_yVj2i4 = () => import('../routes/api/products/with-stock.get.mjs');
const _lazy_1P7fxH = () => import('../routes/api/promotions/_id_.delete.mjs');
const _lazy_9IcDPp = () => import('../routes/api/promotions/_id_.put.mjs');
const _lazy_AI3piO = () => import('../routes/api/index.get7.mjs');
const _lazy_rpWnPQ = () => import('../routes/api/index.post5.mjs');
const _lazy_syrJKw = () => import('../routes/api/public/products/_id_.get.mjs');
const _lazy_g3rjyi = () => import('../routes/api/public/index.get.mjs');
const _lazy_zIcwH0 = () => import('../routes/api/reports/cashier.get.mjs');
const _lazy_zvjF0Q = () => import('../routes/api/reports/dashboard.get.mjs');
const _lazy_4n8gOB = () => import('../routes/api/reports/debtors.get.mjs');
const _lazy_vt0eqH = () => import('../routes/api/index.get8.mjs');
const _lazy_l2sfhf = () => import('../routes/api/index.put.mjs');
const _lazy_q9hbTp = () => import('../routes/api/stocks/_id_.delete.mjs');
const _lazy_G0VLO2 = () => import('../routes/api/stocks/discount.post.mjs');
const _lazy_IwpP_j = () => import('../routes/api/stocks/expiring.get.mjs');
const _lazy_69L7WB = () => import('../routes/api/stocks/inbound.post.mjs');
const _lazy_OqQV77 = () => import('../routes/api/index.get9.mjs');
const _lazy_BT5w10 = () => import('../routes/api/stocks/purchase-suggestion.get.mjs');
const _lazy_eOq7ep = () => import('../routes/api/stocks/scrap.post.mjs');
const _lazy_PpKjyw = () => import('../routes/api/stocks/stocktake/adjust.post.mjs');
const _lazy_uCWeGA = () => import('../routes/api/stocks/stocktake/summary.get.mjs');
const _lazy_H6PiYv = () => import('../routes/api/stocks/summary.get.mjs');
const _lazy_VTQMtj = () => import('../routes/api/users/_id_.put.mjs');
const _lazy_IglC_o = () => import('../routes/api/index.get10.mjs');
const _lazy_zguAg9 = () => import('../routes/api/index.post6.mjs');
const _lazy_3AVg5Z = () => import('../routes/renderer.mjs');

const handlers = [
  { route: '', handler: _kVivA6, lazy: false, middleware: true, method: undefined },
  { route: '', handler: _qC2co0, lazy: false, middleware: true, method: undefined },
  { route: '/api/auth/login', handler: _lazy_wcBWr7, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/me', handler: _lazy_MhNtxA, lazy: true, middleware: false, method: "get" },
  { route: '/api/auth/wx-login', handler: _lazy_l9SbAQ, lazy: true, middleware: false, method: "post" },
  { route: '/api/categories/:id', handler: _lazy_9Xagqg, lazy: true, middleware: false, method: "delete" },
  { route: '/api/categories/:id', handler: _lazy_xR_S7N, lazy: true, middleware: false, method: "put" },
  { route: '/api/categories', handler: _lazy_wj59AL, lazy: true, middleware: false, method: "get" },
  { route: '/api/categories', handler: _lazy_Xs2zsG, lazy: true, middleware: false, method: "post" },
  { route: '/api/customers/:id', handler: _lazy_48mguO, lazy: true, middleware: false, method: "delete" },
  { route: '/api/customers/:id', handler: _lazy_i_IaXA, lazy: true, middleware: false, method: "get" },
  { route: '/api/customers/:id', handler: _lazy_Kqny7O, lazy: true, middleware: false, method: "put" },
  { route: '/api/customers/:id/favorites', handler: _lazy_F4e2eA, lazy: true, middleware: false, method: "get" },
  { route: '/api/customers/:id/recharge', handler: _lazy__zOIZy, lazy: true, middleware: false, method: "post" },
  { route: '/api/customers/:id/repay', handler: _lazy_wn1jAR, lazy: true, middleware: false, method: "post" },
  { route: '/api/customers/debt-summary', handler: _lazy_cBtGtv, lazy: true, middleware: false, method: "get" },
  { route: '/api/customers', handler: _lazy_NKyadb, lazy: true, middleware: false, method: "get" },
  { route: '/api/customers', handler: _lazy_N2vUzB, lazy: true, middleware: false, method: "post" },
  { route: '/api/customers/search', handler: _lazy_6yRXnW, lazy: true, middleware: false, method: "get" },
  { route: '/api/health', handler: _lazy_DDv64i, lazy: true, middleware: false, method: "get" },
  { route: '/api/notifications/:id/read', handler: _lazy_tJOrRI, lazy: true, middleware: false, method: "post" },
  { route: '/api/notifications', handler: _lazy_u6hq0b, lazy: true, middleware: false, method: "get" },
  { route: '/api/notifications/mark-all-read', handler: _lazy_qeIuwf, lazy: true, middleware: false, method: "post" },
  { route: '/api/notifications/regenerate', handler: _lazy_cNTViR, lazy: true, middleware: false, method: "post" },
  { route: '/api/notifications/unread-count', handler: _lazy_WkCaWc, lazy: true, middleware: false, method: "get" },
  { route: '/api/orders/:id', handler: _lazy_nMFnJA, lazy: true, middleware: false, method: "get" },
  { route: '/api/orders/:id/repay', handler: _lazy_hPuUJl, lazy: true, middleware: false, method: "post" },
  { route: '/api/orders/bulk-tag', handler: _lazy_tapoU4, lazy: true, middleware: false, method: "post" },
  { route: '/api/orders/checkout', handler: _lazy_vkOPCF, lazy: true, middleware: false, method: "post" },
  { route: '/api/orders', handler: _lazy_VDeZ0r, lazy: true, middleware: false, method: "get" },
  { route: '/api/payments/statement', handler: _lazy_5lL1Bj, lazy: true, middleware: false, method: "get" },
  { route: '/api/preorders/:id', handler: _lazy_P6D7ZY, lazy: true, middleware: false, method: "get" },
  { route: '/api/preorders/:id', handler: _lazy_WgBe94, lazy: true, middleware: false, method: "put" },
  { route: '/api/preorders/:id/advance', handler: _lazy_9NR9UK, lazy: true, middleware: false, method: "post" },
  { route: '/api/preorders/:id/made', handler: _lazy_FP1_ea, lazy: true, middleware: false, method: "patch" },
  { route: '/api/preorders/:id/urgent', handler: _lazy_ZJ01xX, lazy: true, middleware: false, method: "patch" },
  { route: '/api/preorders', handler: _lazy_CyG28M, lazy: true, middleware: false, method: "get" },
  { route: '/api/preorders', handler: _lazy_Vy3enn, lazy: true, middleware: false, method: "post" },
  { route: '/api/preorders/schedule', handler: _lazy_1yFYY9, lazy: true, middleware: false, method: "get" },
  { route: '/api/preorders/stats/hot', handler: _lazy_itLPkc, lazy: true, middleware: false, method: "get" },
  { route: '/api/preorders/upcoming', handler: _lazy_BKoq6o, lazy: true, middleware: false, method: "get" },
  { route: '/api/products/:id', handler: _lazy_sZNiNV, lazy: true, middleware: false, method: "delete" },
  { route: '/api/products/:id', handler: _lazy_wuRPb5, lazy: true, middleware: false, method: "get" },
  { route: '/api/products/:id', handler: _lazy_SLqT3l, lazy: true, middleware: false, method: "put" },
  { route: '/api/products/:id/image', handler: _lazy_7gLAYk, lazy: true, middleware: false, method: "post" },
  { route: '/api/products', handler: _lazy_BKhPkU, lazy: true, middleware: false, method: "get" },
  { route: '/api/products', handler: _lazy_ajg4UP, lazy: true, middleware: false, method: "post" },
  { route: '/api/products/with-stock', handler: _lazy_yVj2i4, lazy: true, middleware: false, method: "get" },
  { route: '/api/promotions/:id', handler: _lazy_1P7fxH, lazy: true, middleware: false, method: "delete" },
  { route: '/api/promotions/:id', handler: _lazy_9IcDPp, lazy: true, middleware: false, method: "put" },
  { route: '/api/promotions', handler: _lazy_AI3piO, lazy: true, middleware: false, method: "get" },
  { route: '/api/promotions', handler: _lazy_rpWnPQ, lazy: true, middleware: false, method: "post" },
  { route: '/api/public/products/:id', handler: _lazy_syrJKw, lazy: true, middleware: false, method: "get" },
  { route: '/api/public/products', handler: _lazy_g3rjyi, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/cashier', handler: _lazy_zIcwH0, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/dashboard', handler: _lazy_zvjF0Q, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/debtors', handler: _lazy_4n8gOB, lazy: true, middleware: false, method: "get" },
  { route: '/api/settings', handler: _lazy_vt0eqH, lazy: true, middleware: false, method: "get" },
  { route: '/api/settings', handler: _lazy_l2sfhf, lazy: true, middleware: false, method: "put" },
  { route: '/api/stocks/:id', handler: _lazy_q9hbTp, lazy: true, middleware: false, method: "delete" },
  { route: '/api/stocks/discount', handler: _lazy_G0VLO2, lazy: true, middleware: false, method: "post" },
  { route: '/api/stocks/expiring', handler: _lazy_IwpP_j, lazy: true, middleware: false, method: "get" },
  { route: '/api/stocks/inbound', handler: _lazy_69L7WB, lazy: true, middleware: false, method: "post" },
  { route: '/api/stocks', handler: _lazy_OqQV77, lazy: true, middleware: false, method: "get" },
  { route: '/api/stocks/purchase-suggestion', handler: _lazy_BT5w10, lazy: true, middleware: false, method: "get" },
  { route: '/api/stocks/scrap', handler: _lazy_eOq7ep, lazy: true, middleware: false, method: "post" },
  { route: '/api/stocks/stocktake/adjust', handler: _lazy_PpKjyw, lazy: true, middleware: false, method: "post" },
  { route: '/api/stocks/stocktake/summary', handler: _lazy_uCWeGA, lazy: true, middleware: false, method: "get" },
  { route: '/api/stocks/summary', handler: _lazy_H6PiYv, lazy: true, middleware: false, method: "get" },
  { route: '/api/users/:id', handler: _lazy_VTQMtj, lazy: true, middleware: false, method: "put" },
  { route: '/api/users', handler: _lazy_IglC_o, lazy: true, middleware: false, method: "get" },
  { route: '/api/users', handler: _lazy_zguAg9, lazy: true, middleware: false, method: "post" },
  { route: '/__nuxt_error', handler: _lazy_3AVg5Z, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_3AVg5Z, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp = createNitroApp();
function useNitroApp() {
  return nitroApp;
}
runNitroPlugins(nitroApp);

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

export { trapUnhandledNodeErrors as a, useNitroApp as b, defineEventHandler as c, destr as d, signToken as e, getRequestIP as f, getHeader as g, getCurrentUser as h, createError$1 as i, getRouterParam as j, getQuery as k, generateNotifications as l, readMultipartFormData as m, hashPassword as n, joinRelativeURL as o, prisma as p, getResponseStatusText as q, readBody as r, setupGracefulShutdown as s, toNodeListener as t, useRuntimeConfig as u, verifyPassword as v, getResponseStatus as w, defineRenderHandler as x, getRouteRules as y, joinURL as z };
//# sourceMappingURL=nitro.mjs.map
