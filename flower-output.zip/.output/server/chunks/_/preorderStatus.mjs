const FORWARD_FLOW = {
  pending_confirm: ["booked", "cancelled"],
  booked: ["scheduled", "cancelled"],
  scheduled: ["in_production", "cancelled"],
  in_production: ["ready_to_ship", "cancelled"],
  ready_to_ship: ["completed", "cancelled"],
  completed: [],
  cancelled: []
};
const STOCK_DEDUCTED_STATUSES = [
  "in_production",
  "ready_to_ship",
  "completed"
];
function canTransition(from, to) {
  var _a, _b;
  return (_b = (_a = FORWARD_FLOW[from]) == null ? void 0 : _a.includes(to)) != null ? _b : false;
}
function isStockDeducted(status) {
  return STOCK_DEDUCTED_STATUSES.includes(status);
}

export { canTransition as c, isStockDeducted as i };
//# sourceMappingURL=preorderStatus.mjs.map
