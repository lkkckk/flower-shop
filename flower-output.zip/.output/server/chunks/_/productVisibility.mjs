import { h as getCurrentUser } from './nitro.mjs';

const isPlainObject = (value) => {
  if (!value || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
};
const stripWholesalePrice = (value) => {
  if (Array.isArray(value)) {
    return value.map((item) => stripWholesalePrice(item));
  }
  if (!isPlainObject(value)) {
    return value;
  }
  const next = {};
  for (const [key, child] of Object.entries(value)) {
    if (key === "wholesalePrice") continue;
    next[key] = stripWholesalePrice(child);
  }
  return next;
};
const isCashierRequest = (event) => {
  const user = getCurrentUser(event);
  return (user == null ? void 0 : user.type) === "staff" && user.role === "cashier";
};
const hideWholesalePriceForCashier = (event, value) => {
  return isCashierRequest(event) ? stripWholesalePrice(value) : value;
};

export { hideWholesalePriceForCashier as h, isCashierRequest as i };
//# sourceMappingURL=productVisibility.mjs.map
